import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Destination,
  CultureItem,
  UMKMProduct,
  EventItem,
  NewsArticle,
  GalleryPhoto,
  TeamMember,
  MapMarkerItem,
  UserRole,
  AppLanguage,
  TicketBooking,
  PaymentStatus,
  PaymentSettings,
  ContactInfo,
  HeroTextInfo
} from '../types';
import {
  INITIAL_DESTINATIONS,
  INITIAL_CULTURE,
  INITIAL_UMKM,
  INITIAL_EVENTS,
  INITIAL_NEWS,
  INITIAL_GALLERY,
  INITIAL_TEAM,
  INITIAL_MAP_MARKERS,
  INITIAL_BOOKINGS,
} from '../data/initialData';

interface TourismContextType {
  // Data
  destinations: Destination[];
  cultureItems: CultureItem[];
  umkmProducts: UMKMProduct[];
  events: EventItem[];
  news: NewsArticle[];
  gallery: GalleryPhoto[];
  team: TeamMember[];
  addTeamMember: (member: Omit<TeamMember, 'id'>) => void;
  deleteTeamMember: (id: string) => void;
  mapMarkers: MapMarkerItem[];
  ticketBookings: TicketBooking[];
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: Partial<PaymentSettings>) => void;
  heroSliders: string[];
  updateHeroSliders: (urls: string[]) => void;
  contactInfo: ContactInfo;
  updateContactInfo: (info: ContactInfo) => void;
  heroText: HeroTextInfo;
  updateHeroText: (info: HeroTextInfo) => void;
  
  // Active Navigation & View
  currentView: string;
  setCurrentView: (view: string) => void;

  // Language & Role
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;

  // Search & Global Filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Modals & Detail Overlays
  selectedDestination: Destination | null;
  setSelectedDestination: (dest: Destination | null) => void;
  selectedCulture: CultureItem | null;
  setSelectedCulture: (item: CultureItem | null) => void;
  selectedProduct: UMKMProduct | null;
  setSelectedProduct: (prod: UMKMProduct | null) => void;
  selectedArticle: NewsArticle | null;
  setSelectedArticle: (article: NewsArticle | null) => void;
  qrModalItem: { title: string; subtitle: string; code: string; type: string } | null;
  setQrModalItem: (item: { title: string; subtitle: string; code: string; type: string } | null) => void;
  lightboxIndex: number | null;
  setLightboxIndex: (idx: number | null) => void;

  // Ticketing specific
  activeBookingDestination: Destination | null;
  setActiveBookingDestination: (dest: Destination | null) => void;
  selectedTicketForPrint: TicketBooking | null;
  setSelectedTicketForPrint: (ticket: TicketBooking | null) => void;

  // Statistics
  webVisits: number;
  incrementVisits: () => void;

  // CRUD Actions
  addDestination: (dest: Omit<Destination, 'id' | 'slug'>) => void;
  updateDestination: (id: string, dest: Partial<Destination>) => void;
  deleteDestination: (id: string) => void;

  addUMKM: (prod: Omit<UMKMProduct, 'id'>) => void;
  updateUMKM: (id: string, prod: Partial<UMKMProduct>) => void;
  deleteUMKM: (id: string) => void;

  addNews: (news: Omit<NewsArticle, 'id' | 'slug'>) => void;
  updateNews: (id: string, news: Partial<NewsArticle>) => void;
  deleteNews: (id: string) => void;

  addEvent: (event: Omit<EventItem, 'id'>) => void;
  updateEvent: (id: string, event: Partial<EventItem>) => void;
  deleteEvent: (id: string) => void;

  addCulture: (item: Omit<CultureItem, 'id' | 'slug'>) => void;
  updateCulture: (id: string, item: Partial<CultureItem>) => void;
  deleteCulture: (id: string) => void;

  addGalleryPhoto: (photo: Omit<GalleryPhoto, 'id'>) => void;
  deleteGalleryPhoto: (id: string) => void;

  addTicketBooking: (booking: Omit<TicketBooking, 'id' | 'bookingCode' | 'createdAt' | 'qrValidationCode'>) => TicketBooking;
  updateTicketBookingStatus: (id: string, status: PaymentStatus) => void;
  checkInTicket: (bookingCode: string) => boolean;

  resetToDefaults: () => void;
}

const TourismContext = createContext<TourismContextType | undefined>(undefined);

export const TourismProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial from localStorage or defaults
  const [destinations, setDestinations] = useState<Destination[]>(() => {
    const saved = localStorage.getItem('morela_destinations');
    return saved ? JSON.parse(saved) : INITIAL_DESTINATIONS;
  });

  const [cultureItems, setCultureItems] = useState<CultureItem[]>(() => {
    const saved = localStorage.getItem('morela_culture');
    return saved ? JSON.parse(saved) : INITIAL_CULTURE;
  });

  const [umkmProducts, setUmkmProducts] = useState<UMKMProduct[]>(() => {
    const saved = localStorage.getItem('morela_umkm');
    return saved ? JSON.parse(saved) : INITIAL_UMKM;
  });

  const [events, setEvents] = useState<EventItem[]>(() => {
    const saved = localStorage.getItem('morela_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [news, setNews] = useState<NewsArticle[]>(() => {
    const saved = localStorage.getItem('morela_news');
    return saved ? JSON.parse(saved) : INITIAL_NEWS;
  });

  const [gallery, setGallery] = useState<GalleryPhoto[]>(() => {
    const saved = localStorage.getItem('morela_gallery');
    return saved ? JSON.parse(saved) : INITIAL_GALLERY;
  });

  const [ticketBookings, setTicketBookings] = useState<TicketBooking[]>(() => {
    const saved = localStorage.getItem('morela_ticket_bookings');
    return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
  });

  const [team, setTeam] = useState<TeamMember[]>(() => {
    const saved = localStorage.getItem('morela_team');
    return saved ? JSON.parse(saved) : INITIAL_TEAM;
  });
  const [mapMarkers] = useState<MapMarkerItem[]>(INITIAL_MAP_MARKERS);

  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    const saved = localStorage.getItem('morela_payment_settings');
    return saved ? JSON.parse(saved) : {
      rekeningBCA: '0987654321 a.n Desa Morela',
      rekeningMandiri: '1234567890 a.n Pariwisata Morela',
      rekeningMaluku: '1122334455 a.n Kas Desa Morela',
      qrisUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d0/QR_code_for_mobile_English_Wikipedia.svg'
    };
  });

  const updatePaymentSettings = (settings: Partial<PaymentSettings>) => {
    setPaymentSettings(prev => {
      const updated = { ...prev, ...settings };
      localStorage.setItem('morela_payment_settings', JSON.stringify(updated));
      return updated;
    });
  };

  const [heroSliders, setHeroSliders] = useState<string[]>(() => {
    const saved = localStorage.getItem('morela_hero_sliders');
    return saved ? JSON.parse(saved) : [
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=85',
      'https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&w=1920&q=85',
    ];
  });

  const updateHeroSliders = (urls: string[]) => {
    setHeroSliders(urls);
    localStorage.setItem('morela_hero_sliders', JSON.stringify(urls));
  };

  const [contactInfo, setContactInfo] = useState<ContactInfo>(() => {
    const saved = localStorage.getItem('morela_contact_info');
    if (saved) return JSON.parse(saved);
    return {
      address: 'Negeri Morela, Kec. Leihitu, Kab. Maluku Tengah, Maluku',
      phone: '+62 812-3456-7800 (Sekretariat Negeri)'
    };
  });

  const updateContactInfo = (info: ContactInfo) => {
    setContactInfo(info);
    localStorage.setItem('morela_contact_info', JSON.stringify(info));
  };

  const [heroText, setHeroText] = useState<HeroTextInfo>(() => {
    const saved = localStorage.getItem('morela_hero_text');
    if (saved) return JSON.parse(saved);
    return {
      badge: 'Portal Digital Pariwisata Resmi Desa Morela',
      badgeEn: 'Official Digital Tourism Portal of Morela Village',
      title: 'SELAMAT DATANG DI MORELA',
      titleEn: 'WELCOME TO MORELA',
      tagline: '“Jelajah Pesona Morela – Alam, Budaya & Masyarakat”',
      taglineEn: '“Explore the Charms of Morela – Nature, Culture & Community”',
      description: 'Temukan keindahan alam pesisir Leihitu, sakralnya tradisi Pukul Sapu, dan keramahan hangat masyarakat Negeri Morela, Maluku Tengah.',
      descriptionEn: 'Discover Leihitu’s coastal azure waters, sacred centuries-old broom whip traditions, and warm Maluku hospitality.'
    };
  });

  const updateHeroText = (info: HeroTextInfo) => {
    setHeroText(info);
    localStorage.setItem('morela_hero_text', JSON.stringify(info));
  };

  useEffect(() => {
    localStorage.setItem('morela_team', JSON.stringify(team));
  }, [team]);

  const [currentView, setCurrentView] = useState<string>('home');
  const [language, setLanguage] = useState<AppLanguage>('id');
  const [userRole, setUserRole] = useState<UserRole>('pengunjung');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [selectedCulture, setSelectedCulture] = useState<CultureItem | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<UMKMProduct | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [qrModalItem, setQrModalItem] = useState<{ title: string; subtitle: string; code: string; type: string } | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [activeBookingDestination, setActiveBookingDestination] = useState<Destination | null>(null);
  const [selectedTicketForPrint, setSelectedTicketForPrint] = useState<TicketBooking | null>(null);

  // Visits
  const [webVisits, setWebVisits] = useState<number>(() => {
    const saved = localStorage.getItem('morela_visits');
    return saved ? parseInt(saved, 10) : 2845;
  });

  const incrementVisits = () => {
    setWebVisits((prev) => {
      const next = prev + 1;
      localStorage.setItem('morela_visits', next.toString());
      return next;
    });
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('morela_destinations', JSON.stringify(destinations));
  }, [destinations]);

  useEffect(() => {
    localStorage.setItem('morela_culture', JSON.stringify(cultureItems));
  }, [cultureItems]);

  useEffect(() => {
    localStorage.setItem('morela_umkm', JSON.stringify(umkmProducts));
  }, [umkmProducts]);

  useEffect(() => {
    localStorage.setItem('morela_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('morela_news', JSON.stringify(news));
  }, [news]);

  useEffect(() => {
    localStorage.setItem('morela_gallery', JSON.stringify(gallery));
  }, [gallery]);

  useEffect(() => {
    localStorage.setItem('morela_ticket_bookings', JSON.stringify(ticketBookings));
  }, [ticketBookings]);

  // CRUD Implementations
  const addDestination = (item: Omit<Destination, 'id' | 'slug'>) => {
    const id = `dest-${Date.now()}`;
    const slug = item.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newDest: Destination = { ...item, id, slug };
    setDestinations((prev) => [newDest, ...prev]);
  };

  const updateDestination = (id: string, updated: Partial<Destination>) => {
    setDestinations((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteDestination = (id: string) => {
    setDestinations((prev) => prev.filter((item) => item.id !== id));
  };

  const addUMKM = (prod: Omit<UMKMProduct, 'id'>) => {
    const id = `umkm-${Date.now()}`;
    const newProd: UMKMProduct = { ...prod, id };
    setUmkmProducts((prev) => [newProd, ...prev]);
  };

  const updateUMKM = (id: string, updated: Partial<UMKMProduct>) => {
    setUmkmProducts((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteUMKM = (id: string) => {
    setUmkmProducts((prev) => prev.filter((item) => item.id !== id));
  };

  const addNews = (item: Omit<NewsArticle, 'id' | 'slug'>) => {
    const id = `news-${Date.now()}`;
    const slug = item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newArticle: NewsArticle = { ...item, id, slug };
    setNews((prev) => [newArticle, ...prev]);
  };

  const updateNews = (id: string, updated: Partial<NewsArticle>) => {
    setNews((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteNews = (id: string) => {
    setNews((prev) => prev.filter((item) => item.id !== id));
  };

  const addEvent = (event: Omit<EventItem, 'id'>) => {
    const id = `evt-${Date.now()}`;
    const newEvt: EventItem = { ...event, id };
    setEvents((prev) => [newEvt, ...prev]);
  };

  const updateEvent = (id: string, updated: Partial<EventItem>) => {
    setEvents((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((item) => item.id !== id));
  };

  const addCulture = (item: Omit<CultureItem, 'id' | 'slug'>) => {
    const id = `cult-${Date.now()}`;
    const slug = item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newCult: CultureItem = { ...item, id, slug };
    setCultureItems((prev) => [newCult, ...prev]);
  };

  const updateCulture = (id: string, updated: Partial<CultureItem>) => {
    setCultureItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteCulture = (id: string) => {
    setCultureItems((prev) => prev.filter((item) => item.id !== id));
  };

  const addGalleryPhoto = (photo: Omit<GalleryPhoto, 'id'>) => {
    const id = `gal-${Date.now()}`;
    const newPhoto: GalleryPhoto = { ...photo, id };
    setGallery((prev) => [newPhoto, ...prev]);
  };

  const deleteGalleryPhoto = (id: string) => {
    setGallery((prev) => prev.filter((item) => item.id !== id));
  };

  const addTeamMember = (member: Omit<TeamMember, 'id'>) => {
    const id = `team-${Date.now()}`;
    const newMember: TeamMember = { ...member, id };
    setTeam((prev) => [...prev, newMember]);
  };

  const deleteTeamMember = (id: string) => {
    setTeam((prev) => prev.filter((item) => item.id !== id));
  };

  // Ticketing CRUD
  const addTicketBooking = (
    bookingData: Omit<TicketBooking, 'id' | 'bookingCode' | 'createdAt' | 'qrValidationCode'>
  ): TicketBooking => {
    const id = `tkt-${Date.now()}`;
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
    const bookingCode = `MOR-${dateStr}-${randomSuffix}`;
    const qrValidationCode = `VALID-${bookingCode}`;
    const createdAt = new Date().toLocaleString('id-ID', {
      timeZone: 'Asia/Jayapura',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }) + ' WIT';

    const newBooking: TicketBooking = {
      ...bookingData,
      id,
      bookingCode,
      createdAt,
      qrValidationCode,
      paidAt: bookingData.paymentStatus === 'paid' ? createdAt : undefined,
    };

    setTicketBookings((prev) => [newBooking, ...prev]);
    return newBooking;
  };

  const updateTicketBookingStatus = (id: string, status: PaymentStatus) => {
    setTicketBookings((prev) =>
      prev.map((b) => {
        if (b.id !== id) return b;
        const nowStr = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jayapura' }) + ' WIT';
        return {
          ...b,
          paymentStatus: status,
          paidAt: status === 'paid' ? nowStr : b.paidAt,
          checkedInAt: status === 'checked_in' ? nowStr : b.checkedInAt,
        };
      })
    );
  };

  const checkInTicket = (bookingCode: string): boolean => {
    let found = false;
    setTicketBookings((prev) =>
      prev.map((b) => {
        if (b.bookingCode.toUpperCase() === bookingCode.toUpperCase().trim()) {
          found = true;
          const nowStr = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jayapura' }) + ' WIT';
          return {
            ...b,
            paymentStatus: 'checked_in',
            checkedInAt: nowStr,
          };
        }
        return b;
      })
    );
    return found;
  };

  const resetToDefaults = () => {
    localStorage.removeItem('morela_destinations');
    localStorage.removeItem('morela_culture');
    localStorage.removeItem('morela_umkm');
    localStorage.removeItem('morela_events');
    localStorage.removeItem('morela_news');
    localStorage.removeItem('morela_gallery');
    localStorage.removeItem('morela_visits');
    localStorage.removeItem('morela_ticket_bookings');
    setDestinations(INITIAL_DESTINATIONS);
    setCultureItems(INITIAL_CULTURE);
    setUmkmProducts(INITIAL_UMKM);
    setEvents(INITIAL_EVENTS);
    setNews(INITIAL_NEWS);
    setGallery(INITIAL_GALLERY);
    setTicketBookings(INITIAL_BOOKINGS);
    setWebVisits(2845);
  };

  return (
    <TourismContext.Provider
      value={{
        destinations,
        cultureItems,
        umkmProducts,
        events,
        news,
        gallery,
        team,
        mapMarkers,
        ticketBookings,
        currentView,
        setCurrentView,
        language,
        setLanguage,
        userRole,
        setUserRole,
        searchQuery,
        setSearchQuery,
        selectedDestination,
        setSelectedDestination,
        selectedCulture,
        setSelectedCulture,
        selectedProduct,
        setSelectedProduct,
        selectedArticle,
        setSelectedArticle,
        qrModalItem,
        setQrModalItem,
        lightboxIndex,
        setLightboxIndex,
        activeBookingDestination,
        setActiveBookingDestination,
        selectedTicketForPrint,
        setSelectedTicketForPrint,
        webVisits,
        incrementVisits,
        addDestination,
        updateDestination,
        deleteDestination,
        addUMKM,
        updateUMKM,
        deleteUMKM,
        addNews,
        updateNews,
        deleteNews,
        addEvent,
        updateEvent,
        deleteEvent,
        addCulture,
        updateCulture,
        deleteCulture,
        addGalleryPhoto,
        deleteGalleryPhoto,
        addTeamMember,
        deleteTeamMember,
        addTicketBooking,
        updateTicketBookingStatus,
        checkInTicket,
        resetToDefaults,
        paymentSettings,
        updatePaymentSettings,
        heroSliders,
        updateHeroSliders,
        contactInfo,
        updateContactInfo,
        heroText,
        updateHeroText,
      }}
    >
      {children}
    </TourismContext.Provider>
  );
};

export const useTourism = () => {
  const context = useContext(TourismContext);
  if (!context) {
    throw new Error('useTourism must be used within a TourismProvider');
  }
  return context;
};

