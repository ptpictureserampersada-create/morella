import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import {
  BookOpen,
  Award,
  Sparkles,
  Music,
  Utensils,
  History,
  Tag,
  ArrowRight,
  ShieldCheck,
  Compass
} from 'lucide-react';

export const CultureView: React.FC = () => {
  const { cultureItems, setSelectedCulture, language } = useTourism();
  const [activeTab, setActiveTab] = useState<string>('all');

  const tabs = [
    { id: 'all', label: language === 'id' ? 'Semua Arsip' : 'All Archives' },
    { id: 'sejarah', label: language === 'id' ? 'Sejarah & Asal Usul' : 'History' },
    { id: 'tradisi', label: language === 'id' ? 'Tradisi Pukul Sapu' : 'Tradition' },
    { id: 'kesenian', label: language === 'id' ? 'Kesenian & Tari' : 'Arts & Music' },
    { id: 'kuliner', label: language === 'id' ? 'Kuliner Tradisional' : 'Culinary' },
    { id: 'cerita_rakyat', label: language === 'id' ? 'Cerita Rakyat & Sasi' : 'Folklore' },
  ];

  const filteredItems = activeTab === 'all'
    ? cultureItems
    : cultureItems.filter((i) => i.category === activeTab);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      
      {/* Editorial Header */}
      <div className="max-w-3xl space-y-3">
        <div className="text-xs font-semibold uppercase tracking-widest text-amber-700">
          {language === 'id' ? 'Arsip Digital Kebudayaan & Nilai Leluhur' : 'Digital Cultural Heritage Archive'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Budaya, Tradisi & Sejarah Morela' : 'Culture, Tradition & History of Morela'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed max-w-prose">
          {language === 'id'
            ? 'Dokumentasi komprehensif sejarah pembentukan negeri, sakralnya atraksi Pukul Sapu (Ukuwala Mahiate), tarian heroik Cakalele, kearifan konservasi Sasi Laut, dan khazanah kuliner rempah Maluku.'
            : 'Comprehensive institutional repository preserving oral histories, sacred martial fraternities, heroic dances, customary marine conservation (Sasi), and indigenous gastronomic heritage.'}
        </p>
      </div>

      {/* Institutional Featured Spotlight: Tradisi Pukul Sapu */}
      <div className="rounded-3xl bg-stone-900 text-stone-100 overflow-hidden border border-stone-800 shadow-xl grid grid-cols-1 lg:grid-cols-12">
        <div className="lg:col-span-7 p-6 sm:p-10 lg:p-12 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest">
              <Award className="w-4 h-4 text-amber-400" />
              <span>WARISAN BUDAYA TAKBENDA (WBTB) NASIONAL</span>
            </div>
            
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight leading-snug">
              Tradisi Sakral Pukul Sapu (Ukuwala Mahiate)
            </h2>

            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-light">
              Ritual tahunan yang diselenggarakan setiap tanggal 7 Syawal setelah Idul Fitri di Negeri Morela. Saling cambuk dengan lidi pohon enau melambangkan keberanian, ketangguhan fisik, dan ikatan persaudaraan sejati yang disembuhkan dengan ramuan minyak kelapa dan rempah pusaka tanpa meninggalkan rasa dendam.
            </p>

            <blockquote className="border-l-2 border-amber-500 pl-4 py-1 text-xs text-amber-200/90 italic font-serif">
              "Biar luka di badan, hati tetap gandong — persaudaraan masyarakat Morela terpatri abadi melintasi generasi."
            </blockquote>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={() => {
                const found = cultureItems.find((i) => i.id === 'cult-2');
                if (found) setSelectedCulture(found);
              }}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 shadow-sm"
            >
              <span>{language === 'id' ? 'Baca Dokumentasi Lengkap' : 'Read Full Monograph'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[260px] bg-stone-950">
          <img
            src="https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1000&q=80"
            alt="Pukul Sapu Culture Morela"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-transparent lg:hidden" />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-stone-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap border-b-2 -mb-[2px] ${
              activeTab === tab.id
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Cultural Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedCulture(item)}
            className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md hover:border-amber-300 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="relative h-52 w-full bg-stone-100 overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                  {item.category.replace('_', ' ')}
                </div>
              </div>

              <div className="p-6 space-y-3">
                <div className="text-[11px] text-stone-400 font-mono">
                  {item.periodOrTime}
                </div>

                <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-amber-800 transition-colors leading-snug">
                  {language === 'id' ? item.title : item.titleEn}
                </h3>

                <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                  {language === 'id' ? item.summary : item.summaryEn}
                </p>

                <div className="pt-2 flex flex-wrap gap-1.5 text-[10px] text-stone-500">
                  {item.tags.map((t, idx) => (
                    <span key={idx} className="bg-stone-100 px-2 py-0.5 rounded text-stone-600">
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 pt-0">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 group-hover:text-amber-800">
                <span>{language === 'id' ? 'Buka Arsip Lengkap' : 'Read Monograph'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Callout on Digital Preservation */}
      <div className="p-6 sm:p-8 bg-stone-100 rounded-2xl border border-stone-200 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center md:text-left">
          <div className="text-xs font-semibold uppercase tracking-wider text-stone-500">
            {language === 'id' ? 'Arsip Komunitas & Tetua Adat' : 'Community & Customary Oral History'}
          </div>
          <h4 className="font-serif text-lg font-bold text-stone-900">
            {language === 'id' ? 'Punya Informasi Sejarah atau Dokumentasi Adat Morela?' : 'Possess Archival Photographs or Oral Records?'}
          </h4>
          <p className="text-xs text-stone-600 max-w-xl">
            {language === 'id'
              ? 'Masyarakat, mahasiswa, dan peneliti dapat menyumbangkan data naskah atau foto arsip untuk memperkaya khazanah digital kebudayaan desa.'
              : 'Community members and scholars are invited to submit historical manuscripts and photos to enrich the digital repository.'}
          </p>
        </div>

        <button
          onClick={() => {
            alert(language === 'id' ? 'Silakan hubungi Pengelola Desa atau Posko KKN UNIDAR untuk penyerahan arsip foto & dokumen adat.' : 'Please contact Village Administration or UNIDAR post to submit archival materials.');
          }}
          className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors whitespace-nowrap"
        >
          {language === 'id' ? 'Kontribusi Arsip Adat' : 'Contribute Archive'}
        </button>
      </div>

    </div>
  );
};
