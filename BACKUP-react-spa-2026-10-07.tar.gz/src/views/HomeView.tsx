import React, { useState, useEffect } from 'react';
import { useTourism } from '../context/TourismContext';
import {
  Compass,
  ArrowRight,
  MapPin,
  Calendar,
  Sparkles,
  Search,
  Eye,
  ShoppingBag,
  BookOpen,
  Award,
  Waves,
  TreePine,
  Mountain,
  Landmark,
  Layers,
  ChevronRight,
  CheckCircle2,
  QrCode
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    destinations,
    umkmProducts,
    events,
    news,
    setCurrentView,
    setSelectedDestination,
    setSelectedProduct,
    setSelectedArticle,
    setQrModalItem,
    language,
    webVisits,
    heroSliders,
    heroText,
  } = useTourism();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [localSearch, setLocalSearch] = useState<string>('');
  
  const [currentSliderIndex, setCurrentSliderIndex] = useState(0);

  useEffect(() => {
    if (!heroSliders || heroSliders.length === 0) return;
    const interval = setInterval(() => {
      setCurrentSliderIndex((prev) => (prev + 1) % heroSliders.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroSliders]);

  const featuredDestinations = destinations.filter((d) => d.published);
  const displayedDestinations = featuredDestinations.filter((d) => {
    const matchesCategory = activeCategory === 'all' || d.category === activeCategory;
    const matchesSearch =
      d.name.toLowerCase().includes(localSearch.toLowerCase()) ||
      d.tagline.toLowerCase().includes(localSearch.toLowerCase()) ||
      d.location.toLowerCase().includes(localSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredUMKM = umkmProducts.filter((p) => p.featured && p.published).slice(0, 4);
  const upcomingEvents = events.filter((e) => e.status !== 'completed').slice(0, 2);
  const latestNews = news.slice(0, 3);

  const categories = [
    { id: 'all', label: language === 'id' ? 'Semua Destinasi' : 'All Spots', icon: Layers },
    { id: 'pantai', label: language === 'id' ? 'Pantai' : 'Beaches', icon: Waves },
    { id: 'alam', label: language === 'id' ? 'Wisata Alam' : 'Nature', icon: TreePine },
    { id: 'pemandangan', label: language === 'id' ? 'Spot Pemandangan' : 'Viewpoints', icon: Mountain },
    { id: 'religi_sejarah', label: language === 'id' ? 'Wisata Religi & Sejarah' : 'Heritage', icon: Landmark },
    { id: 'budaya', label: language === 'id' ? 'Budaya & Tradisi' : 'Culture', icon: Sparkles },
  ];

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      
      {/* 🌴 1. HERO UTAMA */}
      <section className="relative min-h-[580px] sm:min-h-[640px] flex items-center justify-center bg-stone-900 text-white overflow-hidden">
        {/* Background Image with Scrim */}
        <div className="absolute inset-0 z-0">
          {heroSliders && heroSliders.length > 0 ? (
            heroSliders.map((url, idx) => (
              <img
                key={idx}
                src={url}
                alt={`Morela Slider ${idx + 1}`}
                className={`absolute inset-0 w-full h-full object-cover scale-105 transition-opacity duration-1000 ${
                  idx === currentSliderIndex ? 'opacity-45' : 'opacity-0'
                }`}
              />
            ))
          ) : (
            <div className="absolute inset-0 bg-stone-800" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/60 to-black/40" />
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 flex flex-col lg:flex-row items-center gap-12">
          
          {/* Left / Main Text */}
          <div className="flex-1 text-left">
            {(heroText.badge || heroText.badgeEn) && (
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-medium mb-6 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  {language === 'id' ? heroText.badge : heroText.badgeEn}
                </span>
              </div>
            )}

            {(heroText.title || heroText.titleEn) && (
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight sm:leading-tight">
                {language === 'id' ? heroText.title : heroText.titleEn}
              </h1>
            )}

            {(heroText.tagline || heroText.taglineEn) && (
              <p className="mt-4 sm:mt-6 text-base sm:text-xl text-stone-200 font-light max-w-2xl leading-relaxed">
                {language === 'id' ? heroText.tagline : heroText.taglineEn}
              </p>
            )}

            {(heroText.description || heroText.descriptionEn) && (
              <p className="mt-4 text-xs sm:text-sm text-stone-300 max-w-xl border-l-2 border-emerald-500 pl-4">
                {language === 'id' ? heroText.description : heroText.descriptionEn}
              </p>
            )}

            {/* Three Primary Hero Buttons */}
            <div className="mt-8 sm:mt-10 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={() => setCurrentView('destinations')}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-lg shadow-emerald-950/50 flex items-center gap-2 group"
              >
                <span>{language === 'id' ? 'Jelajahi Destinasi' : 'Explore Destinations'}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setCurrentView('culture')}
                className="px-6 py-3 rounded-xl bg-stone-800/90 hover:bg-stone-700 text-stone-100 font-semibold text-sm transition-all border border-stone-700 backdrop-blur-sm"
              >
                <span>{language === 'id' ? 'Tentang Morela' : 'About Morela'}</span>
              </button>

              <button
                onClick={() => setCurrentView('events')}
                className="px-6 py-3 rounded-xl bg-amber-600/90 hover:bg-amber-500 text-white font-semibold text-sm transition-all shadow-md backdrop-blur-sm"
              >
                <span>{language === 'id' ? 'Agenda & Kegiatan' : 'Agenda & Events'}</span>
              </button>
            </div>

            {/* Quick Search Strip */}
            <div className="mt-10 max-w-xl">
              <div className="relative group">
                <input
                  type="text"
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  placeholder={
                    language === 'id'
                      ? 'Cari pantai, air toska, benteng, atau tradisi Morela...'
                      : 'Search beaches, turquoise coves, heritage, or events...'
                  }
                  className="w-full pl-11 pr-24 py-3.5 bg-stone-900/50 hover:bg-stone-900/80 border border-stone-700/80 rounded-xl text-white placeholder-stone-400 text-xs sm:text-sm focus:outline-none focus:border-emerald-500 focus:bg-stone-900/90 backdrop-blur-md shadow-xl transition-all"
                />
                <Search className="w-4 h-4 text-emerald-500 absolute left-4 top-1/2 -translate-y-1/2" />
                {localSearch && (
                  <button
                    onClick={() => setLocalSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-white px-2 py-1 bg-stone-800 rounded"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right / Infographic Panel */}
          <div className="hidden lg:block w-full max-w-sm shrink-0">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/20 blur-3xl rounded-full" />
              <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-amber-500/20 blur-3xl rounded-full" />
              
              <div className="relative z-10">
                <h3 className="text-white font-serif text-lg font-bold mb-5 flex items-center gap-2">
                  <Compass className="w-5 h-5 text-emerald-400" />
                  {language === 'id' ? 'Sekilas Morela' : 'Morela at a Glance'}
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-stone-900/40 border border-white/10 hover:bg-stone-900/60 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                      <Waves className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider">Topografi</div>
                      <div className="text-sm text-stone-100 font-medium">Pesisir & Teluk Toska</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-stone-900/40 border border-white/10 hover:bg-stone-900/60 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                      <Landmark className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider">Ikon Budaya</div>
                      <div className="text-sm text-stone-100 font-medium">Tradisi Pukul Sapu</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-stone-900/40 border border-white/10 hover:bg-stone-900/60 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                      <MapPin className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider">Lokasi</div>
                      <div className="text-sm text-stone-100 font-medium">Leihitu, Maluku Tengah</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-stone-900/40 border border-white/10 hover:bg-stone-900/60 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                      <TreePine className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider">Komoditas</div>
                      <div className="text-sm text-stone-100 font-medium">Cengkeh & Pala</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 📊 2. STATISTIK POTENSI DESA & KUNJUNGAN */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 sm:-mt-12 relative z-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <Compass className="w-6 h-6" />
            </div>
            <div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-stone-900 tabular-nums">
                {destinations.length}
              </div>
              <div className="text-[11px] text-stone-500 uppercase font-medium">
                {language === 'id' ? 'Destinasi Wisata' : 'Destinations'}
              </div>
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-stone-900 tabular-nums">
                {umkmProducts.length}
              </div>
              <div className="text-[11px] text-stone-500 uppercase font-medium">
                {language === 'id' ? 'Produk UMKM' : 'Local Artisans'}
              </div>
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-stone-900 tabular-nums">
                {news.length}
              </div>
              <div className="text-[11px] text-stone-500 uppercase font-medium">
                {language === 'id' ? 'Warta Desa' : 'News Articles'}
              </div>
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <Eye className="w-6 h-6" />
            </div>
            <div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-stone-900 tabular-nums">
                {webVisits.toLocaleString('id-ID')}
              </div>
              <div className="text-[11px] text-stone-500 uppercase font-medium">
                {language === 'id' ? 'Kunjungan Portal' : 'Web Visitors'}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 🌊 3. DESTINASI UNGGULAN & FILTER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              {language === 'id' ? 'Pesona Bahari & Alam Leihitu' : 'Coastal & Nature Charms'}
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              {language === 'id' ? 'Destinasi Unggulan Morela' : 'Featured Destinations in Morela'}
            </h2>
          </div>

          <button
            onClick={() => setCurrentView('destinations')}
            className="text-xs sm:text-sm font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 group self-start md:self-auto"
          >
            <span>{language === 'id' ? 'Lihat Semua Destinasi' : 'View All Destinations'}</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Destination Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {displayedDestinations.map((dest) => (
            <div
              key={dest.id}
              className="group bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Visual Image with Category & QR Trigger */}
                <div className="relative h-52 w-full overflow-hidden bg-stone-100">
                  <img
                    src={dest.imageUrl}
                    alt={dest.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />
                  
                  {/* Category unboxed tag on top-left */}
                  <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                    {dest.category.replace('_', ' ')}
                  </div>

                  {/* QR button top-right */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setQrModalItem({
                        title: dest.name,
                        subtitle: dest.location,
                        code: dest.slug,
                        type: 'destinasi',
                      });
                    }}
                    className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/90 text-stone-800 hover:bg-white hover:text-emerald-700 shadow-sm transition-colors"
                    title="QR Code"
                  >
                    <QrCode className="w-4 h-4" />
                  </button>

                  {/* Price Tag on Bottom Right */}
                  <div className="absolute bottom-3 right-3 bg-emerald-800/90 backdrop-blur-xs text-white text-xs font-mono font-semibold px-2.5 py-1 rounded-md">
                    {dest.ticketPrice}
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs text-stone-500">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{dest.location}</span>
                  </div>

                  <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-emerald-800 transition-colors">
                    {language === 'id' ? dest.name : dest.nameEn}
                  </h3>

                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {language === 'id' ? dest.tagline : dest.taglineEn}
                  </p>
                </div>
              </div>

              {/* Card Footer Action */}
              <div className="px-5 pb-5 pt-2 border-t border-stone-100 flex items-center justify-between">
                <button
                  onClick={() => setSelectedDestination(dest)}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl bg-stone-50 hover:bg-emerald-700 hover:text-white text-stone-800 text-xs font-semibold transition-all group-hover:bg-emerald-700 group-hover:text-white"
                >
                  <span>{language === 'id' ? 'Lihat Destinasi →' : 'View Destination →'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 🏛️ 4. BUDAYA & TRADISI PUKUL SAPU SPOTLIGHT */}
      <section className="bg-stone-900 text-stone-100 py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest">
                <Sparkles className="w-4 h-4" />
                <span>{language === 'id' ? 'Warisan Leluhur Maluku' : 'Ancestral Maluku Heritage'}</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white tracking-tight leading-snug">
                {language === 'id'
                  ? 'Atraksi Pukul Sapu: Simbol Persaudaraan Sejati Tanpa Dendam'
                  : 'The Sacred Pukul Sapu: Eternal Fraternity of Morela'}
              </h2>

              <p className="text-sm text-stone-300 leading-relaxed font-light">
                {language === 'id'
                  ? 'Diselenggarakan setiap 7 Syawal setelah Idul Fitri, para pemuda Negeri Morela saling menyabetkan lidi pohon enau pilihan. Tidak ada rasa dendam, melainkan kobaran semangat persaudaraan dan ketahanan jiwa yang disembuhkan dengan minyak pusaka berkhasiat tinggi warisan leluhur.'
                  : 'Enacted annually on the 7th of Shawwal, youth from Negeri Morela demonstrate physical endurance and kinship through ceremonial broom whips, healed naturally with heirloom herbal oils.'}
              </p>

              <div className="grid grid-cols-2 gap-3 text-xs text-stone-300">
                <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                  <div className="font-semibold text-amber-400 text-sm">7 Syawal</div>
                  <div className="text-[11px] text-stone-400 mt-0.5">Waktu Pelaksanaan Adat</div>
                </div>
                <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                  <div className="font-semibold text-amber-400 text-sm">WBTb Nasional</div>
                  <div className="text-[11px] text-stone-400 mt-0.5">Warisan Budaya Takbenda</div>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  onClick={() => setCurrentView('culture')}
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2"
                >
                  <span>{language === 'id' ? 'Buka Arsip Budaya Morela' : 'Open Cultural Archive'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Visual Cultural Card */}
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-stone-800 bg-stone-950">
              <img
                src="https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1000&q=80"
                alt="Pukul Sapu Morela Tradition"
                className="w-full h-80 sm:h-96 object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 text-stone-200 text-xs">
                <div className="font-serif text-lg font-bold text-white">
                  Ukuwala Mahiate (Tradisi Pukul Sapu)
                </div>
                <p className="text-[11px] text-stone-400 mt-1">
                  Lapangan Upacara Adat Negeri Morela, Leihitu, Maluku Tengah
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 🛍️ 5. UMKM & EKONOMI KREATIF PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              {language === 'id' ? 'Ekonomi Kreatif Warga' : 'Artisanal Economy'}
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              {language === 'id' ? 'Produk Olahan & Kerajinan Morela' : 'Local Artisan Products & Crafts'}
            </h2>
          </div>

          <button
            onClick={() => setCurrentView('umkm')}
            className="text-xs sm:text-sm font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 group self-start md:self-auto"
          >
            <span>{language === 'id' ? 'Kunjungi Katalog UMKM' : 'Visit Full Marketplace'}</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredUMKM.map((prod) => (
            <div
              key={prod.id}
              className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="relative h-44 w-full bg-stone-100 overflow-hidden">
                  <img
                    src={prod.imageUrl}
                    alt={prod.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-stone-900/80 text-white text-[10px] font-semibold px-2 py-0.5 rounded uppercase">
                    {prod.category.replace('_', ' ')}
                  </div>
                </div>

                <div className="p-4 space-y-1.5">
                  <div className="text-[11px] text-stone-500 font-medium">
                    {prod.sellerGroup}
                  </div>
                  <h4 className="font-serif font-bold text-stone-900 text-sm line-clamp-1 group-hover:text-emerald-800 transition-colors">
                    {language === 'id' ? prod.name : prod.nameEn}
                  </h4>
                  <div className="font-mono text-base font-bold text-emerald-700 tabular-nums">
                    {prod.priceFormatted}
                    <span className="text-[10px] text-stone-500 font-sans font-normal ml-1">/{prod.unit}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 pt-0">
                <button
                  onClick={() => setSelectedProduct(prod)}
                  className="w-full py-2 bg-stone-100 hover:bg-emerald-700 hover:text-white text-stone-800 rounded-xl text-xs font-semibold transition-colors"
                >
                  {language === 'id' ? 'Lihat Produk' : 'View Product'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 📅 6. AGENDA & 📰 BERITA MORELA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          
          {/* Agenda & Event */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                  {language === 'id' ? 'Kalender Kegiatan' : 'Upcoming Calendar'}
                </div>
                <h3 className="font-serif text-2xl font-bold text-stone-900">
                  {language === 'id' ? 'Agenda & Event Desa' : 'Village Agenda & Events'}
                </h3>
              </div>
              <button
                onClick={() => setCurrentView('events')}
                className="text-xs font-semibold text-emerald-700 hover:underline"
              >
                {language === 'id' ? 'Semua Agenda →' : 'All Events →'}
              </button>
            </div>

            <div className="space-y-4">
              {upcomingEvents.map((evt) => (
                <div
                  key={evt.id}
                  className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row gap-4 items-start justify-between"
                >
                  <div className="space-y-1.5 flex-1">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 uppercase">
                      {evt.category}
                    </span>
                    <h4 className="font-serif font-bold text-stone-900 text-base">
                      {language === 'id' ? evt.title : evt.titleEn}
                    </h4>
                    <p className="text-xs text-stone-600 line-clamp-2">
                      {language === 'id' ? evt.description : evt.descriptionEn}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-stone-500 pt-1">
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-stone-400" />
                        {evt.date}
                      </span>
                      <span>·</span>
                      <span className="truncate">{evt.location}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Berita Terkini */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                  {language === 'id' ? 'Warta Komunitas' : 'Village Dispatch'}
                </div>
                <h3 className="font-serif text-2xl font-bold text-stone-900">
                  {language === 'id' ? 'Berita & Publikasi Terkini' : 'Latest News & Articles'}
                </h3>
              </div>
              <button
                onClick={() => setCurrentView('news')}
                className="text-xs font-semibold text-emerald-700 hover:underline"
              >
                {language === 'id' ? 'Semua Berita →' : 'All News →'}
              </button>
            </div>

            <div className="space-y-4">
              {latestNews.map((article) => (
                <div
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 cursor-pointer transition-all flex items-center gap-4 group"
                >
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-stone-100 shrink-0">
                    <img
                      src={article.imageUrl}
                      alt={article.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="text-[10px] text-stone-400 font-mono">
                      {article.publishedDate} · {article.readTime}
                    </div>
                    <h4 className="font-serif font-bold text-stone-900 text-sm group-hover:text-emerald-800 transition-colors line-clamp-2">
                      {language === 'id' ? article.title : article.titleEn}
                    </h4>
                    <p className="text-xs text-stone-500 line-clamp-1">
                      {language === 'id' ? article.summary : article.summaryEn}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 🎓 7. BANNER PENGABDIAN UNIVERSITAS DARUSSALAM AMBON */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-stone-900 text-white relative overflow-hidden shadow-xl border border-emerald-700/40">
          <div className="max-w-2xl space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-300">
              <Award className="w-4 h-4" />
              <span>PROGRAM PENGABDIAN MASYARAKAT</span>
            </div>
            
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Universitas Darussalam Ambon
            </h3>

            <p className="text-xs sm:text-sm text-stone-200 font-light leading-relaxed">
              {language === 'id'
                ? '“Digitalisasi Potensi Pariwisata dan Ekonomi Kreatif Desa Morela” — Sinergi civitas akademika, mahasiswa KKN, Pemerintah Negeri Morela, dan Pokdarwis dalam mewujudkan desa wisata berdaya saing global.'
                : '“Digitalization of Morela Village Tourism & Creative Economy” — Academic synergy between UNIDAR students, village government, and customary tourism leaders.'}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => setCurrentView('program')}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded-xl text-xs transition-colors shadow-md"
              >
                {language === 'id' ? 'Lihat Tim & Hasil Pengabdian' : 'View Team & Outcomes'}
              </button>

              <button
                onClick={() => setCurrentView('map')}
                className="px-5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-medium rounded-xl text-xs transition-colors border border-white/20"
              >
                {language === 'id' ? 'Buka Peta Wisata Interaktif' : 'Explore Interactive Map'}
              </button>
            </div>
          </div>

          <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 opacity-10 pointer-events-none hidden lg:block">
            <Compass className="w-96 h-96 text-white" />
          </div>
        </div>
      </section>

    </div>
  );
};
