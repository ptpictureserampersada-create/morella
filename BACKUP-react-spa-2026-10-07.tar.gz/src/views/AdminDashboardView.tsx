import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { compressImage } from '../utils/imageUtils';
import { Destination, UMKMProduct, NewsArticle, EventItem, CultureItem, GalleryPhoto, UserRole, TicketBooking } from '../types';
import {
  Shield,
  LayoutDashboard,
  Compass,
  ShoppingBag,
  BookOpen,
  Calendar,
  Image as ImageIcon,
  Landmark,
  MapPin,
  Users,
  Settings,
  Plus,
  Trash2,
  Edit2,
  QrCode,
  Eye,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Search,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  BarChart3,
  X,
  Ticket,
  Printer,
  DollarSign
} from 'lucide-react';

export const AdminDashboardView: React.FC = () => {
  const {
    destinations,
    addDestination,
    updateDestination,
    deleteDestination,
    umkmProducts,
    addUMKM,
    updateUMKM,
    deleteUMKM,
    news,
    addNews,
    updateNews,
    deleteNews,
    events,
    addEvent,
    updateEvent,
    deleteEvent,
    cultureItems,
    addCulture,
    updateCulture,
    deleteCulture,
    gallery,
    addGalleryPhoto,
    deleteGalleryPhoto,
    ticketBookings,
    updateTicketBookingStatus,
    checkInTicket,
    setSelectedTicketForPrint,
    team,
    userRole,
    setUserRole,
    webVisits,
    setQrModalItem,
    resetToDefaults,
    setCurrentView,
    language,
    paymentSettings,
    updatePaymentSettings,
    heroSliders,
    updateHeroSliders,
    contactInfo,
    updateContactInfo,
    heroText,
    updateHeroText
  } = useTourism();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [checkInCode, setCheckInCode] = useState<string>('');
  const [checkInMsg, setCheckInMsg] = useState<{ text: string; success: boolean } | null>(null);

  // Modals for CRUD additions
  const [isAddDestModalOpen, setIsAddDestModalOpen] = useState(false);
  const [isAddUMKMModalOpen, setIsAddUMKMModalOpen] = useState(false);
  const [isAddNewsModalOpen, setIsAddNewsModalOpen] = useState(false);
  const [isAddEventModalOpen, setIsAddEventModalOpen] = useState(false);
  const [isAddCultureModalOpen, setIsAddCultureModalOpen] = useState(false);
  const [isAddGalleryModalOpen, setIsAddGalleryModalOpen] = useState(false);
  const [isAddTeamModalOpen, setIsAddTeamModalOpen] = useState(false);

  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [tempPaymentSettings, setTempPaymentSettings] = useState(paymentSettings);

  const [isEditingSliders, setIsEditingSliders] = useState(false);
  const [tempSliders, setTempSliders] = useState(heroSliders.join('\n'));

  const [isEditingContact, setIsEditingContact] = useState(false);
  const [tempContact, setTempContact] = useState(contactInfo);

  const [isEditingHeroText, setIsEditingHeroText] = useState(false);
  const [tempHeroText, setTempHeroText] = useState(heroText);

  // Form states for new Destination
  const [newDest, setNewDest] = useState({
    name: '',
    nameEn: '',
    category: 'pantai' as any,
    tagline: '',
    taglineEn: '',
    description: '',
    descriptionEn: '',
    location: 'Negeri Morela, Kec. Leihitu',
    coordinates: { lat: -3.582, lng: 128.084, mapX: 40, mapY: 35 },
    visitingHours: 'Setiap Hari: 07.00 - 18.00 WIT',
    ticketPrice: 'Rp 5.000 / orang',
    ticketPriceNum: 5000,
    facilities: ['Area Parkir', 'Gazebo', 'Toilet'],
    contactName: 'Pokdarwis Desa Morela',
    contactPhone: '+6281234567801',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1000&q=80',
    galleryImages: [],
    featured: true,
    published: true,
  });

  // Form states for new UMKM
  const [newUMKM, setNewUMKM] = useState({
    name: '',
    nameEn: '',
    category: 'kuliner' as any,
    price: 25000,
    priceFormatted: 'Rp 25.000',
    unit: 'Kemasan / Botol',
    sellerName: '',
    sellerGroup: 'Kelompok Usaha Warga Morela',
    sellerPhone: '+6281234567810',
    sellerAddress: 'Negeri Morela, Leihitu',
    description: '',
    descriptionEn: '',
    imageUrl: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=800&q=80',
    featured: true,
    inStock: true,
    published: true,
  });

  // Form states for new News
  const [newArticle, setNewArticle] = useState({
    title: '',
    titleEn: '',
    category: 'desa' as any,
    author: 'Tim Humas Desa Morela',
    authorRole: 'Pengelola Informasi',
    publishedDate: '29 September 2026',
    readTime: '3 menit baca',
    summary: '',
    summaryEn: '',
    content: '',
    contentEn: '',
    imageUrl: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=1000&q=80',
    published: true,
  });
  // Form states for new Culture
  const [newCulture, setNewCulture] = useState({
    title: '',
    titleEn: '',
    category: 'sejarah' as any,
    summary: '',
    summaryEn: '',
    content: '',
    contentEn: '',
    periodOrTime: '',
    historicalSignificance: '',
    imageUrl: 'https://images.unsplash.com/photo-1599839619722-39751411ea63?auto=format&fit=crop&w=1000&q=80',
    tags: [],
    published: true,
  });

  // Form states for new Event
  const [newEvent, setNewEvent] = useState({
    title: '',
    titleEn: '',
    date: '10 Oktober 2026',
    time: '09.00 WIT',
    location: 'Negeri Morela',
    organizer: 'Pemerintah Desa Morela',
    category: 'budaya' as any,
    description: '',
    descriptionEn: '',
    status: 'upcoming' as any,
    imageUrl: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1000&q=80',
    contactPerson: '+6281234567800',
  });

  // Form states for new Gallery
  const [newGallery, setNewGallery] = useState({
    title: '',
    titleEn: '',
    category: 'alam' as any,
    location: 'Negeri Morela',
    photographer: 'Tim Dokumentasi',
    dateTaken: '2026',
    imageUrl: 'https://images.unsplash.com/photo-1599839619722-39751411ea63?auto=format&fit=crop&w=1000&q=80',
  });

  // Form states for new Team
  const [newTeam, setNewTeam] = useState({
    name: '',
    role: 'Mahasiswa KKN',
    department: '',
    university: 'Universitas Darussalam Ambon',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80',
    bio: '',
    contribution: '',
  });

  const handleCreateDestination = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDest.name) return;
    addDestination(newDest);
    setIsAddDestModalOpen(false);
    alert('Destinasi baru berhasil ditambahkan!');
  };

  const handleCreateUMKM = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUMKM.name) return;
    addUMKM(newUMKM);
    setIsAddUMKMModalOpen(false);
    alert('Produk UMKM berhasil ditambahkan!');
  };

  const handleCreateNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArticle.title) return;
    addNews(newArticle);
    setIsAddNewsModalOpen(false);
    alert('Artikel warta berhasil dipublikasikan!');
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEvent.title) return;
    addEvent(newEvent);
    setIsAddEventModalOpen(false);
    alert('Agenda kegiatan berhasil ditambahkan!');
  };

  const handleCreateCulture = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCulture.title) return;
    addCulture(newCulture);
    setIsAddCultureModalOpen(false);
    alert('Naskah budaya berhasil ditambahkan!');
  };

  const handleCreateGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGallery.title) return;
    addGalleryPhoto(newGallery);
    setIsAddGalleryModalOpen(false);
    alert('Foto galeri berhasil ditambahkan!');
  };

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeam.name) return;
    addTeamMember(newTeam);
    setIsAddTeamModalOpen(false);
    alert('Anggota tim berhasil ditambahkan!');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 flex items-center justify-center min-h-[60vh]">
        <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-xl max-w-sm w-full text-center space-y-6">
          <div className="w-16 h-16 mx-auto bg-stone-100 rounded-2xl flex items-center justify-center">
            <Shield className="w-8 h-8 text-stone-700" />
          </div>
          <div>
            <h2 className="font-serif text-2xl font-bold text-stone-900">Akses Terkunci</h2>
            <p className="text-xs text-stone-500 mt-2">Masukkan kata sandi untuk mengakses portal administrasi dan pengelola data.</p>
          </div>
          
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (passwordInput === 'morela') {
                setIsAuthenticated(true);
              } else {
                alert('Kata sandi salah!');
                setPasswordInput('');
              }
            }}
            className="space-y-4"
          >
            <input
              type="password"
              placeholder="Kata Sandi..."
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-center"
              autoFocus
            />
            <button
              type="submit"
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-sm font-semibold transition-colors"
            >
              Masuk Dashboard
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Admin Top Header & Role Switcher */}
      <div className="p-6 bg-stone-900 text-white rounded-3xl border border-stone-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-widest">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>PORTAL ADMINISTRASI & PENGELOLA</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Dashboard Morela Tourism
          </h1>
          <p className="text-xs text-stone-400">
            Kelola konten destinasi wisata, katalog UMKM, arsip kebudayaan, agenda desa, dan data pengabdian mahasiswa.
          </p>
        </div>

        {/* Role Selector */}
        <div className="p-3 bg-stone-800/90 rounded-2xl border border-stone-700/80 space-y-1.5 self-stretch md:self-auto">
          <div className="text-[10px] text-stone-400 uppercase font-semibold">
            Pilih Mode Akses Pengguna (Role):
          </div>
          <div className="flex items-center gap-1 text-xs">
            {[
              { id: 'admin_desa', label: 'Admin Desa' },
              { id: 'mahasiswa', label: 'Mahasiswa UNIDAR' },
              { id: 'pengunjung', label: 'Tinjau Pengunjung' },
            ].map((role) => (
              <button
                key={role.id}
                onClick={() => setUserRole(role.id as UserRole)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                  userRole === role.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700'
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-stone-200">
        {[
          { id: 'overview', label: '📊 Dashboard & Statistik', icon: LayoutDashboard },
          { id: 'destinasi', label: '🏝️ Destinasi Wisata', icon: Compass },
          { id: 'tiket', label: '🎫 E-Tiket & Retribusi', icon: Ticket },
          { id: 'umkm', label: '🛍️ UMKM & Produk', icon: ShoppingBag },
          { id: 'berita', label: '📰 Warta & Berita', icon: BookOpen },
          { id: 'agenda', label: '📅 Agenda & Event', icon: Calendar },
          { id: 'budaya', label: '🏛️ Budaya & Tradisi', icon: Landmark },
          { id: 'galeri', label: '📸 Galeri', icon: ImageIcon },
          { id: 'tim', label: '👥 Tim Pengabdian', icon: Users },
          { id: 'pengaturan', label: '⚙️ Pengaturan', icon: Settings },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB CONTENT: 📊 OVERVIEW & STATISTIK */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Top 4 KPI Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[11px] font-semibold uppercase text-stone-500">TOTAL DESTINASI</div>
              <div className="font-mono text-3xl font-bold text-stone-900 tabular-nums">{destinations.length}</div>
              <div className="text-[11px] text-emerald-700 font-medium">100% Aktif & Ber-QR Code</div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[11px] font-semibold uppercase text-stone-500">TOTAL UMKM</div>
              <div className="font-mono text-3xl font-bold text-stone-900 tabular-nums">{umkmProducts.length}</div>
              <div className="text-[11px] text-emerald-700 font-medium">Minyak Kayu Putih, Kenari, Pala</div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[11px] font-semibold uppercase text-stone-500">TOTAL BERITA</div>
              <div className="font-mono text-3xl font-bold text-stone-900 tabular-nums">{news.length}</div>
              <div className="text-[11px] text-stone-500 font-medium">Artikel Warta Desa & KKN</div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[11px] font-semibold uppercase text-stone-500">TOTAL GALERI</div>
              <div className="font-mono text-3xl font-bold text-stone-900 tabular-nums">{gallery.length}</div>
              <div className="text-[11px] text-stone-500 font-medium">Foto Terkurasi Desa</div>
            </div>
          </div>

          {/* Visitor Traffic Chart & Analysis (Matching prompt format) */}
          <div className="p-6 sm:p-8 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-700">
                  <BarChart3 className="w-4 h-4 text-emerald-700" />
                  <span>KUNJUNGAN WEBSITE PORTAL</span>
                </div>
                <h3 className="font-serif text-xl font-bold text-stone-900">
                  Statistik Trafik & Penjelajahan Wisatawan
                </h3>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-right">
                <div className="text-[10px] text-emerald-800 font-semibold uppercase">September 2026</div>
                <div className="font-mono text-2xl font-bold text-emerald-900 tabular-nums">
                  {webVisits.toLocaleString('id-ID')} Hits
                </div>
              </div>
            </div>

            {/* ASCII-styled & Bar visualization matching prompt */}
            <div className="space-y-3 p-4 bg-stone-900 text-stone-100 rounded-xl font-mono text-xs overflow-x-auto">
              <div className="text-stone-400">=== STATISTIK KUNJUNGAN PERIODE Q3 2026 ===</div>
              <div className="flex items-center gap-3">
                <span className="w-24 text-stone-400">Juli 2026</span>
                <div className="flex-1 bg-stone-800 h-4 rounded overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[45%]" />
                </div>
                <span className="w-16 text-right">1.280</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="w-24 text-stone-400">Agustus 2026</span>
                <div className="flex-1 bg-stone-800 h-4 rounded overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[65%]" />
                </div>
                <span className="w-16 text-right">1.940</span>
              </div>
              <div className="flex items-center gap-3 font-bold text-emerald-300">
                <span className="w-24">Sept 2026</span>
                <div className="flex-1 bg-stone-800 h-4 rounded overflow-hidden">
                  <div className="bg-emerald-400 h-full w-[95%]" />
                </div>
                <span className="w-16 text-right">{webVisits.toLocaleString('id-ID')}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-stone-600">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <strong className="text-stone-900">Halaman Terpopuler:</strong> Pantai Lubang Buaya Morela (48% views)
              </div>
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <strong className="text-stone-900">Pencarian Terbanyak:</strong> "Tradisi Pukul Sapu" & "Minyak Kayu Putih"
              </div>
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <strong className="text-stone-900">Perangkat Pengunjung:</strong> Mobile Android 82%, Desktop 18%
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 🏝️ DESTINASI WISATA CRUD */}
      {activeTab === 'destinasi' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Kelola Destinasi Wisata
              </h3>
              <p className="text-xs text-stone-500">
                Tambah, perbarui informasi tiket & jam buka, buat QR Code, atau nonaktifkan destinasi.
              </p>
            </div>

            <button
              onClick={() => setIsAddDestModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Destinasi Baru</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-semibold uppercase text-stone-600">
                  <tr>
                    <th className="px-5 py-3.5">Destinasi</th>
                    <th className="px-5 py-3.5">Kategori</th>
                    <th className="px-5 py-3.5">Tiket</th>
                    <th className="px-5 py-3.5">Status</th>
                    <th className="px-5 py-3.5">QR Code</th>
                    <th className="px-5 py-3.5 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {destinations.map((dest) => (
                    <tr key={dest.id} className="hover:bg-stone-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-stone-900 flex items-center gap-3">
                        <img
                          src={dest.imageUrl}
                          alt={dest.name}
                          className="w-10 h-10 rounded-lg object-cover bg-stone-100"
                        />
                        <div>
                          <div>{dest.name}</div>
                          <div className="text-[10px] text-stone-400 font-normal truncate max-w-[200px]">
                            {dest.location}
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 capitalize">{dest.category.replace('_', ' ')}</td>
                      <td className="px-5 py-3.5 font-mono">{dest.ticketPrice}</td>
                      <td className="px-5 py-3.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          dest.published ? 'bg-emerald-50 text-emerald-700' : 'bg-stone-100 text-stone-600'
                        }`}>
                          {dest.published ? 'Publish' : 'Draft'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <button
                          onClick={() => setQrModalItem({
                            title: dest.name,
                            subtitle: dest.location,
                            code: dest.slug,
                            type: 'destinasi',
                          })}
                          className="p-1.5 bg-stone-100 hover:bg-stone-200 rounded-lg text-emerald-700"
                          title="Lihat QR Code"
                        >
                          <QrCode className="w-4 h-4" />
                        </button>
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-2">
                        <button
                          onClick={() => updateDestination(dest.id, { published: !dest.published })}
                          className="px-2.5 py-1 text-[11px] rounded bg-stone-100 hover:bg-stone-200 font-medium"
                        >
                          {dest.published ? 'Sembunyikan' : 'Tayangkan'}
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Yakin ingin menghapus ${dest.name}?`)) {
                              deleteDestination(dest.id);
                            }
                          }}
                          className="p-1 text-rose-600 hover:text-rose-800"
                          title="Hapus Destinasi"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 🎫 E-TIKET & RETRIBUSI CRUD */}
      {activeTab === 'tiket' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Manajemen E-Tiket & Retribusi Desa
              </h3>
              <p className="text-xs text-stone-500">
                Pantau pendapatan tiket masuk, validasi check-in pengunjung di pintu gerbang, dan kelola status pembayaran.
              </p>
            </div>

            <button
              onClick={() => setCurrentView('tickets')}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Buka Formulir Pemesanan Tiket</span>
            </button>
          </div>

          {/* Ticket Financial Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[10px] uppercase font-semibold text-stone-500">TOTAL PENDAPATAN</div>
              <div className="font-mono text-xl font-bold text-emerald-800 tabular-nums">
                Rp {ticketBookings
                  .filter((b) => b.paymentStatus === 'paid' || b.paymentStatus === 'checked_in')
                  .reduce((sum, b) => sum + b.totalAmount, 0)
                  .toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-stone-400">Kas Pokdarwis & Kebersihan</div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[10px] uppercase font-semibold text-stone-500">TIKET TERJUAL</div>
              <div className="font-mono text-xl font-bold text-stone-900 tabular-nums">
                {ticketBookings.length}
              </div>
              <div className="text-[10px] text-stone-400">Total Transaksi Masuk</div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[10px] uppercase font-semibold text-stone-500">SUDAH CHECK-IN</div>
              <div className="font-mono text-xl font-bold text-blue-700 tabular-nums">
                {ticketBookings.filter((b) => b.paymentStatus === 'checked_in').length}
              </div>
              <div className="text-[10px] text-stone-400">Pengunjung di Lokasi</div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
              <div className="text-[10px] uppercase font-semibold text-stone-500">BELUM LUNAS / ON-SITE</div>
              <div className="font-mono text-xl font-bold text-amber-600 tabular-nums">
                {ticketBookings.filter((b) => b.paymentStatus === 'pending').length}
              </div>
              <div className="text-[10px] text-stone-400">Menunggu Bayar di Loket</div>
            </div>
          </div>

          {/* Quick Check-In Barcode Scanner Simulation */}
          <div className="p-5 bg-stone-900 text-white rounded-2xl border border-stone-800 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wide">
              <QrCode className="w-4 h-4" />
              <span>Validasi Check-in Tiket Pengunjung (Pintu Masuk)</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={checkInCode}
                onChange={(e) => setCheckInCode(e.target.value)}
                placeholder="Pindai QR / Ketik Kode Booking (Contoh: MOR-2609-8812)..."
                className="flex-1 px-4 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs font-mono text-white placeholder-stone-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={() => {
                  if (!checkInCode.trim()) return;
                  const success = checkInTicket(checkInCode);
                  if (success) {
                    setCheckInMsg({ text: `Tiket ${checkInCode} berhasil divalidasi Masuk (Checked-In)!`, success: true });
                    setCheckInCode('');
                  } else {
                    setCheckInMsg({ text: `Kode ${checkInCode} tidak ditemukan atau tidak valid.`, success: false });
                  }
                  setTimeout(() => setCheckInMsg(null), 4000);
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl"
              >
                Validasi Check-In
              </button>
            </div>

            {checkInMsg && (
              <div className={`p-3 rounded-xl text-xs font-medium ${
                checkInMsg.success ? 'bg-emerald-950 border border-emerald-500 text-emerald-200' : 'bg-rose-950 border border-rose-500 text-rose-200'
              }`}>
                {checkInMsg.text}
              </div>
            )}
          </div>

          {/* Payment Account Configuration */}
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base">Pengaturan Rekening & QRIS</h4>
                <p className="text-xs text-stone-500">Nomor rekening tujuan pembayaran tiket masuk</p>
              </div>
              <button
                onClick={() => {
                  if (isEditingPayment) {
                    updatePaymentSettings(tempPaymentSettings);
                    setIsEditingPayment(false);
                    alert('Pengaturan rekening & QRIS berhasil disimpan!');
                  } else {
                    setTempPaymentSettings(paymentSettings);
                    setIsEditingPayment(true);
                  }
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${isEditingPayment ? 'bg-emerald-700 hover:bg-emerald-800 text-white' : 'bg-stone-100 hover:bg-stone-200 text-stone-800'}`}
              >
                {isEditingPayment ? 'Simpan Pengaturan' : 'Edit Rekening'}
              </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Rekening BCA</label>
                <input
                  type="text"
                  value={isEditingPayment ? tempPaymentSettings.rekeningBCA : paymentSettings.rekeningBCA}
                  onChange={(e) => setTempPaymentSettings({ ...tempPaymentSettings, rekeningBCA: e.target.value })}
                  disabled={!isEditingPayment}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Rekening Mandiri</label>
                <input
                  type="text"
                  value={isEditingPayment ? tempPaymentSettings.rekeningMandiri : paymentSettings.rekeningMandiri}
                  onChange={(e) => setTempPaymentSettings({ ...tempPaymentSettings, rekeningMandiri: e.target.value })}
                  disabled={!isEditingPayment}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Rekening Bank Maluku</label>
                <input
                  type="text"
                  value={isEditingPayment ? tempPaymentSettings.rekeningMaluku : paymentSettings.rekeningMaluku}
                  onChange={(e) => setTempPaymentSettings({ ...tempPaymentSettings, rekeningMaluku: e.target.value })}
                  disabled={!isEditingPayment}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Link / URL Gambar QRIS</label>
                <input
                  type="text"
                  value={isEditingPayment ? tempPaymentSettings.qrisUrl : paymentSettings.qrisUrl}
                  onChange={(e) => setTempPaymentSettings({ ...tempPaymentSettings, qrisUrl: e.target.value })}
                  disabled={!isEditingPayment}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Bookings Table */}
          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-semibold uppercase text-stone-600">
                  <tr>
                    <th className="px-5 py-3.5">Kode Booking</th>
                    <th className="px-5 py-3.5">Destinasi</th>
                    <th className="px-5 py-3.5">Pengunjung</th>
                    <th className="px-5 py-3.5">Tanggal</th>
                    <th className="px-5 py-3.5">Nominal</th>
                    <th className="px-5 py-3.5">Metode Bayar</th>
                    <th className="px-5 py-3.5">Status</th>
                    <th className="px-5 py-3.5 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {ticketBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-stone-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-mono font-bold text-stone-900">
                        {b.bookingCode}
                      </td>
                      <td className="px-5 py-3.5 font-semibold text-stone-800">
                        {b.destinationName}
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-medium text-stone-900">{b.visitorName}</div>
                        <div className="text-[10px] text-stone-400 font-mono">{b.visitorPhone}</div>
                      </td>
                      <td className="px-5 py-3.5 font-mono text-stone-600">
                        {b.visitDate}
                      </td>
                      <td className="px-5 py-3.5 font-mono font-bold text-emerald-800">
                        Rp {b.totalAmount.toLocaleString('id-ID')}
                      </td>
                      <td className="px-5 py-3.5 uppercase font-mono text-[11px]">
                        {b.paymentMethod.replace('_', ' ')}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                          b.paymentStatus === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : b.paymentStatus === 'checked_in'
                            ? 'bg-blue-100 text-blue-800'
                            : b.paymentStatus === 'cancelled'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {b.paymentStatus === 'paid' ? 'Lunas' : b.paymentStatus === 'checked_in' ? 'Checked-In' : b.paymentStatus === 'cancelled' ? 'Batal' : 'Pending'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1.5 whitespace-nowrap">
                        {b.paymentStatus === 'pending' && (
                          <button
                            onClick={() => updateTicketBookingStatus(b.id, 'paid')}
                            className="px-2 py-1 bg-emerald-700 text-white rounded text-[11px] font-medium"
                            title="Tandai Sudah Bayar"
                          >
                            Set Lunas
                          </button>
                        )}
                        {b.paymentStatus === 'paid' && (
                          <button
                            onClick={() => updateTicketBookingStatus(b.id, 'checked_in')}
                            className="px-2 py-1 bg-blue-700 text-white rounded text-[11px] font-medium"
                            title="Konfirmasi Check-In"
                          >
                            Check-In
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedTicketForPrint(b)}
                          className="p-1 text-stone-600 hover:text-stone-900"
                          title="Cetak E-Tiket"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 🛍️ UMKM CRUD */}
      {activeTab === 'umkm' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Kelola Produk UMKM & Ekonomi Kreatif
              </h3>
              <p className="text-xs text-stone-500">
                Daftarkan produk olahan minyak kayu putih, kenari, sambal, kerajinan tangan, dan kontak penjual.
              </p>
            </div>

            <button
              onClick={() => setIsAddUMKMModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Produk UMKM</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-semibold uppercase text-stone-600">
                  <tr>
                    <th className="px-5 py-3.5">Produk</th>
                    <th className="px-5 py-3.5">Harga</th>
                    <th className="px-5 py-3.5">Pengelola</th>
                    <th className="px-5 py-3.5">Kontak WhatsApp</th>
                    <th className="px-5 py-3.5 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {umkmProducts.map((prod) => (
                    <tr key={prod.id} className="hover:bg-stone-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-stone-900">
                        {prod.name}
                      </td>
                      <td className="px-5 py-3.5 font-mono text-emerald-700 font-bold">{prod.priceFormatted}</td>
                      <td className="px-5 py-3.5 text-stone-600">{prod.sellerGroup}</td>
                      <td className="px-5 py-3.5 font-mono">{prod.sellerPhone}</td>
                      <td className="px-5 py-3.5 text-right space-x-2">
                        <button
                          onClick={() => deleteUMKM(prod.id)}
                          className="p-1 text-rose-600 hover:text-rose-800"
                          title="Hapus Produk"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 📰 BERITA CRUD */}
      {activeTab === 'berita' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Kelola Berita & Publikasi Kegiatan
              </h3>
              <p className="text-xs text-stone-500">
                Tulis artikel perkembangan pariwisata dan catatan pengabdian mahasiswa UNIDAR.
              </p>
            </div>

            <button
              onClick={() => setIsAddNewsModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Tulis Berita Baru</span>
            </button>
          </div>

          <div className="space-y-3">
            {news.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between gap-4"
              >
                <div>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                    {item.category}
                  </span>
                  <h4 className="font-serif font-bold text-stone-900 text-base mt-1">
                    {item.title}
                  </h4>
                  <div className="text-xs text-stone-400 font-mono mt-0.5">
                    {item.publishedDate} · {item.author}
                  </div>
                </div>

                <button
                  onClick={() => deleteNews(item.id)}
                  className="p-2 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Hapus Berita"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: 📅 AGENDA CRUD */}
      {activeTab === 'agenda' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Kelola Agenda & Kalender Acara
              </h3>
              <p className="text-xs text-stone-500">
                Jadwalkan festival Pukul Sapu, lokakarya desa, atau aksi bersih lingkungan.
              </p>
            </div>

            <button
              onClick={() => setIsAddEventModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Acara Baru</span>
            </button>
          </div>

          <div className="space-y-3">
            {events.map((evt) => (
              <div
                key={evt.id}
                className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between gap-4"
              >
                <div>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-800">
                    {evt.category}
                  </span>
                  <h4 className="font-serif font-bold text-stone-900 text-base mt-1">
                    {evt.title}
                  </h4>
                  <div className="text-xs text-stone-500 font-mono mt-0.5">
                    {evt.date} · {evt.location}
                  </div>
                </div>

                <button
                  onClick={() => deleteEvent(evt.id)}
                  className="p-2 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: 🏛️ BUDAYA, 📸 GALERI, 👥 TIM */}
      {activeTab === 'budaya' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <h3 className="font-serif text-xl font-bold text-stone-900">
              Arsip Kebudayaan & Adat Morela ({cultureItems.length} Naskah)
            </h3>
            <button
              onClick={() => setIsAddCultureModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Acara Baru</span>
            </button>
          </div>
          <div className="space-y-3">
            {cultureItems.map((c) => (
              <div key={c.id} className="p-4 bg-white rounded-2xl border border-stone-200 flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase font-semibold text-amber-800">{c.category}</div>
                  <h4 className="font-serif font-bold text-stone-900">{c.title}</h4>
                  <p className="text-xs text-stone-500 line-clamp-1">{c.summary}</p>
                </div>
                <button
                  onClick={() => deleteCulture(c.id)}
                  className="p-2 text-rose-600 hover:text-rose-800"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'galeri' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <h3 className="font-serif text-xl font-bold text-stone-900">
              Koleksi Foto Dokumentasi ({gallery.length} Foto)
            </h3>
            <button
              onClick={() => setIsAddGalleryModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Data Baru</span>
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {gallery.map((g) => (
              <div key={g.id} className="relative rounded-xl overflow-hidden border border-stone-200 group bg-stone-100">
                <img src={g.imageUrl} alt={g.title} className="w-full h-32 object-cover" />
                <div className="p-2 text-[11px] font-semibold truncate bg-white">{g.title}</div>
                <button
                  onClick={() => deleteGalleryPhoto(g.id)}
                  className="absolute top-2 right-2 p-1.5 bg-rose-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'tim' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <h3 className="font-serif text-xl font-bold text-stone-900">
              Tim Pengabdian Mahasiswa UNIDAR Ambon
            </h3>
            <button
              onClick={() => setIsAddTeamModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Data Baru</span>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {team.map((m) => (
              <div key={m.id} className="p-4 bg-white rounded-2xl border border-stone-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img src={m.photoUrl} alt={m.name} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h5 className="font-serif font-bold text-stone-900 text-sm">{m.name}</h5>
                    <div className="text-xs text-emerald-700">{m.role}</div>
                    <div className="text-[11px] text-stone-400">{m.department}</div>
                  </div>
                </div>
                <button
                  onClick={() => deleteTeamMember(m.id)}
                  className="p-2 text-rose-600 hover:text-rose-800"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: ⚙️ PENGATURAN */}
      {activeTab === 'pengaturan' && (
        <div className="p-6 bg-white rounded-2xl border border-stone-200 space-y-6 max-w-2xl">
          <h3 className="font-serif text-xl font-bold text-stone-900">
            Pengaturan & Sinkronisasi Portal
          </h3>

          <div className="space-y-2 text-xs text-stone-600">
            <p>
              Seluruh data yang Anda buat, edit, atau hapus tersimpan secara persisten pada browser lokal (localStorage).
            </p>
          </div>

          <div className="pt-6 border-t border-stone-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-4">
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base">Pengaturan Slider Latar Belakang (Hero)</h4>
                <p className="text-xs text-stone-500">Masukkan link URL atau unggah gambar untuk slider (1 baris untuk 1 gambar)</p>
              </div>
              <div className="flex items-center gap-2">
                {isEditingSliders && (
                  <label className="cursor-pointer px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors">
                    <Plus className="w-4 h-4" />
                    <span>Upload Gambar Lokal</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 1920, 0.7);
                            setTempSliders(prev => {
                              const newText = prev ? prev + '\n' + compressed : compressed;
                              return newText;
                            });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                )}
                <button
                  onClick={() => {
                    if (isEditingSliders) {
                      const newUrls = tempSliders.split('\n').map(url => url.trim()).filter(url => url.length > 0);
                      updateHeroSliders(newUrls);
                      setIsEditingSliders(false);
                      alert('Pengaturan gambar slider berhasil disimpan!');
                    } else {
                      setTempSliders(heroSliders.join('\n'));
                      setIsEditingSliders(true);
                    }
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${isEditingSliders ? 'bg-emerald-700 hover:bg-emerald-800 text-white' : 'bg-stone-100 hover:bg-stone-200 text-stone-800'}`}
                >
                  {isEditingSliders ? 'Simpan Gambar' : 'Edit Gambar'}
                </button>
              </div>
            </div>
            
            <textarea
              value={isEditingSliders ? tempSliders : heroSliders.join('\n')}
              onChange={(e) => setTempSliders(e.target.value)}
              disabled={!isEditingSliders}
              rows={5}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              placeholder="https://... atau klik Upload Gambar Lokal"
            />

            {!isEditingSliders && heroSliders.length > 0 && (
              <div className="mt-3 flex gap-3 overflow-x-auto pb-2">
                {heroSliders.map((url, idx) => (
                  <div key={idx} className="relative shrink-0 group">
                    <img src={url} alt={`Preview ${idx + 1}`} className="w-32 h-20 object-cover rounded-xl border border-stone-200 shadow-sm transition-opacity group-hover:opacity-90" />
                    <div className="absolute top-1 left-1 bg-black/60 text-white text-[10px] px-1.5 rounded-md font-mono">{idx + 1}</div>
                    <button
                      onClick={() => {
                        if (confirm(`Hapus gambar slider ke-${idx + 1}?`)) {
                          const newSliders = [...heroSliders];
                          newSliders.splice(idx, 1);
                          updateHeroSliders(newSliders);
                        }
                      }}
                      className="absolute top-1 right-1 bg-rose-500 text-white p-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-600"
                      title="Hapus Gambar"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-stone-200">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base">Pengaturan Kontak & Alamat</h4>
                <p className="text-xs text-stone-500">Informasi alamat dan nomor kontak yang tampil di bagian Footer website</p>
              </div>
              <button
                onClick={() => {
                  if (isEditingContact) {
                    updateContactInfo(tempContact);
                    setIsEditingContact(false);
                    alert('Informasi kontak berhasil disimpan!');
                  } else {
                    setTempContact(contactInfo);
                    setIsEditingContact(true);
                  }
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${isEditingContact ? 'bg-emerald-700 hover:bg-emerald-800 text-white' : 'bg-stone-100 hover:bg-stone-200 text-stone-800'}`}
              >
                {isEditingContact ? 'Simpan Kontak' : 'Edit Kontak'}
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Alamat Lengkap</label>
                <textarea
                  value={isEditingContact ? tempContact.address : contactInfo.address}
                  onChange={(e) => setTempContact({ ...tempContact, address: e.target.value })}
                  disabled={!isEditingContact}
                  rows={2}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Nomor Telepon / Kontak</label>
                <input
                  type="text"
                  value={isEditingContact ? tempContact.phone : contactInfo.phone}
                  onChange={(e) => setTempContact({ ...tempContact, phone: e.target.value })}
                  disabled={!isEditingContact}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-200">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base">Pengaturan Teks Beranda (Hero)</h4>
                <p className="text-xs text-stone-500">Ubah atau hapus (kosongkan) teks yang muncul di atas gambar slider beranda</p>
              </div>
              <button
                onClick={() => {
                  if (isEditingHeroText) {
                    updateHeroText(tempHeroText);
                    setIsEditingHeroText(false);
                    alert('Pengaturan teks beranda berhasil disimpan!');
                  } else {
                    setTempHeroText(heroText);
                    setIsEditingHeroText(true);
                  }
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${isEditingHeroText ? 'bg-emerald-700 hover:bg-emerald-800 text-white' : 'bg-stone-100 hover:bg-stone-200 text-stone-800'}`}
              >
                {isEditingHeroText ? 'Simpan Teks' : 'Edit Teks'}
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Badge (Label Atas) [ID]</label>
                <input
                  type="text"
                  value={isEditingHeroText ? tempHeroText.badge : heroText.badge}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, badge: e.target.value })}
                  disabled={!isEditingHeroText}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Badge (Label Atas) [EN]</label>
                <input
                  type="text"
                  value={isEditingHeroText ? tempHeroText.badgeEn : heroText.badgeEn}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, badgeEn: e.target.value })}
                  disabled={!isEditingHeroText}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Judul Utama [ID]</label>
                <input
                  type="text"
                  value={isEditingHeroText ? tempHeroText.title : heroText.title}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, title: e.target.value })}
                  disabled={!isEditingHeroText}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Judul Utama [EN]</label>
                <input
                  type="text"
                  value={isEditingHeroText ? tempHeroText.titleEn : heroText.titleEn}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, titleEn: e.target.value })}
                  disabled={!isEditingHeroText}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Tagline [ID]</label>
                <textarea
                  value={isEditingHeroText ? tempHeroText.tagline : heroText.tagline}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, tagline: e.target.value })}
                  disabled={!isEditingHeroText}
                  rows={2}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Tagline [EN]</label>
                <textarea
                  value={isEditingHeroText ? tempHeroText.taglineEn : heroText.taglineEn}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, taglineEn: e.target.value })}
                  disabled={!isEditingHeroText}
                  rows={2}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Deskripsi Singkat [ID]</label>
                <textarea
                  value={isEditingHeroText ? tempHeroText.description : heroText.description}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, description: e.target.value })}
                  disabled={!isEditingHeroText}
                  rows={3}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Deskripsi Singkat [EN]</label>
                <textarea
                  value={isEditingHeroText ? tempHeroText.descriptionEn : heroText.descriptionEn}
                  onChange={(e) => setTempHeroText({ ...tempHeroText, descriptionEn: e.target.value })}
                  disabled={!isEditingHeroText}
                  rows={3}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs disabled:bg-stone-50 disabled:text-stone-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-200">
            <button
              onClick={() => {
                if (confirm('Apakah Anda yakin ingin mengatur ulang seluruh data kembali ke data contoh bawaan?')) {
                  resetToDefaults();
                  alert('Data telah dikembalikan ke kondisi awal (default seeder)!');
                }
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-semibold transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Kembalikan Seluruh Data ke Default (Reset)</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Destinasi */}
      {isAddDestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Destinasi Baru</h3>
              <button onClick={() => setIsAddDestModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateDestination} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Destinasi</label>
                <input
                  type="text"
                  required
                  value={newDest.name}
                  onChange={(e) => setNewDest({ ...newDest, name: e.target.value })}
                  placeholder="Contoh: Pantai Pasir Putih Morela"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Kategori</label>
                  <select
                    value={newDest.category}
                    onChange={(e) => setNewDest({ ...newDest, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  >
                    <option value="pantai">Pantai</option>
                    <option value="alam">Wisata Alam</option>
                    <option value="pemandangan">Spot Pemandangan</option>
                    <option value="religi_sejarah">Wisata Religi & Sejarah</option>
                    <option value="budaya">Budaya & Tradisi</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Harga Tiket</label>
                  <input
                    type="text"
                    value={newDest.ticketPrice}
                    onChange={(e) => setNewDest({ ...newDest, ticketPrice: e.target.value })}
                    placeholder="Rp 5.000 / orang"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Tagline Singkat</label>
                <input
                  type="text"
                  value={newDest.tagline}
                  onChange={(e) => setNewDest({ ...newDest, tagline: e.target.value })}
                  placeholder="Pemandangan pesisir menawan dengan air jernih"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Deskripsi Lengkap</label>
                <textarea
                  rows={3}
                  value={newDest.description}
                  onChange={(e) => setNewDest({ ...newDest, description: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto Sampul</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 1000, 0.7);
                            setNewDest({ ...newDest, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newDest.imageUrl}
                  onChange={(e) => setNewDest({ ...newDest, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddDestModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan & Buat QR Code
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Tambah UMKM */}
      {isAddUMKMModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Produk UMKM</h3>
              <button onClick={() => setIsAddUMKMModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateUMKM} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Produk</label>
                <input
                  type="text"
                  required
                  value={newUMKM.name}
                  onChange={(e) => setNewUMKM({ ...newUMKM, name: e.target.value })}
                  placeholder="Contoh: Minyak Kayu Putih Murni 100ml"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Harga Format</label>
                  <input
                    type="text"
                    value={newUMKM.priceFormatted}
                    onChange={(e) => setNewUMKM({ ...newUMKM, priceFormatted: e.target.value })}
                    placeholder="Rp 35.000"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Satuan</label>
                  <input
                    type="text"
                    value={newUMKM.unit}
                    onChange={(e) => setNewUMKM({ ...newUMKM, unit: e.target.value })}
                    placeholder="Botol 100ml / Box"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Penjual & Kelompok</label>
                <input
                  type="text"
                  value={newUMKM.sellerName}
                  onChange={(e) => setNewUMKM({ ...newUMKM, sellerName: e.target.value })}
                  placeholder="Nama Pengrajin / Penanggung Jawab"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nomor WhatsApp</label>
                <input
                  type="text"
                  value={newUMKM.sellerPhone}
                  onChange={(e) => setNewUMKM({ ...newUMKM, sellerPhone: e.target.value })}
                  placeholder="+6281234567810"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto Produk</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewUMKM({ ...newUMKM, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newUMKM.imageUrl}
                  onChange={(e) => setNewUMKM({ ...newUMKM, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddUMKMModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan Produk
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Berita */}
      {isAddNewsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tulis Berita / Warta Baru</h3>
              <button onClick={() => setIsAddNewsModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateNews} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Judul Berita</label>
                <input
                  type="text"
                  required
                  value={newArticle.title}
                  onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                  placeholder="Judul artikel berita..."
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Ringkasan (1-2 Kalimat)</label>
                <input
                  type="text"
                  value={newArticle.summary}
                  onChange={(e) => setNewArticle({ ...newArticle, summary: e.target.value })}
                  placeholder="Ringkasan warta..."
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Isi Berita</label>
                <textarea
                  rows={4}
                  value={newArticle.content}
                  onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto Berita</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewArticle({ ...newArticle, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newArticle.imageUrl}
                  onChange={(e) => setNewArticle({ ...newArticle, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddNewsModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Tayangkan Berita
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Agenda */}
      {isAddEventModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Agenda Kegiatan</h3>
              <button onClick={() => setIsAddEventModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Acara</label>
                <input
                  type="text"
                  required
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Tanggal</label>
                  <input
                    type="text"
                    value={newEvent.date}
                    onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Lokasi</label>
                  <input
                    type="text"
                    value={newEvent.location}
                    onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Deskripsi Singkat</label>
                <textarea
                  rows={3}
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto Agenda</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewEvent({ ...newEvent, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newEvent.imageUrl}
                  onChange={(e) => setNewEvent({ ...newEvent, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddEventModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan Acara
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: Tambah Culture */}
      {isAddCultureModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Naskah Budaya</h3>
              <button onClick={() => setIsAddCultureModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateCulture} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Judul Naskah / Acara</label>
                <input
                  type="text"
                  required
                  value={newCulture.title}
                  onChange={(e) => setNewCulture({ ...newCulture, title: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Kategori</label>
                <select
                  value={newCulture.category}
                  onChange={(e) => setNewCulture({ ...newCulture, category: e.target.value as any })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                >
                  <option value="sejarah">Sejarah</option>
                  <option value="tradisi">Tradisi</option>
                  <option value="kesenian">Kesenian</option>
                  <option value="kuliner">Kuliner</option>
                  <option value="cerita_rakyat">Cerita Rakyat</option>
                  <option value="tokoh">Tokoh</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Ringkasan</label>
                <input
                  type="text"
                  value={newCulture.summary}
                  onChange={(e) => setNewCulture({ ...newCulture, summary: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>
              
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Konten Lengkap</label>
                <textarea
                  rows={4}
                  value={newCulture.content}
                  onChange={(e) => setNewCulture({ ...newCulture, content: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto Naskah</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewCulture({ ...newCulture, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newCulture.imageUrl}
                  onChange={(e) => setNewCulture({ ...newCulture, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddCultureModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan Naskah
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: Tambah Galeri */}
      {isAddGalleryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Foto Galeri</h3>
              <button onClick={() => setIsAddGalleryModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateGallery} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Judul Foto</label>
                <input
                  type="text"
                  required
                  value={newGallery.title}
                  onChange={(e) => setNewGallery({ ...newGallery, title: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Kategori</label>
                <select
                  value={newGallery.category}
                  onChange={(e) => setNewGallery({ ...newGallery, category: e.target.value as any })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                >
                  <option value="alam">Alam & Lingkungan</option>
                  <option value="budaya">Budaya & Tradisi</option>
                  <option value="masyarakat">Sosial Masyarakat</option>
                  <option value="pengabdian">Pengabdian KKN</option>
                  <option value="wisata">Pariwisata</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Lokasi</label>
                <input
                  type="text"
                  value={newGallery.location}
                  onChange={(e) => setNewGallery({ ...newGallery, location: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto (Link)</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewGallery({ ...newGallery, imageUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newGallery.imageUrl}
                  onChange={(e) => setNewGallery({ ...newGallery, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddGalleryModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan Foto
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Tim */}
      {isAddTeamModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 text-stone-900 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="font-serif font-bold text-lg">Tambah Anggota Tim</h3>
              <button onClick={() => setIsAddTeamModalOpen(false)}>
                <X className="w-5 h-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleCreateTeam} className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Lengkap</label>
                <input
                  type="text"
                  required
                  value={newTeam.name}
                  onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Peran / Jabatan</label>
                  <input
                    type="text"
                    value={newTeam.role}
                    onChange={(e) => setNewTeam({ ...newTeam, role: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Fakultas / Jurusan</label>
                  <input
                    type="text"
                    value={newTeam.department}
                    onChange={(e) => setNewTeam({ ...newTeam, department: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>
              </div>
              
              <div>
                <label className="font-semibold text-stone-700 flex justify-between items-center mb-1">
                  <span>URL Foto (Link)</span>
                  <label className="cursor-pointer text-[10px] bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded text-stone-700 font-medium transition-colors">
                    Upload Lokal
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const compressed = await compressImage(file, 800, 0.7);
                            setNewTeam({ ...newTeam, photoUrl: compressed });
                          } catch (err) {
                            console.error(err);
                            alert('Gagal memproses gambar');
                          }
                        }
                      }}
                    />
                  </label>
                </label>
                <input
                  type="text"
                  value={newTeam.photoUrl}
                  onChange={(e) => setNewTeam({ ...newTeam, photoUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-[11px]"
                  placeholder="https://... atau klik Upload Lokal"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddTeamModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold"
                >
                  Simpan Anggota
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
