import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { Calendar, Clock, MapPin, Phone, User, CheckCircle2, AlertCircle } from 'lucide-react';

export const EventsView: React.FC = () => {
  const { events, language } = useTourism();
  const [filter, setFilter] = useState<string>('all');

  const filtered = filter === 'all'
    ? events
    : events.filter((e) => e.status === filter || e.category === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Kalender Kegiatan & Perayaan' : 'Community Calendar & Celebrations'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Agenda & Event Desa Morela' : 'Events & Agenda in Morela'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Pantau jadwal upacara adat sakral tahunan, kegiatan kolaborasi pengabdian mahasiswa Universitas Darussalam Ambon, pelatihan desa, dan festival seni pesisir Leihitu.'
            : 'Stay informed regarding sacred annual cultural ceremonies, UNIDAR academic community engagements, conservation drives, and youth cultural festivals.'}
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-stone-200">
        {[
          { id: 'all', label: language === 'id' ? 'Semua Agenda' : 'All Events' },
          { id: 'upcoming', label: language === 'id' ? 'Akan Datang' : 'Upcoming' },
          { id: 'budaya', label: language === 'id' ? 'Adat & Budaya' : 'Culture' },
          { id: 'pengabdian', label: language === 'id' ? 'Pengabdian Mahasiswa' : 'Community Service' },
          { id: 'completed', label: language === 'id' ? 'Telah Terlaksana' : 'Completed' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={`px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap border-b-2 -mb-[2px] ${
              filter === tab.id
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Events List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
        {filtered.map((evt) => (
          <div
            key={evt.id}
            className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                <img
                  src={evt.imageUrl}
                  alt={evt.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                  {evt.category}
                </div>

                <div className={`absolute top-3 right-3 text-[10px] font-semibold uppercase px-2.5 py-1 rounded-md shadow-xs ${
                  evt.status === 'upcoming'
                    ? 'bg-emerald-600 text-white'
                    : evt.status === 'ongoing'
                    ? 'bg-amber-500 text-white'
                    : 'bg-stone-600 text-white'
                }`}>
                  {evt.status === 'upcoming' ? 'Akan Datang' : evt.status === 'ongoing' ? 'Berlangsung' : 'Selesai'}
                </div>
              </div>

              <div className="p-6 space-y-4">
                <div className="space-y-1">
                  <h3 className="font-serif text-xl font-bold text-stone-900 leading-snug">
                    {language === 'id' ? evt.title : evt.titleEn}
                  </h3>
                  <div className="text-xs text-stone-500 font-medium">
                    {language === 'id' ? 'Penyelenggara:' : 'Organizer:'} {evt.organizer}
                  </div>
                </div>

                <div className="space-y-2 text-xs text-stone-600 p-3.5 bg-stone-50 rounded-xl border border-stone-200">
                  <div className="flex items-center gap-2 font-mono">
                    <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{evt.date}</span>
                    <span className="text-stone-400">|</span>
                    <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{evt.time}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="truncate">{evt.location}</span>
                  </div>
                </div>

                <p className="text-xs text-stone-700 leading-relaxed">
                  {language === 'id' ? evt.description : evt.descriptionEn}
                </p>
              </div>
            </div>

            <div className="p-6 pt-0 border-t border-stone-100 flex items-center justify-between text-xs">
              <span className="text-stone-500">
                Kontak Info: <strong className="text-stone-800">{evt.contactPerson}</strong>
              </span>

              <a
                href={`https://wa.me/${evt.contactPerson.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="py-1.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg font-medium transition-colors"
              >
                {language === 'id' ? 'Tanya Panitia' : 'Contact'}
              </a>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
