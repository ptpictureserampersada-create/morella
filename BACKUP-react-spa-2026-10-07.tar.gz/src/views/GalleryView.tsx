import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { Camera, MapPin, Eye, Maximize2 } from 'lucide-react';

export const GalleryView: React.FC = () => {
  const { gallery, setLightboxIndex, language } = useTourism();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: language === 'id' ? 'Semua Foto' : 'All Photos' },
    { id: 'wisata', label: '🏝️ ' + (language === 'id' ? 'Wisata' : 'Tourism') },
    { id: 'alam', label: '📷 ' + (language === 'id' ? 'Alam' : 'Nature') },
    { id: 'budaya', label: '🎭 ' + (language === 'id' ? 'Budaya' : 'Culture') },
    { id: 'masyarakat', label: '👥 ' + (language === 'id' ? 'Masyarakat' : 'Community') },
    { id: 'pengabdian', label: '🎓 ' + (language === 'id' ? 'Pengabdian' : 'University') },
  ];

  const filtered = activeCategory === 'all'
    ? gallery
    : gallery.filter((item) => item.category === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Dokumentasi Visual & Lensa Pesisir' : 'Visual Lens & Documentation'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Galeri Fotografi Desa Morela' : 'Photo Gallery of Morela'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Potret keindahan pantai toska, khidmatnya adat istiadat leluhur, senyum hangat masyarakat pesisir, dan jejak program pengabdian mahasiswa di Jazirah Leihitu.'
            : 'A visual archive capturing turquoise waters, solemn ancestral ceremonies, community daily life, and university community service moments.'}
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-stone-200">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap border-b-2 -mb-[2px] ${
              activeCategory === cat.id
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-stone-500 hover:text-stone-900'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Masonry-like Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filtered.map((photo, index) => {
          // Find real index in global gallery for lightbox
          const realIndex = gallery.findIndex((g) => g.id === photo.id);

          return (
            <div
              key={photo.id}
              onClick={() => setLightboxIndex(realIndex)}
              className="group relative bg-stone-900 rounded-2xl overflow-hidden shadow-xs hover:shadow-lg transition-all cursor-pointer aspect-4/3"
            >
              <img
                src={photo.imageUrl}
                alt={photo.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Top Category Badge */}
              <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase px-2 py-0.5 rounded">
                {photo.category}
              </div>

              {/* Hover Fullscreen Icon */}
              <div className="absolute top-3 right-3 p-1.5 rounded-full bg-white/20 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>

              {/* Bottom Caption */}
              <div className="absolute bottom-3.5 left-3.5 right-3.5 text-white space-y-1">
                <h4 className="font-serif font-bold text-sm leading-tight text-white group-hover:text-emerald-300 transition-colors line-clamp-1">
                  {language === 'id' ? photo.title : photo.titleEn}
                </h4>
                <div className="flex items-center justify-between text-[10px] text-stone-300">
                  <span className="flex items-center gap-1 truncate max-w-[150px]">
                    <MapPin className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span className="truncate">{photo.location}</span>
                  </span>
                  <span className="font-mono text-stone-400">{photo.dateTaken}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 text-center text-xs text-stone-500">
        💡 {language === 'id' ? 'Klik pada foto mana pun untuk membuka tampilan layar penuh (fullscreen lightbox).' : 'Click any photo to open fullscreen high-resolution lightbox.'}
      </div>

    </div>
  );
};
