import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { Search, Calendar, User, Clock, ArrowRight, Tag } from 'lucide-react';

export const NewsView: React.FC = () => {
  const { news, setSelectedArticle, language } = useTourism();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [query, setQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: language === 'id' ? 'Semua Warta' : 'All Articles' },
    { id: 'mahasiswa', label: language === 'id' ? 'Kegiatan Mahasiswa UNIDAR' : 'UNIDAR Students' },
    { id: 'desa', label: language === 'id' ? 'Berita Desa' : 'Village News' },
    { id: 'pariwisata', label: language === 'id' ? 'Pariwisata' : 'Tourism' },
    { id: 'budaya', label: language === 'id' ? 'Budaya' : 'Culture' },
    { id: 'umkm', label: language === 'id' ? 'UMKM' : 'Crafts & Market' },
    { id: 'lingkungan', label: language === 'id' ? 'Lingkungan' : 'Environment' },
  ];

  const filtered = news.filter((item) => {
    const matchCat = activeCategory === 'all' || item.category === activeCategory;
    const matchQuery =
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.summary.toLowerCase().includes(query.toLowerCase()) ||
      item.author.toLowerCase().includes(query.toLowerCase());
    return matchCat && matchQuery;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Publikasi & Kabar Pesisir' : 'Village Dispatches & News'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Warta Desa & Catatan Pengabdian' : 'News & Community Service Dispatches'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Informasi terhangat seputar perkembangan ekowisata Negeri Morela, dokumentasi program pengabdian mahasiswa Universitas Darussalam Ambon, dan inovasi kelompok usaha warga.'
            : 'Latest updates on ecotourism initiatives, community service documentation from UNIDAR Ambon students, and local economic breakthroughs.'}
        </p>
      </div>

      {/* Search and Category Filter */}
      <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-96">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={language === 'id' ? 'Cari judul artikel, topik, penulis...' : 'Search article headlines...'}
              className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="text-xs text-stone-500 font-mono">
            {filtered.length} {language === 'id' ? 'Artikel Terpublikasi' : 'Articles Published'}
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((item) => (
          <article
            key={item.id}
            onClick={() => setSelectedArticle(item)}
            className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute top-3 left-3 bg-stone-900/80 text-white text-[10px] font-semibold uppercase px-2 py-0.5 rounded backdrop-blur-xs">
                  {item.category}
                </div>
              </div>

              <div className="p-5 sm:p-6 space-y-3">
                <div className="flex items-center gap-2 text-[11px] text-stone-400 font-mono">
                  <span>{item.publishedDate}</span>
                  <span>·</span>
                  <span>{item.readTime}</span>
                </div>

                <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-emerald-800 transition-colors leading-snug line-clamp-2">
                  {language === 'id' ? item.title : item.titleEn}
                </h3>

                <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                  {language === 'id' ? item.summary : item.summaryEn}
                </p>
              </div>
            </div>

            <div className="p-5 sm:p-6 pt-0 border-t border-stone-100 flex items-center justify-between text-xs">
              <span className="text-stone-500 text-[11px] truncate max-w-[170px]">
                {item.author}
              </span>
              <span className="text-emerald-700 font-semibold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                <span>{language === 'id' ? 'Baca Selengkapnya' : 'Read'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </article>
        ))}
      </div>

    </div>
  );
};
