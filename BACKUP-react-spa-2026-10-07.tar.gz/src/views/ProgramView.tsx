import React from 'react';
import { useTourism } from '../context/TourismContext';
import {
  Award,
  BookOpen,
  Users,
  Target,
  CheckCircle,
  Building,
  GraduationCap,
  Sparkles,
  ExternalLink,
  HeartHandshake
} from 'lucide-react';

export const ProgramView: React.FC = () => {
  const { team, language, setCurrentView } = useTourism();

  const programPillars = [
    {
      title: 'Pilar 1: Digitalisasi Pariwisata & Media Web Portal',
      titleEn: 'Pillar 1: Digital Tourism & Web Portal Infrastructure',
      desc: 'Pembangunan website resmi terintegrasi "Morela Tourism", penyusunan katalog informasi destinasi, dan implementasi QR Code di titik-titik wisata desa.',
      descEn: 'Development of the integrated Morela Tourism web portal, cataloging tourist spots, and installing on-site QR codes.',
      icon: '🌐',
    },
    {
      title: 'Pilar 2: Pemberdayaan & Rebranding Produk UMKM',
      titleEn: 'Pillar 2: SME Empowerment & Creative Product Rebranding',
      desc: 'Peningkatan standardisasi kemasan higienis minyak kayu putih, pembuatan label resmi halua kenari dan rempah pala, serta pembukaan jalur pemasaran daring.',
      descEn: 'Standardizing hygiene packaging for local eucalyptus oils, designing labels for canarium treats and spices.',
      icon: '🛍️',
    },
    {
      title: 'Pilar 3: Digitalisasi & Pelestarian Arsip Budaya Adat',
      titleEn: 'Pillar 3: Customary Heritage & Cultural Archival Digitization',
      desc: 'Pendokumentasian tradisi sakral Pukul Sapu, sejarah pembentukan negeri adat, wawancara tetua adat dan saniri negeri, serta penulisan narasi dwibahasa.',
      descEn: 'Comprehensive recording of the sacred Pukul Sapu rituals, founding history, and bilingual publication.',
      icon: '🏛️',
    },
    {
      title: 'Pilar 4: Penguatan Kapasitas Pokdarwis & Sadar Lingkungan',
      titleEn: 'Pillar 4: Tourism Awareness & Coastal Preservation',
      desc: 'Lokakarya sadar wisata (sapta pesona) bagi pemuda desa, aksi bersih pantai di Pantai Lubang Buaya, dan pembuatan papan himbauan ramah lingkungan.',
      descEn: 'Hospitality training workshops for village youth, beach cleanups, and eco-guidelines.',
      icon: '🌿',
    },
  ];

  const outcomes = [
    { metric: '1 Portal', label: 'Website Pariwisata Resmi Desa Morela Berbasis Web & Mobile' },
    { metric: '100% QR Code', label: 'Destinasi Wisata Dilengkapi Kode Respons Cepat Pindai' },
    { metric: '6 Produk', label: 'UMKM Didampingi Desain Kemasan & Pemasaran Online' },
    { metric: '30+ Pemuda', label: 'Tergabung dalam Pelatihan Sadar Wisata Digital Pokdarwis' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      
      {/* Hero Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold uppercase tracking-wider">
          <GraduationCap className="w-4 h-4 text-emerald-700" />
          <span>PROGRAM PENGABDIAN MASYARAKAT</span>
        </div>
        
        <h1 className="font-serif text-3xl sm:text-5xl font-bold text-stone-900 tracking-tight leading-tight">
          Universitas Darussalam Ambon
        </h1>

        <div className="p-4 rounded-xl bg-stone-100 border-l-4 border-emerald-600 text-stone-800 text-sm font-medium">
          “Digitalisasi Potensi Pariwisata dan Ekonomi Kreatif Desa Morela, Kecamatan Leihitu, Kabupaten Maluku Tengah”
        </div>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-prose">
          Program kolaborasi terpadu antara civitas akademika Universitas Darussalam Ambon bersama Pemerintah Negeri Morela, Lembaga Adat Saniri Negeri, dan Kelompok Sadar Wisata (Pokdarwis) guna mengoptimalkan potensi bahari dan nilai luhur budaya Morela.
        </p>
      </div>

      {/* Profil Universitas & Mitra Desa */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-6 sm:p-8 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-700">
              <Building className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-stone-900">
                Universitas Darussalam Ambon (UNIDAR)
              </h3>
              <p className="text-xs text-stone-500">
                Lembaga Pendidikan Tinggi Berbasis Keilmuan & Pengabdian di Maluku
              </p>
            </div>
          </div>
          <p className="text-xs text-stone-600 leading-relaxed">
            Sebagai perguruan tinggi terkemuka di Maluku, UNIDAR Ambon senantiasa berkomitmen menjalankan Tri Dharma Perguruan Tinggi, khususnya pengabdian masyarakat yang berorientasi pada pemecahan masalah riil pedesaan pesisir dan pulau-pulau kecil.
          </p>
        </div>

        <div className="p-6 sm:p-8 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-amber-50 text-amber-700">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-stone-900">
                Pemerintah Negeri Adat Morela
              </h3>
              <p className="text-xs text-stone-500">
                Mitra Strategis & Tuan Rumah Program Pengabdian
              </p>
            </div>
          </div>
          <p className="text-xs text-stone-600 leading-relaxed">
            Pemerintah Negeri Morela bersama Bapa Raja, Saniri Negeri, dan Pokdarwis memberikan dukungan penuh terhadap proses riset lapangan, wawancara adat, hingga keberlanjutan pemeliharaan infrastruktur portal pariwisata.
          </p>
        </div>
      </div>

      {/* Program Kerja (4 Pilar) */}
      <div className="space-y-6">
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
            Fokus Rencana Aksi
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
            4 Pilar Program Kerja Pengabdian
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {programPillars.map((p, idx) => (
            <div
              key={idx}
              className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-3"
            >
              <div className="text-3xl">{p.icon}</div>
              <h4 className="font-serif text-lg font-bold text-stone-900">
                {p.title}
              </h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Hasil Kegiatan & Dampak Capaian */}
      <div className="p-8 sm:p-10 rounded-3xl bg-stone-900 text-white space-y-8">
        <div className="space-y-2">
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-widest">
            Milestone & Deliverables
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
            Hasil Capaian Program Pengabdian
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {outcomes.map((o, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-stone-800/80 border border-stone-700/60 space-y-2">
              <div className="font-mono text-2xl font-bold text-emerald-400 tabular-nums">
                {o.metric}
              </div>
              <p className="text-xs text-stone-300 leading-relaxed">
                {o.label}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Tim Pengabdian (Dosen Pembimbing & Mahasiswa) */}
      <div className="space-y-6">
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
            Struktur Personalia
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
            Dosen Pembimbing & Tim Mahasiswa UNIDAR
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {team.map((member) => (
            <div
              key={member.id}
              className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={member.photoUrl}
                    alt={member.name}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-full object-cover border-2 border-emerald-500"
                  />
                  <div>
                    <h4 className="font-serif font-bold text-stone-900 text-sm">
                      {member.name}
                    </h4>
                    <div className="text-xs text-emerald-700 font-medium">
                      {member.role}
                    </div>
                    <div className="text-[11px] text-stone-400">
                      {member.department}
                    </div>
                  </div>
                </div>

                <p className="text-xs text-stone-600 leading-relaxed">
                  {member.bio}
                </p>
              </div>

              <div className="pt-3 border-t border-stone-100 text-[11px] text-stone-500">
                <strong className="text-stone-700">Peran:</strong> {member.contribution}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
