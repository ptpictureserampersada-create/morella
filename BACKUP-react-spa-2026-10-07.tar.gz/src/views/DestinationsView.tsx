import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import {
  Compass,
  MapPin,
  Clock,
  Ticket,
  Search,
  QrCode,
  Waves,
  TreePine,
  Mountain,
  Landmark,
  Sparkles,
  Layers,
  Phone
} from 'lucide-react';

export const DestinationsView: React.FC = () => {
  const {
    destinations,
    setSelectedDestination,
    setQrModalItem,
    language,
    setCurrentView,
  } = useTourism();

  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [query, setQuery] = useState<string>('');

  const publishedDestinations = destinations.filter((d) => d.published);

  const filtered = publishedDestinations.filter((d) => {
    const matchCat = selectedCat === 'all' || d.category === selectedCat;
    const matchText =
      d.name.toLowerCase().includes(query.toLowerCase()) ||
      d.description.toLowerCase().includes(query.toLowerCase()) ||
      d.location.toLowerCase().includes(query.toLowerCase()) ||
      d.tagline.toLowerCase().includes(query.toLowerCase());
    return matchCat && matchText;
  });

  const categories = [
    { id: 'all', label: language === 'id' ? 'Semua Destinasi' : 'All Spots', icon: Layers },
    { id: 'pantai', label: language === 'id' ? 'Pantai' : 'Beaches', icon: Waves },
    { id: 'alam', label: language === 'id' ? 'Wisata Alam' : 'Nature', icon: TreePine },
    { id: 'pemandangan', label: language === 'id' ? 'Spot Pemandangan' : 'Viewpoints', icon: Mountain },
    { id: 'religi_sejarah', label: language === 'id' ? 'Wisata Religi & Sejarah' : 'Historic & Sacred', icon: Landmark },
    { id: 'budaya', label: language === 'id' ? 'Budaya & Tradisi' : 'Culture', icon: Sparkles },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Eksplorasi Pariwisata Leihitu' : 'Leihitu Tourism Exploration'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Destinasi Wisata Desa Morela' : 'Tourist Destinations in Morela'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Temukan pesona pantai pasir putih berair toska, tebing karang alami, perbukitan rempah pala warisan dunia, hingga arena sakral upacara adat persaudaraan.'
            : 'Explore turquoise lagoons, ancient nutmeg agro-forests, dramatic sea cliffs, and sacred ancestral cultural arenas along the northern coast of Ambon island.'}
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          {/* Search box */}
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={language === 'id' ? 'Cari nama pantai, lokasi, fasilitas...' : 'Search destination, facility...'}
              className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="text-xs text-stone-500 font-mono self-end md:self-center">
            {language === 'id' ? `Menampilkan ${filtered.length} dari ${destinations.length} destinasi` : `Showing ${filtered.length} of ${destinations.length} spots`}
          </div>
        </div>

        {/* Category Pills (Functional buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = selectedCat === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCat(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Destinations */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((dest) => (
            <div
              key={dest.id}
              className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Photo showcase with category & QR */}
                <div className="relative h-56 w-full bg-stone-100 overflow-hidden">
                  <img
                    src={dest.imageUrl}
                    alt={dest.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />

                  <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                    {dest.category.replace('_', ' ')}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setQrModalItem({
                        title: dest.name,
                        subtitle: dest.location,
                        code: dest.slug,
                        type: 'destinasi',
                      });
                    }}
                    className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/90 text-stone-800 hover:bg-white hover:text-emerald-700 shadow-sm transition-colors"
                    title="QR Code"
                  >
                    <QrCode className="w-4 h-4" />
                  </button>

                  <div className="absolute bottom-3 right-3 bg-emerald-800/95 backdrop-blur-xs text-white text-xs font-mono font-semibold px-2.5 py-1 rounded-md">
                    {dest.ticketPrice}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 sm:p-6 space-y-3">
                  <div className="flex items-center gap-1.5 text-xs text-stone-500">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{dest.location}</span>
                  </div>

                  <h3 className="font-serif text-xl font-bold text-stone-900 group-hover:text-emerald-800 transition-colors">
                    {language === 'id' ? dest.name : dest.nameEn}
                  </h3>

                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {language === 'id' ? dest.tagline : dest.taglineEn}
                  </p>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-stone-400" />
                      <span className="truncate max-w-[140px]">{dest.visitingHours}</span>
                    </span>
                    <span className="text-emerald-700 font-medium">
                      {dest.contactName.split(' ')[0]}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSelectedDestination(dest)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold transition-colors text-center"
                >
                  {language === 'id' ? 'Lihat Detail' : 'View Details'}
                </button>

                <button
                  onClick={() => setCurrentView('map')}
                  className="py-2.5 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-medium transition-colors text-center"
                >
                  {language === 'id' ? 'Lihat di Peta' : 'On Map'}
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-white rounded-2xl border border-stone-200 space-y-3">
          <p className="text-stone-500 text-sm">
            {language === 'id' ? 'Tidak ada destinasi yang cocok dengan pencarian Anda.' : 'No destinations match your search query.'}
          </p>
          <button
            onClick={() => {
              setQuery('');
              setSelectedCat('all');
            }}
            className="px-4 py-2 bg-stone-900 text-white text-xs rounded-lg"
          >
            {language === 'id' ? 'Reset Pencarian' : 'Reset Filters'}
          </button>
        </div>
      )}
    </div>
  );
};
