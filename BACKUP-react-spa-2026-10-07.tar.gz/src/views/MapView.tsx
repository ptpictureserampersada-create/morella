import React from 'react';
import { useTourism } from '../context/TourismContext';
import { InteractiveMap } from '../components/InteractiveMap';
import { MapPin, Navigation, Compass, Info, Car, Bike, Footprints } from 'lucide-react';

export const MapView: React.FC = () => {
  const { language } = useTourism();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-8">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Navigasi Spasial Desa' : 'Spatial Navigation & Wayfinding'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Peta Wisata & Jelajah Negeri Morela' : 'Explore Morela: Interactive Tourist Map'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Petakan rute perjalanan Anda menyusuri pesisir utara Leihitu. Temukan titik pantai eksotis, lokasi sentra kerajinan minyak kayu putih, warung kuliner tradisional papeda, homestay warga, dan fasilitas umum.'
            : 'Plan your itinerary along the northern Leihitu coastal highway. Locate azure beaches, artisanal eucalyptus oil distilleries, traditional culinary stops, homestays, and municipal amenities.'}
        </p>
      </div>

      {/* Main Interactive Map Component */}
      <InteractiveMap />

      {/* How to Reach Morela (Panduan Rute Wisatawan) */}
      <div className="bg-stone-50 rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6">
        <div className="space-y-1">
          <span className="text-xs font-semibold uppercase tracking-widest text-emerald-800">
            {language === 'id' ? 'Aksesibilitas & Petunjuk Perjalanan' : 'Travel Guide & Accessibility'}
          </span>
          <h3 className="font-serif text-xl font-bold text-stone-900">
            {language === 'id' ? 'Cara Menuju Desa Morela dari Kota Ambon' : 'How to Reach Morela from Ambon City'}
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs text-stone-700">
          <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-stone-900 text-sm">
              <Car className="w-4 h-4 text-emerald-700" />
              <span>{language === 'id' ? 'Kendaraan Pribadi / Rental' : 'Private Car / Rental'}</span>
            </div>
            <p className="leading-relaxed">
              {language === 'id'
                ? 'Jarak tempuh sekitar 32 km dari pusat Kota Ambon melalui jalur Hitu-Leihitu (± 45–60 menit). Jalan beraspal mulus dengan suguhan panorama perbukitan hijau dan pesisir teluk.'
                : 'Approximately 32 km from Ambon City Center via the Hitu-Leihitu coastal route (45–60 mins) along scenic asphalt roads.'}
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-stone-900 text-sm">
              <Bike className="w-4 h-4 text-emerald-700" />
              <span>{language === 'id' ? 'Sepeda Motor / Touring' : 'Motorcycle Touring'}</span>
            </div>
            <p className="leading-relaxed">
              {language === 'id'
                ? 'Sangat direkomendasikan bagi penikmat touring. Angin pesisir sejuk, banyak spot singgah foto di tepi tebing, dan mudah bermanuver ke jalan setapak pantai.'
                : 'Ideal for scenic motorcycling with refreshing sea breezes and multiple cliffside photography lookout points.'}
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-stone-900 text-sm">
              <Compass className="w-4 h-4 text-emerald-700" />
              <span>{language === 'id' ? 'Transportasi Umum / Angkot' : 'Public Minibus (Angkot)'}</span>
            </div>
            <p className="leading-relaxed">
              {language === 'id'
                ? 'Tersedia angkutan pedesaan trayek Ambon - Hitu - Morela dari Terminal Mardika Ambon. Tarif terjangkau (± Rp 15.000 - Rp 20.000 / orang).'
                : 'Local transport minibuses depart regularly from Mardika Terminal Ambon towards Leihitu and Morela at nominal fares.'}
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
