import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import {
  ShoppingBag,
  Search,
  Phone,
  Store,
  QrCode,
  Tag,
  CheckCircle2,
  Table as TableIcon,
  LayoutGrid
} from 'lucide-react';

export const UMKMView: React.FC = () => {
  const {
    umkmProducts,
    setSelectedProduct,
    setQrModalItem,
    language
  } = useTourism();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  const published = umkmProducts.filter((p) => p.published);

  const filtered = published.filter((p) => {
    const matchCat = activeCategory === 'all' || p.category === activeCategory;
    const matchText =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.sellerGroup.toLowerCase().includes(search.toLowerCase()) ||
      p.sellerName.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchText;
  });

  const categories = [
    { id: 'all', label: language === 'id' ? 'Semua Produk' : 'All Products' },
    { id: 'produk_olahan', label: language === 'id' ? 'Minyak & Olahan Rempah' : 'Spice Oils & Extracts' },
    { id: 'kuliner', label: language === 'id' ? 'Kuliner & Camilan' : 'Culinary & Snacks' },
    { id: 'kerajinan', label: language === 'id' ? 'Kerajinan Tangan' : 'Handicrafts' },
  ];

  const handleDirectWhatsApp = (prod: any) => {
    const phone = prod.sellerPhone.replace(/[^0-9]/g, '');
    const message = encodeURIComponent(
      language === 'id'
        ? `Halo ${prod.sellerName} (${prod.sellerGroup}), saya tertarik memesan produk "${prod.name}" (${prod.priceFormatted}/${prod.unit}) yang saya temukan di portal Morela Tourism.`
        : `Hello ${prod.sellerName}, I would like to purchase "${prod.nameEn || prod.name}" from the Morela Tourism marketplace.`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
          {language === 'id' ? 'Pemberdayaan Ekonomi Masyarakat' : 'Community Artisan Market'}
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'UMKM & Produk Kreatif Desa Morela' : 'Local Crafts & Artisans of Morela'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed">
          {language === 'id'
            ? 'Dukung langsung perekonomian kelompok usaha ibu-ibu dan petani Negeri Morela. Dapatkan minyak kayu putih sulingan asli Leihitu, kenari gula aren, olahan pala berkualitas ekspor, dan anyaman lontar etnik.'
            : 'Directly support village home industries and cooperative artisans. Purchase authentic steam-distilled cajuput eucalyptus oil, canarium brittle, nutmeg delicacies, and handwoven crafts.'}
        </p>
      </div>

      {/* Control Strip */}
      <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={language === 'id' ? 'Cari minyak kayu putih, kenari, pala...' : 'Search eucalyptus, nutmeg, crafts...'}
              className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="flex items-center gap-3 self-end md:self-auto">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-stone-100 p-1 rounded-xl">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-500 hover:text-stone-900'
                }`}
                title="Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'table' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-500 hover:text-stone-900'
                }`}
                title="Table View"
              >
                <TableIcon className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-stone-500 font-mono">
              {filtered.length} {language === 'id' ? 'Produk' : 'Items'}
            </div>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filtered.map((prod) => (
            <div
              key={prod.id}
              className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="relative h-52 w-full bg-stone-100 overflow-hidden">
                  <img
                    src={prod.imageUrl}
                    alt={prod.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md">
                    {prod.category.replace('_', ' ')}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setQrModalItem({
                        title: prod.name,
                        subtitle: `${prod.priceFormatted} · ${prod.sellerGroup}`,
                        code: prod.id,
                        type: 'umkm',
                      });
                    }}
                    className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/90 text-stone-800 hover:bg-white hover:text-emerald-700 shadow-sm transition-colors"
                    title="QR Code"
                  >
                    <QrCode className="w-4 h-4" />
                  </button>

                  <div className="absolute bottom-3 right-3 bg-emerald-800/90 backdrop-blur-xs text-white text-xs font-mono font-bold px-2.5 py-1 rounded-md">
                    {prod.priceFormatted}
                  </div>
                </div>

                <div className="p-5 space-y-2">
                  <div className="text-[11px] text-stone-500 font-medium truncate">
                    {prod.sellerGroup}
                  </div>

                  <h3 className="font-serif text-lg font-bold text-stone-900 group-hover:text-emerald-800 transition-colors line-clamp-1">
                    {language === 'id' ? prod.name : prod.nameEn}
                  </h3>

                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {language === 'id' ? prod.description : prod.descriptionEn}
                  </p>

                  <div className="pt-2 flex items-center justify-between text-xs text-stone-500">
                    <span>Satuan: <strong className="text-stone-700">{prod.unit}</strong></span>
                    <span className="flex items-center gap-1 text-emerald-700 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {language === 'id' ? 'Tersedia' : 'In Stock'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: [Lihat Produk] - [Hubungi Penjual] */}
              <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSelectedProduct(prod)}
                  className="py-2.5 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold transition-colors text-center"
                >
                  {language === 'id' ? 'Lihat Produk' : 'View Product'}
                </button>

                <button
                  onClick={() => handleDirectWhatsApp(prod)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{language === 'id' ? 'Hubungi Penjual' : 'Contact Seller'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View matching user prompt format */
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-semibold uppercase tracking-wider text-stone-600">
                <tr>
                  <th className="px-6 py-3.5">{language === 'id' ? 'Produk' : 'Product'}</th>
                  <th className="px-6 py-3.5">{language === 'id' ? 'Kategori' : 'Category'}</th>
                  <th className="px-6 py-3.5">{language === 'id' ? 'Harga' : 'Price'}</th>
                  <th className="px-6 py-3.5">{language === 'id' ? 'Pengelola / Kelompok' : 'Producer Group'}</th>
                  <th className="px-6 py-3.5 text-right">{language === 'id' ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {filtered.map((prod) => (
                  <tr key={prod.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="px-6 py-4 font-semibold text-stone-900 flex items-center gap-3">
                      <img
                        src={prod.imageUrl}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-lg object-cover bg-stone-100"
                      />
                      <div>
                        <div>{language === 'id' ? prod.name : prod.nameEn}</div>
                        <div className="text-[10px] text-stone-400 font-normal">{prod.unit}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 capitalize">{prod.category.replace('_', ' ')}</td>
                    <td className="px-6 py-4 font-mono font-bold text-emerald-700">{prod.priceFormatted}</td>
                    <td className="px-6 py-4 text-stone-600">{prod.sellerGroup}</td>
                    <td className="px-6 py-4 text-right space-x-2">
                      <button
                        onClick={() => setSelectedProduct(prod)}
                        className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg font-medium"
                      >
                        {language === 'id' ? 'Lihat Produk' : 'View'}
                      </button>
                      <button
                        onClick={() => handleDirectWhatsApp(prod)}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold inline-flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3" />
                        <span>{language === 'id' ? 'Hubungi Penjual' : 'Order'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Community Order Assistance Box */}
      <div className="p-6 rounded-2xl bg-emerald-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <h4 className="font-serif text-lg font-bold">
            {language === 'id' ? 'Butuh Pengiriman Paket Oleh-Oleh Jumlah Besar?' : 'Bulk Souvenir Orders & Shipping?'}
          </h4>
          <p className="text-xs text-emerald-200">
            {language === 'id'
              ? 'Posko KKN Mahasiswa UNIDAR dan Koperasi Desa Morela siap membantu pengemasan bingkisan resmi.'
              : 'Village cooperative and UNIDAR community team assist with customized gift boxes and national deliveries.'}
          </p>
        </div>
        <a
          href="https://wa.me/6281234567810?text=Halo%20Admin%20UMKM%20Morela%20Tourism"
          target="_blank"
          rel="noreferrer"
          className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 rounded-xl text-xs font-bold transition-colors whitespace-nowrap"
        >
          {language === 'id' ? 'Konsultasi Pesanan Khusus' : 'Consult Wholesale Order'}
        </a>
      </div>

    </div>
  );
};
