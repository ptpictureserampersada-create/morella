import React, { useState, useEffect } from 'react';
import { useTourism } from '../context/TourismContext';
import { Destination, TicketBooking, PaymentMethod } from '../types';
import {
  Ticket,
  CreditCard,
  QrCode,
  CheckCircle2,
  Calendar,
  Users,
  MapPin,
  Clock,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
  Search,
  Printer,
  Share2,
  Building2,
  Smartphone,
  Info,
  DollarSign
} from 'lucide-react';

export const TicketingView: React.FC = () => {
  const {
    destinations,
    ticketBookings,
    addTicketBooking,
    setSelectedTicketForPrint,
    activeBookingDestination,
    setActiveBookingDestination,
    language
  } = useTourism();

  const [activeTab, setActiveTab] = useState<'pesan' | 'cek' | 'info'>('pesan');
  
  // Selection state
  const availableDestinations = destinations.filter((d) => d.published && d.ticketPriceNum > 0);
  const defaultDest = activeBookingDestination || availableDestinations[0] || destinations[0];
  const [selectedDestId, setSelectedDestId] = useState<string>(defaultDest ? defaultDest.id : '');

  // Form states
  const todayStr = new Date().toISOString().split('T')[0];
  const [visitDate, setVisitDate] = useState<string>(todayStr);
  const [adultCount, setAdultCount] = useState<number>(2);
  const [childCount, setChildCount] = useState<number>(0);
  const [visitorName, setVisitorName] = useState<string>('');
  const [visitorPhone, setVisitorPhone] = useState<string>('');
  const [visitorEmail, setVisitorEmail] = useState<string>('');
  const [visitorCity, setVisitorCity] = useState<string>('Kota Ambon');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('qris');

  // Checkout and simulated payment step
  const [bookingStep, setBookingStep] = useState<'form' | 'payment_pending' | 'success'>('form');
  const [currentBooking, setCurrentBooking] = useState<TicketBooking | null>(null);
  const [paymentTimer, setPaymentTimer] = useState<number>(900); // 15 mins in sec

  // Search booking state
  const [searchBookingCode, setSearchBookingCode] = useState<string>('');
  const [foundBooking, setFoundBooking] = useState<TicketBooking | null>(null);
  const [searchError, setSearchError] = useState<string>('');

  const currentDest = destinations.find((d) => d.id === selectedDestId) || destinations[0];
  const pricePerTicket = currentDest ? currentDest.ticketPriceNum : 5000;
  const cleanlinessFee = 2000;
  const ticketSubtotal = (adultCount * pricePerTicket) + (childCount * Math.round(pricePerTicket * 0.5));
  const grandTotal = ticketSubtotal + cleanlinessFee;

  // Countdown timer for pending QRIS payment
  useEffect(() => {
    let interval: any;
    if (bookingStep === 'payment_pending' && paymentTimer > 0) {
      interval = setInterval(() => {
        setPaymentTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [bookingStep, paymentTimer]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim()) {
      alert(language === 'id' ? 'Silakan masukkan nama lengkap Anda.' : 'Please enter your full name.');
      return;
    }
    if (!visitorPhone.trim()) {
      alert(language === 'id' ? 'Silakan masukkan nomor telepon / WhatsApp.' : 'Please enter your phone number.');
      return;
    }

    const newBooking = addTicketBooking({
      destinationId: currentDest.id,
      destinationName: currentDest.name,
      destinationLocation: currentDest.location,
      visitDate,
      visitorName,
      visitorEmail: visitorEmail || `${visitorName.toLowerCase().replace(/\s+/g, '')}@gmail.com`,
      visitorPhone,
      visitorCity,
      adultCount,
      childCount,
      pricePerTicket,
      cleanlinessFee,
      totalAmount: grandTotal,
      paymentMethod,
      paymentStatus: paymentMethod === 'cash_on_site' ? 'pending' : 'pending',
    });

    setCurrentBooking(newBooking);
    setBookingStep('payment_pending');
    setPaymentTimer(900);
    window.scrollTo({ top: 300, behavior: 'smooth' });
  };

  const handleSimulatePaymentSuccess = () => {
    if (!currentBooking) return;
    const updated = {
      ...currentBooking,
      paymentStatus: 'paid' as any,
      paidAt: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jayapura' }) + ' WIT',
    };
    setCurrentBooking(updated);
    setBookingStep('success');
  };

  const handleSearchTicket = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    setFoundBooking(null);

    const code = searchBookingCode.trim().toUpperCase();
    const matched = ticketBookings.find(
      (b) => b.bookingCode.toUpperCase() === code || b.visitorPhone.includes(code)
    );

    if (matched) {
      setFoundBooking(matched);
    } else {
      setSearchError(
        language === 'id'
          ? 'Tiket dengan Kode Booking tersebut tidak ditemukan. Pastikan format penulisan benar (Contoh: MOR-2609-8812).'
          : 'Booking code not found. Please check and try again.'
      );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      
      {/* Editorial Header */}
      <div className="space-y-3 max-w-3xl">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-emerald-700">
          <Ticket className="w-4 h-4" />
          <span>{language === 'id' ? 'Sistem Pembayaran E-Tiket Resmi' : 'Official E-Ticketing System'}</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight">
          {language === 'id' ? 'Tiket Wisata & Retribusi Desa Morela' : 'Morela Tourism E-Ticketing'}
        </h1>
        <p className="text-sm text-stone-600 leading-relaxed max-w-prose">
          {language === 'id'
            ? 'Pesan tiket masuk wisata Negeri Morela secara online, cepat, dan transparan. Mendukung pembayaran instan melalui QRIS Nasional (Bank Maluku Malut, BCA, BRI, Mandiri, e-Wallet) dan Virtual Account.'
            : 'Book tourist entrance tickets online for Morela destinations with instant cashless payments via QRIS, Virtual Account, or on-site counter payments.'}
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => {
            setActiveTab('pesan');
            setBookingStep('form');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold transition-colors border-b-2 -mb-[2px] whitespace-nowrap ${
            activeTab === 'pesan'
              ? 'border-emerald-700 text-emerald-800'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>{language === 'id' ? 'Pesan Tiket Baru' : 'Book New Ticket'}</span>
        </button>

        <button
          onClick={() => setActiveTab('cek')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold transition-colors border-b-2 -mb-[2px] whitespace-nowrap ${
            activeTab === 'cek'
              ? 'border-emerald-700 text-emerald-800'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>{language === 'id' ? 'Cek Status & Cetak Tiket' : 'Find / Print E-Ticket'}</span>
        </button>

        <button
          onClick={() => setActiveTab('info')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold transition-colors border-b-2 -mb-[2px] whitespace-nowrap ${
            activeTab === 'info'
              ? 'border-emerald-700 text-emerald-800'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Info className="w-4 h-4" />
          <span>{language === 'id' ? 'Daftar Tarif & Regulasi' : 'Tariff & Regulations'}</span>
        </button>
      </div>

      {/* TAB 1: PESAN TIKET ONLINE */}
      {activeTab === 'pesan' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Form Column (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {bookingStep === 'form' && (
              <form onSubmit={handleCreateOrder} className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6">
                
                {/* Step 1: Destination Selection */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-stone-900 uppercase tracking-wide">
                    <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px]">1</span>
                    <span>{language === 'id' ? 'Pilih Destinasi Wisata' : 'Select Destination'}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {availableDestinations.map((dest) => (
                      <div
                        key={dest.id}
                        onClick={() => setSelectedDestId(dest.id)}
                        className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                          selectedDestId === dest.id
                            ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                            : 'border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        <img
                          src={dest.imageUrl}
                          alt={dest.name}
                          className="w-12 h-12 rounded-xl object-cover bg-stone-100 shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="font-serif font-bold text-xs text-stone-900 truncate">
                            {dest.name}
                          </h4>
                          <div className="font-mono text-xs font-semibold text-emerald-800 mt-0.5">
                            {dest.ticketPrice}
                          </div>
                          <div className="text-[10px] text-stone-500 truncate">
                            {dest.visitingHours}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Step 2: Date & Visitor Quantities */}
                <div className="space-y-3 pt-4 border-t border-stone-100">
                  <div className="flex items-center gap-2 text-xs font-semibold text-stone-900 uppercase tracking-wide">
                    <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px]">2</span>
                    <span>{language === 'id' ? 'Tanggal Kunjungan & Jumlah Pengunjung' : 'Visit Date & Visitors'}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[11px] font-semibold text-stone-600 block mb-1">
                        Tanggal Rencana Kunjungan
                      </label>
                      <input
                        type="date"
                        min={todayStr}
                        value={visitDate}
                        onChange={(e) => setVisitDate(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:border-emerald-600"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-stone-600 block mb-1">
                        Pengunjung Dewasa
                      </label>
                      <div className="flex items-center border border-stone-200 rounded-xl bg-stone-50 overflow-hidden">
                        <button
                          type="button"
                          onClick={() => setAdultCount(Math.max(1, adultCount - 1))}
                          className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-xs font-bold"
                        >
                          -
                        </button>
                        <span className="flex-1 text-center font-mono font-bold text-xs text-stone-900">
                          {adultCount}
                        </span>
                        <button
                          type="button"
                          onClick={() => setAdultCount(adultCount + 1)}
                          className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-xs font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-stone-600 block mb-1">
                        Anak-anak (&lt; 10 Thn)
                      </label>
                      <div className="flex items-center border border-stone-200 rounded-xl bg-stone-50 overflow-hidden">
                        <button
                          type="button"
                          onClick={() => setChildCount(Math.max(0, childCount - 1))}
                          className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-xs font-bold"
                        >
                          -
                        </button>
                        <span className="flex-1 text-center font-mono font-bold text-xs text-stone-900">
                          {childCount}
                        </span>
                        <button
                          type="button"
                          onClick={() => setChildCount(childCount + 1)}
                          className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-xs font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Step 3: Visitor Contact Details */}
                <div className="space-y-3 pt-4 border-t border-stone-100">
                  <div className="flex items-center gap-2 text-xs font-semibold text-stone-900 uppercase tracking-wide">
                    <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px]">3</span>
                    <span>{language === 'id' ? 'Data Diri Pemesan (Pengunjung)' : 'Lead Visitor Information'}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="font-semibold text-stone-600 block mb-1">Nama Lengkap *</label>
                      <input
                        type="text"
                        required
                        value={visitorName}
                        onChange={(e) => setVisitorName(e.target.value)}
                        placeholder="Contoh: Muhammad Ramli"
                        className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-stone-50 focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-600 block mb-1">Nomor WhatsApp / HP *</label>
                      <input
                        type="tel"
                        required
                        value={visitorPhone}
                        onChange={(e) => setVisitorPhone(e.target.value)}
                        placeholder="Contoh: 081234567890"
                        className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-stone-50 focus:border-emerald-600 font-mono"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-600 block mb-1">Alamat Email</label>
                      <input
                        type="email"
                        value={visitorEmail}
                        onChange={(e) => setVisitorEmail(e.target.value)}
                        placeholder="ramli@gmail.com"
                        className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-stone-50 focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-stone-600 block mb-1">Asal Kota / Domisili</label>
                      <input
                        type="text"
                        value={visitorCity}
                        onChange={(e) => setVisitorCity(e.target.value)}
                        placeholder="Kota Ambon / Jakarta / Luar Negeri"
                        className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-stone-50 focus:border-emerald-600"
                      />
                    </div>
                  </div>
                </div>

                {/* Step 4: Payment Methods */}
                <div className="space-y-3 pt-4 border-t border-stone-100">
                  <div className="flex items-center gap-2 text-xs font-semibold text-stone-900 uppercase tracking-wide">
                    <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px]">4</span>
                    <span>{language === 'id' ? 'Pilih Metode Pembayaran' : 'Payment Method'}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div
                      onClick={() => setPaymentMethod('qris')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all space-y-1.5 ${
                        paymentMethod === 'qris'
                          ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                          : 'border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900 flex items-center gap-1.5">
                          <QrCode className="w-4 h-4 text-emerald-700" />
                          <span>QRIS Instan</span>
                        </span>
                        <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded">
                          Populer
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 leading-tight">
                        Bank Maluku Malut, BCA, BRI, GoPay, OVO, Dana.
                      </p>
                    </div>

                    <div
                      onClick={() => setPaymentMethod('va_bca')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all space-y-1.5 ${
                        paymentMethod === 'va_bca' || paymentMethod === 'va_maluku'
                          ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                          : 'border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900 flex items-center gap-1.5">
                          <Building2 className="w-4 h-4 text-emerald-700" />
                          <span>Virtual Account</span>
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 leading-tight">
                        Transfer otomatis via ATM atau Mobile Banking.
                      </p>
                    </div>

                    <div
                      onClick={() => setPaymentMethod('cash_on_site')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all space-y-1.5 ${
                        paymentMethod === 'cash_on_site'
                          ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                          : 'border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900 flex items-center gap-1.5">
                          <DollarSign className="w-4 h-4 text-emerald-700" />
                          <span>Bayar di Lokasi</span>
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 leading-tight">
                        Bayar tunai di pos loket masuk Pokdarwis Morela.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Submit Action */}
                <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-stone-400 uppercase font-semibold">Total Tagihan</span>
                    <div className="font-mono text-xl font-bold text-emerald-800">
                      Rp {grandTotal.toLocaleString('id-ID')}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all"
                  >
                    <span>Lanjutkan Pembayaran</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </form>
            )}

            {/* Step: Payment Pending & Simulated QRIS */}
            {bookingStep === 'payment_pending' && currentBooking && (
              <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6 animate-in fade-in">
                <div className="flex items-center justify-between pb-4 border-b border-stone-200">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-semibold text-amber-700 uppercase tracking-wider">
                      MENUNGGU PEMBAYARAN
                    </span>
                    <h3 className="font-serif text-xl font-bold text-stone-900">
                      Selesaikan Pembayaran E-Tiket
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-stone-400 block">Sisa Waktu:</span>
                    <span className="font-mono font-bold text-rose-600 text-base">
                      {formatTimer(paymentTimer)}
                    </span>
                  </div>
                </div>

                {/* QRIS Graphic Simulator */}
                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200 flex flex-col items-center justify-center space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="font-bold text-stone-900 text-sm tracking-widest">
                      QRIS · STANDAR PEMBAYARAN NASIONAL
                    </div>
                  </div>

                  {/* QRIS SVG Matrix */}
                  <div className="w-56 h-56 bg-white p-4 rounded-2xl border-2 border-stone-300 shadow-sm flex flex-col items-center justify-center relative">
                    <svg viewBox="0 0 100 100" className="w-full h-full text-stone-900" fill="currentColor">
                      <rect x="5" y="5" width="28" height="28" rx="2" fill="#047857" />
                      <rect x="10" y="10" width="18" height="18" fill="white" />
                      <rect x="14" y="14" width="10" height="10" fill="#047857" />

                      <rect x="67" y="5" width="28" height="28" rx="2" fill="#047857" />
                      <rect x="72" y="10" width="18" height="18" fill="white" />
                      <rect x="76" y="14" width="10" height="10" fill="#047857" />

                      <rect x="5" y="67" width="28" height="28" rx="2" fill="#047857" />
                      <rect x="10" y="72" width="18" height="18" fill="white" />
                      <rect x="14" y="76" width="10" height="10" fill="#047857" />

                      <rect x="36" y="12" width="6" height="6" fill="#0f172a" />
                      <rect x="48" y="12" width="6" height="6" fill="#047857" />
                      <rect x="36" y="38" width="8" height="8" fill="#0f172a" />
                      <rect x="48" y="38" width="6" height="6" fill="#047857" />
                      <rect x="60" y="38" width="8" height="8" fill="#0f172a" />
                      <rect x="38" y="52" width="8" height="8" fill="#047857" />
                      <rect x="52" y="52" width="8" height="8" fill="#0f172a" />
                      <rect x="70" y="42" width="8" height="8" fill="#047857" />
                      <rect x="40" y="70" width="8" height="8" fill="#0f172a" />
                      <rect x="56" y="70" width="8" height="8" fill="#047857" />
                      <rect x="70" y="70" width="8" height="8" fill="#0f172a" />

                      <circle cx="50" cy="50" r="8" fill="white" stroke="#047857" strokeWidth="2" />
                      <circle cx="50" cy="50" r="4" fill="#047857" />
                    </svg>

                    <div className="absolute bottom-2 text-[9px] font-mono text-stone-400">
                      NMID: ID1029384756201
                    </div>
                  </div>

                  <div className="text-center space-y-1">
                    <div className="text-xs font-semibold text-stone-800">
                      Merchant: <span className="text-emerald-800">POKDARWIS NEGERI MORELA</span>
                    </div>
                    <div className="font-mono text-xl font-bold text-stone-900">
                      Rp {currentBooking.totalAmount.toLocaleString('id-ID')}
                    </div>
                    <div className="text-[11px] text-stone-500">
                      Kode Booking: <strong className="font-mono">{currentBooking.bookingCode}</strong>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 space-y-1">
                  <div className="font-semibold">Instruksi Pembayaran:</div>
                  <ol className="list-decimal list-inside space-y-1 text-[11px]">
                    <li>Buka aplikasi Mobile Banking (Bank Maluku Malut, BCA, BRI, Mandiri) atau e-Wallet (GoPay, OVO, Dana).</li>
                    <li>Pilih menu <strong>Pindai / Scan QRIS</strong> lalu arahkan kamera ke barcode di atas.</li>
                    <li>Periksa nama penerima bertuliskan <strong>POKDARWIS NEGERI MORELA</strong>.</li>
                    <li>Setelah transaksi berhasil, klik tombol verifikasi di bawah ini.</li>
                  </ol>
                </div>

                {/* Simulation button */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                  <button
                    onClick={() => setBookingStep('form')}
                    className="w-full sm:w-auto px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs rounded-xl font-medium"
                  >
                    Kembali Ubah Pesanan
                  </button>

                  <button
                    onClick={handleSimulatePaymentSuccess}
                    className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-sm"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Saya Sudah Bayar (Konfirmasi)</span>
                  </button>
                </div>
              </div>
            )}

            {/* Step: Success & Verified E-Ticket Display */}
            {bookingStep === 'success' && currentBooking && (
              <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6 animate-in zoom-in-95">
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-stone-900">
                    Pembayaran Berhasil Dikonfirmasi!
                  </h3>
                  <p className="text-xs text-stone-600 max-w-md mx-auto">
                    Terima kasih, <strong>{currentBooking.visitorName}</strong>. E-Tiket resmi Anda telah diterbitkan dan tercatat dalam basis data pengelola desa.
                  </p>
                </div>

                {/* Compact E-Ticket Preview Card */}
                <div className="p-5 rounded-2xl bg-stone-900 text-white space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                    <div className="text-[10px] text-emerald-400 font-mono tracking-widest uppercase">
                      MORELA TOURISM · E-TICKET PASS
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-600 text-white font-semibold">
                      CONFIRMED (LUNAS)
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase">KODE BOOKING</div>
                      <div className="font-mono text-base font-bold text-amber-300">
                        {currentBooking.bookingCode}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 uppercase">TANGGAL WISATA</div>
                      <div className="font-semibold text-stone-100">{currentBooking.visitDate}</div>
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] text-stone-400 uppercase">DESTINASI</div>
                    <div className="font-serif text-base font-bold text-white">
                      {currentBooking.destinationName}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-2 border-t border-stone-800 font-mono">
                    <span className="text-stone-400">Total: Rp {currentBooking.totalAmount.toLocaleString('id-ID')}</span>
                    <span className="text-emerald-400">{currentBooking.adultCount} Dewasa</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => setSelectedTicketForPrint(currentBooking)}
                    className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Buka & Cetak E-Tiket</span>
                  </button>

                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      `E-Tiket Wisata Morela:\nKode: ${currentBooking.bookingCode}\nDestinasi: ${currentBooking.destinationName}\nTanggal: ${currentBooking.visitDate}`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-3 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-2"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Kirim ke WhatsApp</span>
                  </a>
                </div>

                <div className="text-center">
                  <button
                    onClick={() => {
                      setBookingStep('form');
                      setCurrentBooking(null);
                    }}
                    className="text-xs text-stone-500 hover:text-stone-900 underline"
                  >
                    Pesan Tiket untuk Destinasi Lain
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Right Summary Column (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Selected Destination Showcase Card */}
            <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
              <div className="relative h-44 w-full bg-stone-900">
                <img
                  src={currentDest.imageUrl}
                  alt={currentDest.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <span className="text-[10px] text-emerald-300 font-semibold uppercase">
                    DESTINASI PILIHAN
                  </span>
                  <h4 className="font-serif text-lg font-bold text-white truncate">
                    {currentDest.name}
                  </h4>
                </div>
              </div>

              <div className="p-5 space-y-4 text-xs">
                <div className="flex items-center gap-2 text-stone-600">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="truncate">{currentDest.location}</span>
                </div>

                <div className="flex items-center gap-2 text-stone-600">
                  <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{currentDest.visitingHours}</span>
                </div>

                {/* Calculation Details */}
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                  <div className="font-semibold text-stone-900 uppercase text-[10px] text-stone-500">
                    Rincian Biaya Tiket
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span>Tiket Dewasa ({adultCount}x):</span>
                    <span className="font-mono">Rp {(adultCount * pricePerTicket).toLocaleString('id-ID')}</span>
                  </div>

                  {childCount > 0 && (
                    <div className="flex justify-between text-stone-600">
                      <span>Tiket Anak ({childCount}x):</span>
                      <span className="font-mono">Rp {(childCount * Math.round(pricePerTicket * 0.5)).toLocaleString('id-ID')}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-stone-600">
                    <span>Retribusi Sampah & Asuransi:</span>
                    <span className="font-mono">Rp {cleanlinessFee.toLocaleString('id-ID')}</span>
                  </div>

                  <div className="flex justify-between pt-2 border-t border-stone-200 font-bold text-stone-900 text-sm">
                    <span>Total Pembayaran:</span>
                    <span className="font-mono text-emerald-800 text-base font-bold">
                      Rp {grandTotal.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 flex items-start gap-2 text-[11px] text-emerald-950">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    Dana retribusi dikelola secara transparan oleh Pemerintah Negeri Morela untuk pembersihan pantai dan pelestarian terumbu karang.
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Benefits */}
            <div className="p-5 rounded-3xl bg-stone-900 text-stone-200 space-y-3 text-xs">
              <div className="font-semibold text-white uppercase text-[10px] tracking-wider text-amber-400">
                Keuntungan Tiket Online Morela
              </div>
              <ul className="space-y-2 text-[11px]">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Jalur masuk prioritas tanpa antre di pos loket.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Tercatat otomatis dan terlindungi asuransi pesisir.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>E-Tiket aman tersimpan di smartphone dapat dicetak kapan saja.</span>
                </li>
              </ul>
            </div>

          </div>
        </div>
      )}

      {/* TAB 2: CEK STATUS / CARI E-TIKET */}
      {activeTab === 'cek' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="space-y-1">
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Cek Status Pemesanan & Cetak Ulang E-Tiket
              </h3>
              <p className="text-xs text-stone-500">
                Masukkan Kode Booking yang Anda terima saat pemesanan (Contoh: <code className="text-emerald-700 font-mono font-bold">MOR-2609-8812</code>) atau nomor WhatsApp Anda.
              </p>
            </div>

            <form onSubmit={handleSearchTicket} className="flex gap-2">
              <input
                type="text"
                required
                value={searchBookingCode}
                onChange={(e) => setSearchBookingCode(e.target.value)}
                placeholder="Masukkan Kode Booking (MOR-XXXX-XXXX)..."
                className="flex-1 px-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-900 focus:outline-none focus:border-emerald-600"
              />
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5"
              >
                <Search className="w-4 h-4" />
                <span>Cari Tiket</span>
              </button>
            </form>

            {searchError && (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{searchError}</span>
              </div>
            )}

            {/* Found Result Card */}
            {foundBooking && (
              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-stone-400 uppercase font-semibold">KODE BOOKING</span>
                    <div className="font-mono text-lg font-bold text-stone-900">
                      {foundBooking.bookingCode}
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase ${
                    foundBooking.paymentStatus === 'paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : foundBooking.paymentStatus === 'checked_in'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {foundBooking.paymentStatus === 'paid' ? 'LUNAS' : foundBooking.paymentStatus === 'checked_in' ? 'CHECKED-IN' : 'PENDING'}
                  </span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="font-serif text-base font-bold text-stone-900">
                    {foundBooking.destinationName}
                  </div>
                  <div className="text-stone-500">
                    Pengunjung: <strong>{foundBooking.visitorName}</strong> ({foundBooking.adultCount} Dewasa)
                  </div>
                  <div className="text-stone-500 font-mono">
                    Tanggal Kunjungan: {foundBooking.visitDate}
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <button
                    onClick={() => setSelectedTicketForPrint(foundBooking)}
                    className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Lihat & Cetak E-Tiket</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: DAFTAR TARIF & REGULASI DESA */}
      {activeTab === 'info' && (
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="space-y-1">
              <h3 className="font-serif text-xl font-bold text-stone-900">
                Tarif Retribusi Resmi & Regulasi Wisatawan
              </h3>
              <p className="text-xs text-stone-500">
                Berdasarkan Keputusan Musyawarah Saniri & Pemerintah Negeri Morela tahun 2026.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-semibold uppercase text-stone-600">
                  <tr>
                    <th className="px-4 py-3">Nama Destinasi</th>
                    <th className="px-4 py-3">Kategori</th>
                    <th className="px-4 py-3">Tiket Dewasa</th>
                    <th className="px-4 py-3">Tiket Anak</th>
                    <th className="px-4 py-3">Jam Operasional</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {destinations.map((d) => (
                    <tr key={d.id} className="hover:bg-stone-50">
                      <td className="px-4 py-3 font-semibold text-stone-900">{d.name}</td>
                      <td className="px-4 py-3 capitalize">{d.category.replace('_', ' ')}</td>
                      <td className="px-4 py-3 font-mono font-bold text-emerald-800">{d.ticketPrice}</td>
                      <td className="px-4 py-3 font-mono">
                        {d.ticketPriceNum > 0 ? `Rp ${Math.round(d.ticketPriceNum * 0.5).toLocaleString('id-ID')}` : 'Gratis'}
                      </td>
                      <td className="px-4 py-3 font-mono text-stone-500 text-[11px]">{d.visitingHours}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2 text-xs text-stone-600">
              <div className="font-semibold text-stone-900">Tata Tertib & Keselamatan Wisatawan:</div>
              <ul className="list-disc list-inside space-y-1 text-[11px]">
                <li>Dilarang menginjak, mengambil, atau merusak karang laut di sekitar Pantai Lubang Buaya.</li>
                <li>Wisatawan wajib menjaga kebersihan dan membuang sampah pada tempat yang disediakan.</li>
                <li>Hormati kearifan lokal adat dan busana sopan saat berkunjung ke situs sejarah dan permukiman adat Morela.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
