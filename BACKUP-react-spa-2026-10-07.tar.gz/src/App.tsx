import React, { useEffect } from 'react';
import { TourismProvider, useTourism } from './context/TourismContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { DestinationModal } from './components/DestinationModal';
import { ProductModal } from './components/ProductModal';
import { CultureDetailModal } from './components/CultureDetailModal';
import { ArticleModal } from './components/ArticleModal';
import { QRCodeModal } from './components/QRCodeModal';
import { LightboxModal } from './components/LightboxModal';
import { TicketModal } from './components/TicketModal';

// Views
import { HomeView } from './views/HomeView';
import { DestinationsView } from './views/DestinationsView';
import { TicketingView } from './views/TicketingView';
import { CultureView } from './views/CultureView';
import { UMKMView } from './views/UMKMView';
import { EventsView } from './views/EventsView';
import { NewsView } from './views/NewsView';
import { GalleryView } from './views/GalleryView';
import { MapView } from './views/MapView';
import { ProgramView } from './views/ProgramView';
import { AdminDashboardView } from './views/AdminDashboardView';

const MainContent: React.FC = () => {
  const { currentView, incrementVisits } = useTourism();

  // Record a simulated visit on initial mount
  useEffect(() => {
    incrementVisits();
  }, []);

  const renderActiveView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView />;
      case 'destinations':
        return <DestinationsView />;
      case 'tickets':
        return <TicketingView />;
      case 'culture':
        return <CultureView />;
      case 'umkm':
        return <UMKMView />;
      case 'events':
        return <EventsView />;
      case 'news':
        return <NewsView />;
      case 'gallery':
        return <GalleryView />;
      case 'map':
        return <MapView />;
      case 'program':
        return <ProgramView />;
      case 'admin':
        return <AdminDashboardView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 selection:bg-emerald-100 selection:text-emerald-900 pb-16 lg:pb-0">
      {/* Top Bar Header */}
      <Header />

      {/* Main View Area */}
      <main className="flex-1 animate-in fade-in duration-150">
        {renderActiveView()}
      </main>

      {/* Institutional Footer */}
      <Footer />

      {/* Smartphone Bottom Navigation */}
      <MobileBottomNav />

      {/* Detail & Overlay Modals */}
      <DestinationModal />
      <ProductModal />
      <CultureDetailModal />
      <ArticleModal />
      <QRCodeModal />
      <LightboxModal />
      <TicketModal />
    </div>
  );
};

export default function App() {
  return (
    <TourismProvider>
      <MainContent />
    </TourismProvider>
  );
}
