export type CategoryDestination = 'pantai' | 'alam' | 'pemandangan' | 'religi_sejarah' | 'budaya';

export interface Destination {
  id: string;
  slug: string;
  name: string;
  nameEn: string;
  category: CategoryDestination;
  tagline: string;
  taglineEn: string;
  description: string;
  descriptionEn: string;
  location: string;
  coordinates: {
    lat: number;
    lng: number;
    mapX: number; // Percentage coordinate on interactive SVG map (0-100)
    mapY: number;
  };
  visitingHours: string;
  ticketPrice: string;
  ticketPriceNum: number;
  facilities: string[];
  contactName: string;
  contactPhone: string;
  imageUrl: string;
  galleryImages: string[];
  featured: boolean;
  published: boolean;
}

export type CategoryCulture = 'sejarah' | 'tradisi' | 'kesenian' | 'kuliner' | 'cerita_rakyat' | 'tokoh';

export interface CultureItem {
  id: string;
  slug: string;
  title: string;
  titleEn: string;
  category: CategoryCulture;
  summary: string;
  summaryEn: string;
  content: string;
  contentEn: string;
  periodOrTime: string;
  historicalSignificance: string;
  imageUrl: string;
  tags: string[];
  published: boolean;
}

export type CategoryUMKM = 'kuliner' | 'kerajinan' | 'produk_olahan' | 'agrowisata';

export interface UMKMProduct {
  id: string;
  name: string;
  nameEn: string;
  category: CategoryUMKM;
  price: number;
  priceFormatted: string;
  unit: string;
  sellerName: string;
  sellerGroup: string;
  sellerPhone: string;
  sellerAddress: string;
  description: string;
  descriptionEn: string;
  imageUrl: string;
  featured: boolean;
  inStock: boolean;
  published: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  titleEn: string;
  date: string;
  time: string;
  location: string;
  organizer: string;
  category: 'budaya' | 'pengabdian' | 'desa' | 'olahraga' | 'keagamaan';
  description: string;
  descriptionEn: string;
  status: 'upcoming' | 'ongoing' | 'completed';
  imageUrl: string;
  contactPerson: string;
}

export interface NewsArticle {
  id: string;
  slug: string;
  title: string;
  titleEn: string;
  category: 'desa' | 'mahasiswa' | 'pariwisata' | 'budaya' | 'umkm' | 'lingkungan';
  author: string;
  authorRole: string;
  publishedDate: string;
  readTime: string;
  summary: string;
  summaryEn: string;
  content: string;
  contentEn: string;
  imageUrl: string;
  published: boolean;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  titleEn: string;
  category: 'alam' | 'budaya' | 'masyarakat' | 'pengabdian' | 'wisata';
  location: string;
  photographer: string;
  dateTaken: string;
  imageUrl: string;
}

export interface ContactInfo {
  address: string;
  phone: string;
}

export interface HeroTextInfo {
  badge: string;
  badgeEn: string;
  title: string;
  titleEn: string;
  tagline: string;
  taglineEn: string;
  description: string;
  descriptionEn: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: string;
  university: string;
  photoUrl: string;
  bio: string;
  contribution: string;
}

export interface MapMarkerItem {
  id: string;
  title: string;
  type: 'wisata' | 'umkm' | 'kuliner' | 'penginapan' | 'fasilitas';
  categoryLabel: string;
  location: string;
  description: string;
  mapX: number; // SVG percentage x (0-100)
  mapY: number; // SVG percentage y (0-100)
  phone?: string;
  rating?: number;
}

export type UserRole = 'pengunjung' | 'mahasiswa' | 'admin_desa';
export type AppLanguage = 'id' | 'en';

export type PaymentMethod = 'qris' | 'va_maluku' | 'va_bca' | 'va_mandiri' | 'cash_on_site';
export type PaymentStatus = 'pending' | 'paid' | 'checked_in' | 'cancelled';

export interface PaymentSettings {
  rekeningBCA: string;
  rekeningMandiri: string;
  rekeningMaluku: string;
  qrisUrl: string;
}

export interface TicketBooking {
  id: string;
  bookingCode: string;
  destinationId: string;
  destinationName: string;
  destinationLocation: string;
  visitDate: string;
  visitorName: string;
  visitorEmail: string;
  visitorPhone: string;
  visitorCity: string;
  adultCount: number;
  childCount: number;
  pricePerTicket: number;
  cleanlinessFee: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  createdAt: string;
  paidAt?: string;
  checkedInAt?: string;
  qrValidationCode: string;
}
