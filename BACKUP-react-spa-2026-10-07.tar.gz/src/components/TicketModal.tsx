import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { TicketBooking } from '../types';
import {
  X,
  Printer,
  Share2,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  User,
  ShieldCheck,
  Compass,
  Copy,
  Check,
  Download
} from 'lucide-react';

export const TicketModal: React.FC = () => {
  const { selectedTicketForPrint, setSelectedTicketForPrint, language } = useTourism();
  const [copied, setCopied] = useState(false);

  if (!selectedTicketForPrint) return null;

  const ticket = selectedTicketForPrint;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(ticket.bookingCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `E-Tiket Resmi Morela Tourism:\nKode Booking: ${ticket.bookingCode}\nDestinasi: ${ticket.destinationName}\nTanggal: ${ticket.visitDate}\nPengunjung: ${ticket.visitorName} (${ticket.adultCount} Dewasa, ${ticket.childCount} Anak)\nTotal: Rp ${ticket.totalAmount.toLocaleString('id-ID')}\nStatus: ${ticket.paymentStatus.toUpperCase()}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full my-auto overflow-hidden shadow-2xl border border-stone-200 text-stone-900 relative">
        
        {/* Floating Close Button */}
        <button
          onClick={() => setSelectedTicketForPrint(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-stone-900/80 text-white hover:bg-stone-950 transition-colors shadow-md"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* E-Ticket Header Strip */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-stone-900 text-white p-6 pb-8 relative overflow-hidden">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Compass className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-semibold tracking-widest text-emerald-300">
                PEMERINTAH NEGERI MORELA & POKDARWIS
              </span>
              <h3 className="font-serif text-xl font-bold tracking-tight text-white">
                E-TIKET WISATA RESMI
              </h3>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] text-stone-300 uppercase">KODE BOOKING</div>
              <div className="font-mono text-lg font-bold text-amber-300 tracking-wider">
                {ticket.bookingCode}
              </div>
            </div>
            <div className="text-right">
              <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold uppercase ${
                ticket.paymentStatus === 'paid'
                  ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/40'
                  : ticket.paymentStatus === 'checked_in'
                  ? 'bg-blue-500/20 text-blue-200 border border-blue-400/40'
                  : 'bg-amber-500/20 text-amber-200 border border-amber-400/40'
              }`}>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{ticket.paymentStatus === 'paid' ? 'LUNAS (CONFIRMED)' : ticket.paymentStatus === 'checked_in' ? 'CHECKED-IN' : 'MENUNGGU BAYAR'}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Tear-off Scallop Line */}
        <div className="relative flex items-center justify-between px-6 -my-3 z-10">
          <div className="w-6 h-6 rounded-full bg-black/80 -ml-9" />
          <div className="flex-1 border-b-2 border-dashed border-stone-300 mx-2" />
          <div className="w-6 h-6 rounded-full bg-black/80 -mr-9" />
        </div>

        {/* Ticket Body */}
        <div className="p-6 sm:p-7 space-y-6 pt-6">
          {/* Destination & Visit Date */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wide">
              Destinasi Tujuan
            </div>
            <h4 className="font-serif text-xl font-bold text-stone-900 leading-snug">
              {ticket.destinationName}
            </h4>
            <div className="flex items-center gap-1.5 text-xs text-stone-500">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>{ticket.destinationLocation}</span>
            </div>
          </div>

          {/* Details Definition Grid */}
          <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs">
            <div>
              <div className="text-[10px] text-stone-400 uppercase font-semibold">TANGGAL KUNJUNGAN</div>
              <div className="font-semibold text-stone-800 text-sm mt-0.5">{ticket.visitDate}</div>
            </div>

            <div>
              <div className="text-[10px] text-stone-400 uppercase font-semibold">PEMESAN / WISATAWAN</div>
              <div className="font-semibold text-stone-800 truncate text-sm mt-0.5">{ticket.visitorName}</div>
            </div>

            <div>
              <div className="text-[10px] text-stone-400 uppercase font-semibold">JUMLAH PENGUNJUNG</div>
              <div className="font-medium text-stone-800 mt-0.5">
                {ticket.adultCount} Dewasa {ticket.childCount > 0 && `· ${ticket.childCount} Anak`}
              </div>
            </div>

            <div>
              <div className="text-[10px] text-stone-400 uppercase font-semibold">METODE BAYAR</div>
              <div className="font-medium text-stone-800 uppercase mt-0.5">{ticket.paymentMethod.replace('_', ' ')}</div>
            </div>
          </div>

          {/* Financial Breakdown */}
          <div className="space-y-1.5 text-xs text-stone-600 border-t border-b border-stone-200 py-3">
            <div className="flex justify-between">
              <span>Tiket Masuk ({ticket.adultCount}x @Rp {ticket.pricePerTicket.toLocaleString('id-ID')}):</span>
              <span className="font-mono">Rp {(ticket.adultCount * ticket.pricePerTicket).toLocaleString('id-ID')}</span>
            </div>
            {ticket.childCount > 0 && (
              <div className="flex justify-between">
                <span>Tiket Anak ({ticket.childCount}x @Rp {(ticket.pricePerTicket / 2).toLocaleString('id-ID')}):</span>
                <span className="font-mono">Rp {(ticket.childCount * (ticket.pricePerTicket / 2)).toLocaleString('id-ID')}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Retribusi Kebersihan & Asuransi Pesisir:</span>
              <span className="font-mono">Rp {ticket.cleanlinessFee.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between pt-1.5 border-t border-stone-100 font-bold text-stone-900 text-sm">
              <span>Total Pembayaran:</span>
              <span className="font-mono text-emerald-800 font-bold text-base">
                Rp {ticket.totalAmount.toLocaleString('id-ID')}
              </span>
            </div>
          </div>

          {/* Barcode & Verification QR Pattern */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex flex-col items-center justify-center space-y-2">
            <div className="w-32 h-32 bg-white p-2 rounded-lg border border-stone-200 flex items-center justify-center shadow-xs">
              {/* Dynamic QR Matrix Pattern */}
              <svg viewBox="0 0 100 100" className="w-full h-full text-stone-900" fill="currentColor">
                <rect x="5" y="5" width="28" height="28" rx="2" fill="#047857" />
                <rect x="10" y="10" width="18" height="18" fill="white" />
                <rect x="14" y="14" width="10" height="10" fill="#047857" />

                <rect x="67" y="5" width="28" height="28" rx="2" fill="#047857" />
                <rect x="72" y="10" width="18" height="18" fill="white" />
                <rect x="76" y="14" width="10" height="10" fill="#047857" />

                <rect x="5" y="67" width="28" height="28" rx="2" fill="#047857" />
                <rect x="10" y="72" width="18" height="18" fill="white" />
                <rect x="14" y="76" width="10" height="10" fill="#047857" />

                <rect x="38" y="38" width="8" height="8" fill="#0f172a" />
                <rect x="52" y="38" width="6" height="6" fill="#047857" />
                <rect x="42" y="52" width="6" height="6" fill="#047857" />
                <rect x="54" y="52" width="8" height="8" fill="#0f172a" />
                <rect x="70" y="42" width="8" height="8" fill="#0f172a" />
                <rect x="40" y="70" width="8" height="8" fill="#0f172a" />
                <rect x="60" y="70" width="8" height="8" fill="#047857" />
                <rect x="74" y="74" width="8" height="8" fill="#0f172a" />
              </svg>
            </div>
            
            <div className="font-mono text-[11px] text-stone-500 tracking-wider">
              {ticket.qrValidationCode}
            </div>
            <p className="text-[10px] text-stone-400 text-center">
              Tunjukkan barcode / QR ini kepada petugas di loket masuk wisata Negeri Morela.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-2 bg-white border border-stone-300 hover:bg-stone-100 rounded-xl text-xs font-medium text-stone-700 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Tersalin!' : 'Salin Kode'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Kirim WhatsApp</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Tiket</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
