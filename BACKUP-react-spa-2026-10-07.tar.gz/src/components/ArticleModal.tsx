import React from 'react';
import { useTourism } from '../context/TourismContext';
import { X, Calendar, User, Clock, Share2, Tag } from 'lucide-react';

export const ArticleModal: React.FC = () => {
  const { selectedArticle, setSelectedArticle, language } = useTourism();

  if (!selectedArticle) return null;

  const article = selectedArticle;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200 text-stone-900 relative">
        <button
          onClick={() => setSelectedArticle(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-stone-900/80 text-white hover:bg-stone-950 transition-colors shadow-md"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="relative h-60 sm:h-72 w-full bg-stone-900 overflow-hidden">
          <img
            src={article.imageUrl}
            alt={article.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5 text-white">
            <span className="text-[11px] font-semibold uppercase tracking-widest text-emerald-300">
              {article.category} · WARTA DESA & PENGABDIAN
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-white mt-1 leading-snug">
              {language === 'id' ? article.title : article.titleEn}
            </h2>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-5 max-h-[60vh] overflow-y-auto">
          {/* Metadata bar */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 pb-3 border-b border-stone-200">
            <span className="flex items-center gap-1.5 font-medium text-stone-800">
              <User className="w-3.5 h-3.5 text-emerald-600" />
              {article.author} ({article.authorRole})
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-stone-400" />
              {article.publishedDate}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-stone-400" />
              {article.readTime}
            </span>
          </div>

          {/* Article Summary */}
          <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed italic">
            "{language === 'id' ? article.summary : article.summaryEn}"
          </div>

          {/* Full content */}
          <div className="text-stone-800 text-sm leading-relaxed space-y-4 whitespace-pre-line max-w-prose">
            {language === 'id' ? article.content : article.contentEn}
          </div>
        </div>

        <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={() => setSelectedArticle(null)}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-medium transition-colors"
          >
            {language === 'id' ? 'Tutup' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
