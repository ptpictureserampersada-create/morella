import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { Compass, Globe, Shield, Menu, X, Sparkles, MapPin, Ticket } from 'lucide-react';

export const Header: React.FC = () => {
  const { currentView, setCurrentView, language, setLanguage, userRole, setUserRole } = useTourism();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', labelId: 'Beranda', labelEn: 'Home' },
    { id: 'destinations', labelId: 'Destinasi', labelEn: 'Destinations' },
    { id: 'tickets', labelId: 'Tiket Wisata', labelEn: 'E-Ticket' },
    { id: 'culture', labelId: 'Budaya', labelEn: 'Culture' },
    { id: 'umkm', labelId: 'UMKM', labelEn: 'Local Market' },
    { id: 'map', labelId: 'Peta Wisata', labelEn: 'Map' },
    { id: 'social', labelId: 'Media Sosial', labelEn: 'Social Media' },
    { id: 'events', labelId: 'Agenda', labelEn: 'Events' },
    { id: 'news', labelId: 'Berita', labelEn: 'News' },
    { id: 'gallery', labelId: 'Galeri', labelEn: 'Gallery' },
    { id: 'program', labelId: 'Pengabdian UNIDAR', labelEn: 'UNIDAR Program' },
  ];

  const handleNavClick = (viewId: string) => {
    setCurrentView(viewId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-stone-900/95 backdrop-blur-md border-b border-stone-800 text-stone-100 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Zone 1: Brand title wordmark */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus-visible:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-950/40 border border-emerald-500/30 group-hover:scale-105 transition-transform">
              <Compass className="w-5 h-5 text-emerald-200" />
            </div>
            <div>
              <div className="font-serif text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Negeri Morella
              </div>
              <p className="text-[10px] text-stone-400 font-sans tracking-wide uppercase">
                {language === 'id' ? 'Leihitu · Maluku Tengah' : 'Leihitu · Central Maluku'}
              </p>
            </div>
          </button>

          {/* Zone 2: Clean text navigation links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-medium">
            {navLinks.slice(0, 7).map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === item.id
                    ? 'text-emerald-400 font-semibold bg-stone-800/80'
                    : 'text-stone-300 hover:text-white hover:bg-stone-800/40'
                }`}
              >
                {item.id === 'tickets' && <Ticket className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{language === 'id' ? item.labelId : item.labelEn}</span>
              </button>
            ))}

            <div className="relative group">
              <button
                className={`px-3 py-1.5 rounded-lg transition-colors text-stone-300 hover:text-white hover:bg-stone-800/40 ${
                  currentView === 'events' || currentView === 'news' || currentView === 'gallery' || currentView === 'program' ? 'text-emerald-400 font-semibold' : ''
                }`}
              >
                {language === 'id' ? 'Lainnya ▾' : 'More ▾'}
              </button>
              <div className="absolute right-0 top-full mt-1 w-52 py-2 bg-stone-900 border border-stone-800 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150">
                <button
                  onClick={() => handleNavClick('events')}
                  className="w-full text-left px-4 py-2 text-sm text-stone-300 hover:text-emerald-400 hover:bg-stone-800"
                >
                  {language === 'id' ? 'Agenda & Kegiatan' : 'Events & Calendar'}
                </button>
                <button
                  onClick={() => handleNavClick('news')}
                  className="w-full text-left px-4 py-2 text-sm text-stone-300 hover:text-emerald-400 hover:bg-stone-800"
                >
                  {language === 'id' ? 'Warta Desa & KKN' : 'Village & Student News'}
                </button>
                <button
                  onClick={() => handleNavClick('gallery')}
                  className="w-full text-left px-4 py-2 text-sm text-stone-300 hover:text-emerald-400 hover:bg-stone-800"
                >
                  {language === 'id' ? 'Galeri Dokumentasi' : 'Photo Gallery'}
                </button>
                <button
                  onClick={() => handleNavClick('program')}
                  className="w-full text-left px-4 py-2 text-sm text-stone-300 hover:text-emerald-400 hover:bg-stone-800"
                >
                  {language === 'id' ? 'Pengabdian Mahasiswa UNIDAR' : 'UNIDAR Community Service'}
                </button>
              </div>
            </div>
          </nav>

          {/* Zone 3: Language Toggle & Admin/Role Portal Action */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Language Switcher */}
            <div className="flex items-center bg-stone-800/90 rounded-lg p-0.5 border border-stone-700/60 text-xs">
              <button
                onClick={() => setLanguage('id')}
                className={`px-2 py-1 rounded-md transition-colors font-medium ${
                  language === 'id' ? 'bg-emerald-700 text-white shadow-sm' : 'text-stone-400 hover:text-stone-200'
                }`}
                title="Bahasa Indonesia"
              >
                ID
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded-md transition-colors font-medium ${
                  language === 'en' ? 'bg-emerald-700 text-white shadow-sm' : 'text-stone-400 hover:text-stone-200'
                }`}
                title="English"
              >
                EN
              </button>
            </div>

            {/* Admin Dashboard CTA Button */}
            <button
              onClick={() => handleNavClick('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap ${
                currentView === 'admin'
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-900/40 ring-1 ring-amber-400'
                  : 'bg-emerald-700 hover:bg-emerald-600 text-white shadow-sm'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>{language === 'id' ? 'Dashboard Admin' : 'Admin Portal'}</span>
            </button>

            {/* Mobile menu hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 focus:outline-none"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-stone-900 border-b border-stone-800 px-4 pt-2 pb-6 space-y-1 animate-in fade-in slide-in-from-top-2 duration-150">
          {navLinks.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center justify-between ${
                currentView === item.id
                  ? 'bg-emerald-950/80 text-emerald-400 font-semibold'
                  : 'text-stone-300 hover:bg-stone-800 hover:text-white'
              }`}
            >
              <span className="flex items-center gap-2">
                {item.id === 'tickets' && <Ticket className="w-4 h-4 text-emerald-400" />}
                <span>{language === 'id' ? item.labelId : item.labelEn}</span>
              </span>
            </button>
          ))}
          
          <div className="pt-3 border-t border-stone-800 mt-2 flex items-center justify-between text-xs text-stone-400 px-3">
            <span>Role: {userRole === 'admin_desa' ? 'Pemerintah Negeri' : userRole === 'mahasiswa' ? 'Mahasiswa UNIDAR' : 'Wisatawan'}</span>
            <button
              onClick={() => handleNavClick('admin')}
              className="text-emerald-400 hover:underline font-medium"
            >
              Buka Dashboard ➔
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

