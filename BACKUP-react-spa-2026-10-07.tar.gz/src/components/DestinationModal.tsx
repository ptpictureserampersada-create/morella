import React from 'react';
import { useTourism } from '../context/TourismContext';
import { X, MapPin, Clock, Ticket, Phone, CheckCircle2, QrCode, Share2, Compass } from 'lucide-react';

export const DestinationModal: React.FC = () => {
  const {
    selectedDestination,
    setSelectedDestination,
    setQrModalItem,
    setActiveBookingDestination,
    setCurrentView,
    language
  } = useTourism();

  if (!selectedDestination) return null;

  const dest = selectedDestination;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: dest.name,
        text: dest.tagline,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert(language === 'id' ? 'Tautan berhasil disalin!' : 'Link copied!');
    }
  };

  const handleWhatsAppContact = () => {
    const phone = dest.contactPhone.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      language === 'id'
        ? `Halo ${dest.contactName}, saya ingin bertanya tentang informasi kunjungan ke ${dest.name} melalui portal Morela Tourism.`
        : `Hello ${dest.contactName}, I would like to inquire about visiting ${dest.nameEn || dest.name} via Morela Tourism portal.`
    );
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  const handleBookTicket = () => {
    setActiveBookingDestination(dest);
    setSelectedDestination(null);
    setCurrentView('tickets');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-3xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200 text-stone-900 relative">
        
        {/* Floating Close Button */}
        <button
          onClick={() => setSelectedDestination(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-stone-900/80 text-white hover:bg-stone-950 transition-colors shadow-md"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Visual Area with Scrim */}
        <div className="relative h-64 sm:h-80 w-full bg-stone-900 overflow-hidden">
          <img
            src={dest.imageUrl}
            alt={dest.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
          
          <div className="absolute bottom-5 left-5 right-5 text-white">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-300 mb-1">
              <span>{dest.category.toUpperCase().replace('_', ' & ')}</span>
              <span>·</span>
              <span>NEGERI MORELA</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight">
              {language === 'id' ? dest.name : dest.nameEn}
            </h2>
            <p className="text-xs sm:text-sm text-stone-200 mt-1 max-w-xl font-light">
              {language === 'id' ? dest.tagline : dest.taglineEn}
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          
          {/* Quick Specifications Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-stone-50 border border-stone-200 text-xs">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-stone-500 uppercase font-semibold">
                  {language === 'id' ? 'Jam Kunjungan' : 'Opening Hours'}
                </div>
                <div className="font-medium text-stone-800">{dest.visitingHours}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800">
                <Ticket className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-stone-500 uppercase font-semibold">
                  {language === 'id' ? 'Harga Tiket' : 'Ticket Fee'}
                </div>
                <div className="font-medium text-stone-800 font-mono tabular-nums">{dest.ticketPrice}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-stone-500 uppercase font-semibold">
                  {language === 'id' ? 'Wilayah' : 'Location'}
                </div>
                <div className="font-medium text-stone-800 truncate max-w-[160px]">{dest.location}</div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-stone-900">
              {language === 'id' ? 'Deskripsi Lengkap' : 'About Destination'}
            </h4>
            <p className="text-sm text-stone-700 leading-relaxed max-w-prose">
              {language === 'id' ? dest.description : dest.descriptionEn}
            </p>
          </div>

          {/* Facilities */}
          {dest.facilities && dest.facilities.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-stone-900">
                {language === 'id' ? 'Fasilitas Tersedia' : 'Available Amenities'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {dest.facilities.map((fac, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-stone-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{fac}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Photo Gallery Grid */}
          {dest.galleryImages && dest.galleryImages.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-stone-900">
                {language === 'id' ? 'Galeri Foto' : 'Photo Gallery'}
              </h4>
              <div className="grid grid-cols-3 gap-2">
                {dest.galleryImages.map((img, idx) => (
                  <div key={idx} className="h-24 sm:h-32 rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                    <img
                      src={img}
                      alt={`${dest.name} ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contact Box */}
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-0.5 text-center sm:text-left">
              <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wide">
                {language === 'id' ? 'Kontak Pengelola / Pokdarwis' : 'Local Host Contact'}
              </span>
              <div className="font-semibold text-stone-900 text-sm">{dest.contactName}</div>
              <div className="text-xs text-stone-600 font-mono">{dest.contactPhone}</div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleWhatsAppContact}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors shadow-xs"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{language === 'id' ? 'Hubungi Pengelola' : 'Chat Host via WhatsApp'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleBookTicket}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors shadow-xs"
            >
              <Ticket className="w-4 h-4" />
              <span>{language === 'id' ? 'Pesan E-Tiket Online' : 'Book E-Ticket'}</span>
            </button>

            <button
              onClick={() =>
                setQrModalItem({
                  title: dest.name,
                  subtitle: dest.location,
                  code: dest.slug,
                  type: 'destinasi',
                })
              }
              className="flex items-center gap-2 px-3.5 py-2 bg-white border border-stone-300 hover:bg-stone-100 text-stone-800 rounded-lg text-xs font-medium transition-colors"
            >
              <QrCode className="w-4 h-4 text-emerald-700" />
              <span>{language === 'id' ? 'QR Code' : 'QR'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg text-xs font-medium transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span>{language === 'id' ? 'Bagikan' : 'Share'}</span>
            </button>
            <button
              onClick={() => setSelectedDestination(null)}
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-medium transition-colors"
            >
              {language === 'id' ? 'Tutup' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
