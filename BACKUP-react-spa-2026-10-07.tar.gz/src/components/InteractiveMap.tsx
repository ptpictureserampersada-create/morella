import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { MapMarkerItem } from '../types';
import { MapPin, Navigation, Phone, Star, Info, Compass, Layers } from 'lucide-react';

export const InteractiveMap: React.FC = () => {
  const { mapMarkers, setSelectedDestination, destinations, setQrModalItem, language } = useTourism();
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedMarker, setSelectedMarker] = useState<MapMarkerItem | null>(mapMarkers[0]);

  const filteredMarkers = filterType === 'all'
    ? mapMarkers
    : mapMarkers.filter((m) => m.type === filterType);

  const getMarkerColor = (type: string) => {
    switch (type) {
      case 'wisata': return 'bg-blue-600 text-white ring-blue-300';
      case 'umkm': return 'bg-emerald-600 text-white ring-emerald-300';
      case 'kuliner': return 'bg-amber-500 text-white ring-amber-200';
      case 'penginapan': return 'bg-purple-600 text-white ring-purple-300';
      case 'fasilitas': return 'bg-rose-600 text-white ring-rose-300';
      default: return 'bg-stone-700 text-white ring-stone-400';
    }
  };

  const getMarkerBadge = (type: string) => {
    switch (type) {
      case 'wisata': return { bg: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-600' };
      case 'umkm': return { bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-600' };
      case 'kuliner': return { bg: 'bg-amber-50 text-amber-800 border-amber-200', dot: 'bg-amber-600' };
      case 'penginapan': return { bg: 'bg-purple-50 text-purple-700 border-purple-200', dot: 'bg-purple-600' };
      case 'fasilitas': return { bg: 'bg-rose-50 text-rose-700 border-rose-200', dot: 'bg-rose-600' };
      default: return { bg: 'bg-stone-100 text-stone-700 border-stone-200', dot: 'bg-stone-600' };
    }
  };

  const handleOpenLinkedDestination = (marker: MapMarkerItem) => {
    const matched = destinations.find((d) => d.name.toLowerCase().includes(marker.title.toLowerCase()) || marker.title.toLowerCase().includes(d.name.toLowerCase()));
    if (matched) {
      setSelectedDestination(matched);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
      {/* Map Control Bar */}
      <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-700" />
          <span className="text-xs font-semibold uppercase tracking-wider text-stone-700">
            {language === 'id' ? 'Kategori Marker Lokasi' : 'Location Pin Categories'}
          </span>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {[
            { id: 'all', label: language === 'id' ? 'Semua Titik' : 'All Spots' },
            { id: 'wisata', label: '🔵 ' + (language === 'id' ? 'Wisata' : 'Destinations') },
            { id: 'umkm', label: '🟢 ' + (language === 'id' ? 'UMKM' : 'Crafts') },
            { id: 'kuliner', label: '🟠 ' + (language === 'id' ? 'Kuliner' : 'Culinary') },
            { id: 'penginapan', label: '🟣 ' + (language === 'id' ? 'Penginapan' : 'Stays') },
            { id: 'fasilitas', label: '🔴 ' + (language === 'id' ? 'Fasilitas' : 'Facilities') },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterType === tab.id
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Map Canvas and Split Detail Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3">
        {/* Interactive SVG Map Viewport (2 Columns on large) */}
        <div className="lg:col-span-2 relative bg-sky-900/10 min-h-[420px] sm:min-h-[500px] overflow-hidden select-none border-b lg:border-b-0 lg:border-r border-stone-200 flex items-center justify-center p-2 sm:p-4">
          
          {/* Custom SVG Coastal Cartography of Morela / Leihitu */}
          <svg
            viewBox="0 0 1000 600"
            className="w-full h-full max-h-[560px] object-contain drop-shadow-sm"
          >
            <defs>
              {/* Sea Water Gradient */}
              <linearGradient id="seaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0284c7" stopOpacity="0.35" />
                <stop offset="50%" stopColor="#0ea5e9" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.15" />
              </linearGradient>

              {/* Coastal Coral Reef Glow */}
              <linearGradient id="reefGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0.2" />
              </linearGradient>

              {/* Land Elevation Gradient */}
              <linearGradient id="landGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ecfdf5" />
                <stop offset="60%" stopColor="#d1fae5" />
                <stop offset="100%" stopColor="#a7f3d0" />
              </linearGradient>

              {/* Hill Shading */}
              <linearGradient id="hillGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#059669" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#047857" stopOpacity="0.4" />
              </linearGradient>
            </defs>

            {/* Base Sea Background */}
            <rect width="1000" height="600" fill="url(#seaGrad)" />

            {/* Sea Grid Nautical Lines */}
            <line x1="0" y1="150" x2="1000" y2="150" stroke="#0284c7" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.3" />
            <line x1="0" y1="300" x2="1000" y2="300" stroke="#0284c7" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.3" />
            <line x1="250" y1="0" x2="250" y2="600" stroke="#0284c7" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.3" />
            <line x1="750" y1="0" x2="750" y2="600" stroke="#0284c7" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.3" />

            {/* Water Label */}
            <text x="180" y="80" fill="#0369a1" fontSize="18" fontStyle="italic" opacity="0.6" fontWeight="bold">
              LAUT SERAM (SERAM SEA)
            </text>
            <text x="180" y="105" fill="#0284c7" fontSize="12" opacity="0.5">
              Pesisir Utara Jazirah Leihitu · Maluku Tengah
            </text>

            {/* Coral Reef Fringes */}
            <path
              d="M 50,220 Q 220,180 420,200 T 700,210 Q 880,240 980,260 L 980,310 Q 750,260 500,250 Q 250,250 50,270 Z"
              fill="url(#reefGrad)"
            />

            {/* Main Landmass of Morela Peninsula */}
            <path
              d="M 0,260 Q 180,230 320,240 Q 420,210 520,230 Q 640,240 760,220 Q 880,250 1000,280 L 1000,600 L 0,600 Z"
              fill="url(#landGrad)"
              stroke="#10b981"
              strokeWidth="2"
            />

            {/* Mountain Ridge & Nutmeg Forests in the South */}
            <path
              d="M 100,600 Q 260,390 420,440 Q 560,400 700,450 Q 850,380 980,600 Z"
              fill="url(#hillGrad)"
            />
            <path
              d="M 220,600 Q 360,460 500,500 Q 640,450 780,600 Z"
              fill="#065f46"
              opacity="0.25"
            />

            {/* Main Coastal Road of Leihitu */}
            <path
              d="M 0,310 Q 200,290 350,300 Q 500,290 650,295 Q 850,310 1000,340"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="4"
              strokeDasharray="8 4"
            />

            {/* Village Settlement Blocks */}
            <rect x="460" y="310" width="80" height="40" rx="4" fill="#fbbf24" opacity="0.3" />
            <text x="500" y="335" fill="#92400e" fontSize="11" fontWeight="bold" textAnchor="middle">
              NEGERI MORELA
            </text>

            {/* Compass Rose */}
            <g transform="translate(80, 80)">
              <circle cx="0" cy="0" r="26" fill="white" opacity="0.8" stroke="#cbd5e1" strokeWidth="1" />
              <polygon points="0,-22 5,-4 0,0 -5,-4" fill="#ef4444" />
              <polygon points="0,22 5,4 0,0 -5,4" fill="#64748b" />
              <polygon points="-22,0 -4,-5 0,0 -4,5" fill="#64748b" />
              <polygon points="22,0 4,-5 0,0 4,5" fill="#64748b" />
              <text x="0" y="-25" fill="#ef4444" fontSize="10" fontWeight="bold" textAnchor="middle">U</text>
            </g>
          </svg>

          {/* Interactive Marker Overlay (Positioned via Percentage) */}
          <div className="absolute inset-0 pointer-events-none">
            {filteredMarkers.map((marker) => {
              const isSelected = selectedMarker?.id === marker.id;
              const markerBg = getMarkerColor(marker.type);

              return (
                <div
                  key={marker.id}
                  style={{
                    left: `${marker.mapX}%`,
                    top: `${marker.mapY}%`,
                  }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-auto cursor-pointer group z-10"
                  onClick={() => setSelectedMarker(marker)}
                >
                  {/* Pulsing ring for active pin */}
                  {isSelected && (
                    <span className="absolute -inset-2 rounded-full bg-emerald-500/40 animate-ping" />
                  )}

                  {/* Marker Pin Button */}
                  <div
                    className={`relative w-8 h-8 rounded-full flex items-center justify-center shadow-lg transition-transform duration-200 group-hover:scale-125 ring-2 ${markerBg} ${
                      isSelected ? 'scale-125 ring-4 ring-white' : ''
                    }`}
                  >
                    <MapPin className="w-4 h-4" />
                  </div>

                  {/* Tooltip on hover */}
                  <div className="absolute left-1/2 bottom-full mb-1 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-stone-900 text-white text-[11px] px-2 py-1 rounded shadow-md pointer-events-none whitespace-nowrap font-medium z-30">
                    {marker.title}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Map legend at bottom left */}
          <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs px-3 py-2 rounded-lg border border-stone-200 text-[10px] text-stone-600 space-y-1 shadow-xs hidden sm:block">
            <div className="font-semibold text-stone-800">
              {language === 'id' ? 'Jalur Jalan:' : 'Road Legend:'}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-1 bg-amber-500 rounded" />
              <span>Jalan Utama Pesisir Leihitu</span>
            </div>
          </div>
        </div>

        {/* Selected Marker Detail Card (Right Column) */}
        <div className="p-5 sm:p-6 bg-white flex flex-col justify-between space-y-4">
          {selectedMarker ? (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${getMarkerBadge(selectedMarker.type).bg}`}>
                    {selectedMarker.categoryLabel}
                  </span>
                  {selectedMarker.rating && (
                    <span className="flex items-center gap-1 text-xs font-semibold text-amber-600">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                      <span>{selectedMarker.rating}</span>
                    </span>
                  )}
                </div>

                <h3 className="font-serif text-xl font-bold text-stone-900">
                  {selectedMarker.title}
                </h3>

                <p className="text-xs text-stone-500 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                  <span>{selectedMarker.location}</span>
                </p>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-700 leading-relaxed">
                {selectedMarker.description}
              </div>

              {selectedMarker.phone && (
                <div className="flex items-center gap-2 text-xs text-stone-600 pt-1">
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <a
                    href={`https://wa.me/${selectedMarker.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="hover:text-emerald-700 hover:underline"
                  >
                    {selectedMarker.phone}
                  </a>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={() => handleOpenLinkedDestination(selectedMarker)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs"
                >
                  <Info className="w-4 h-4" />
                  <span>{language === 'id' ? 'Lihat Informasi Lengkap' : 'View Full Details'}</span>
                </button>

                <button
                  onClick={() =>
                    setQrModalItem({
                      title: selectedMarker.title,
                      subtitle: selectedMarker.location,
                      code: selectedMarker.id,
                      type: 'marker',
                    })
                  }
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-medium transition-colors"
                >
                  <span>{language === 'id' ? '📱 Buat QR Code Lokasi' : '📱 Generate Spot QR'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-stone-400 text-xs">
              {language === 'id' ? 'Klik salah satu pin marker pada peta untuk melihat detail.' : 'Select a pin marker on the map to view details.'}
            </div>
          )}

          <div className="text-[11px] text-stone-400 border-t border-stone-100 pt-3">
            📍 Koordinat Geografis: Pesisir Utara Jazirah Leihitu (-3.58°, 128.08°)
          </div>
        </div>
      </div>
    </div>
  );
};
