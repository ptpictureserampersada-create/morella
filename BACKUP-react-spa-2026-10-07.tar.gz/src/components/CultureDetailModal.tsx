import React from 'react';
import { useTourism } from '../context/TourismContext';
import { X, BookOpen, Clock, Award, Tag } from 'lucide-react';

export const CultureDetailModal: React.FC = () => {
  const { selectedCulture, setSelectedCulture, language } = useTourism();

  if (!selectedCulture) return null;

  const item = selectedCulture;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200 text-stone-900 relative">
        <button
          onClick={() => setSelectedCulture(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-stone-900/80 text-white hover:bg-stone-950 transition-colors shadow-md"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="relative h-56 sm:h-64 w-full bg-stone-900 overflow-hidden">
          <img
            src={item.imageUrl}
            alt={item.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5 text-white">
            <span className="text-[10px] font-semibold tracking-widest uppercase text-amber-300">
              {item.category.toUpperCase().replace('_', ' ')} · ARSIP KEBUDAYAAN DESA MORELA
            </span>
            <h2 className="font-serif text-2xl font-bold text-white mt-1">
              {language === 'id' ? item.title : item.titleEn}
            </h2>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Historical Significance Ribbon */}
          <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-900 uppercase tracking-wide">
              <Award className="w-4 h-4 text-amber-700" />
              <span>{language === 'id' ? 'Makna & Signifikansi Sejarah' : 'Historical Significance'}</span>
            </div>
            <p className="text-xs text-amber-950 leading-relaxed font-serif italic">
              "{item.historicalSignificance}"
            </p>
            <div className="text-[11px] text-amber-800 flex items-center gap-1 pt-1 font-mono">
              <Clock className="w-3.5 h-3.5" />
              <span>{item.periodOrTime}</span>
            </div>
          </div>

          {/* Long form text */}
          <div className="space-y-4 text-stone-800 text-sm leading-relaxed max-w-prose whitespace-pre-line">
            {language === 'id' ? item.content : item.contentEn}
          </div>

          {/* Tags */}
          {item.tags && item.tags.length > 0 && (
            <div className="pt-4 border-t border-stone-200 flex flex-wrap items-center gap-2 text-xs text-stone-600">
              <Tag className="w-3.5 h-3.5 text-stone-400" />
              {item.tags.map((t, idx) => (
                <span key={idx} className="bg-stone-100 px-2.5 py-1 rounded-md text-stone-700">
                  #{t}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={() => setSelectedCulture(null)}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-medium transition-colors"
          >
            {language === 'id' ? 'Selesai Membaca' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
