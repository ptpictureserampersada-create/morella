import React from 'react';
import { useTourism } from '../context/TourismContext';
import { X, ShoppingBag, Phone, MapPin, Store, QrCode } from 'lucide-react';

export const ProductModal: React.FC = () => {
  const { selectedProduct, setSelectedProduct, setQrModalItem, language } = useTourism();

  if (!selectedProduct) return null;

  const prod = selectedProduct;

  const handleOrderWhatsApp = () => {
    const phone = prod.sellerPhone.replace(/[^0-9]/g, '');
    const message = encodeURIComponent(
      language === 'id'
        ? `Halo ${prod.sellerName} (${prod.sellerGroup}), saya tertarik memesan produk "${prod.name}" (${prod.priceFormatted}/${prod.unit}) yang saya lihat di portal Morela Tourism.`
        : `Hello ${prod.sellerName}, I would like to order "${prod.nameEn || prod.name}" (${prod.priceFormatted}/${prod.unit}) from the Morela Tourism marketplace.`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200 text-stone-900 relative">
        {/* Close Button */}
        <button
          onClick={() => setSelectedProduct(null)}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-stone-900/80 text-white hover:bg-stone-950 transition-colors shadow-md"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Image */}
        <div className="relative h-56 sm:h-72 w-full bg-stone-100 overflow-hidden">
          <img
            src={prod.imageUrl}
            alt={prod.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute top-4 left-4 bg-emerald-700 text-white text-[11px] font-semibold px-2.5 py-1 rounded-md uppercase tracking-wider shadow-sm">
            {prod.category.replace('_', ' ')}
          </div>
        </div>

        {/* Info Content */}
        <div className="p-6 sm:p-7 space-y-5">
          <div>
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900">
              {language === 'id' ? prod.name : prod.nameEn}
            </h3>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="font-mono text-2xl font-bold text-emerald-700 tabular-nums">
                {prod.priceFormatted}
              </span>
              <span className="text-xs text-stone-500">
                / {prod.unit}
              </span>
            </div>
          </div>

          <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1.5 text-xs text-stone-700">
            <div className="font-semibold text-stone-900 uppercase tracking-wide text-[10px] text-stone-500">
              {language === 'id' ? 'Deskripsi Produk' : 'Product Details'}
            </div>
            <p className="leading-relaxed">
              {language === 'id' ? prod.description : prod.descriptionEn}
            </p>
          </div>

          {/* Seller / Group Credentials */}
          <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-stone-900 font-semibold">
              <Store className="w-4 h-4 text-emerald-600" />
              <span>{prod.sellerGroup}</span>
            </div>
            <div className="text-stone-600">
              <span className="font-medium text-stone-800">{language === 'id' ? 'Penanggung Jawab:' : 'Host / Contact:'}</span> {prod.sellerName}
            </div>
            <div className="flex items-center gap-2 text-stone-500">
              <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
              <span>{prod.sellerAddress}</span>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleOrderWhatsApp}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-semibold transition-colors shadow-sm"
            >
              <Phone className="w-4 h-4" />
              <span>{language === 'id' ? 'Hubungi Penjual (WhatsApp)' : 'Contact Seller (WhatsApp)'}</span>
            </button>

            <button
              onClick={() =>
                setQrModalItem({
                  title: prod.name,
                  subtitle: `${prod.priceFormatted} · ${prod.sellerGroup}`,
                  code: prod.id,
                  type: 'umkm',
                })
              }
              className="p-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl transition-colors"
              title="QR Code Produk"
            >
              <QrCode className="w-5 h-5 text-emerald-700" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
