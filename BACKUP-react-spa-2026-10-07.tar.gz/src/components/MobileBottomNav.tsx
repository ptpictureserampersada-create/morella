import React from 'react';
import { useTourism } from '../context/TourismContext';
import { Home, Compass, Map, ShoppingBag, ShieldCheck } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentView, setCurrentView, language } = useTourism();

  const items = [
    { id: 'home', labelId: 'Beranda', labelEn: 'Home', icon: Home },
    { id: 'destinations', labelId: 'Wisata', labelEn: 'Explore', icon: Compass },
    { id: 'map', labelId: 'Peta', labelEn: 'Map', icon: Map },
    { id: 'umkm', labelId: 'UMKM', labelEn: 'Shop', icon: ShoppingBag },
    { id: 'admin', labelId: 'Admin', labelEn: 'Admin', icon: ShieldCheck },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-stone-900/95 backdrop-blur-md border-t border-stone-800 pb-safe">
      <div className="flex items-center justify-around h-14 px-2">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setCurrentView(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`flex flex-col items-center justify-center flex-1 h-full py-1 min-w-[50px] transition-colors ${
                isActive ? 'text-emerald-400 font-semibold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Icon className="w-4 h-4 mb-0.5" />
              <span className="text-[10px] tracking-tight truncate max-w-[64px]">
                {language === 'id' ? item.labelId : item.labelEn}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
