import React from 'react';
import { useTourism } from '../context/TourismContext';
import { Compass, Phone, Mail, MapPin, ExternalLink, Heart, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentView, language, webVisits, contactInfo } = useTourism();

  return (
    <footer className="bg-stone-950 text-stone-300 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          
          {/* Column 1: Portal Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md border border-emerald-500/30">
                <Compass className="w-5 h-5 text-emerald-200" />
              </div>
              <span className="font-serif text-xl font-bold tracking-tight text-white">
                MORELA TOURISM
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              {language === 'id'
                ? 'Portal Digital Pariwisata Desa Morela: Media promosi keindahan alam pesisir, cagar budaya sakral, serta etalase produk UMKM kreatif masyarakat Leihitu, Maluku Tengah.'
                : 'Digital Tourism Portal of Morela Village: Promoting pristine coastal landscapes, sacred cultural heritage, and artisanal creative local crafts of Leihitu, Central Maluku.'}
            </p>
            <div className="text-xs text-stone-400 pt-2 space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>{contactInfo.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>{contactInfo.phone}</span>
              </div>
            </div>
          </div>

          {/* Column 2: Program Pengabdian UNIDAR */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-white uppercase tracking-wider">
              <Award className="w-4 h-4 text-amber-400" />
              <span>{language === 'id' ? 'Program Pengabdian' : 'Community Service'}</span>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-900 border border-stone-800 space-y-2">
              <div className="text-xs font-semibold text-emerald-400">
                UNIVERSITAS DARUSSALAM AMBON
              </div>
              <p className="text-[11px] text-stone-300 leading-relaxed">
                {language === 'id'
                  ? 'Program Pengabdian Masyarakat Mahasiswa: "Digitalisasi Potensi Pariwisata dan Ekonomi Kreatif Desa Morela".'
                  : 'Student Community Service Program: "Digitalization of Tourism & Creative Economy in Morela Village".'}
              </p>
              <button
                onClick={() => setCurrentView('program')}
                className="text-xs text-amber-400 hover:text-amber-300 font-medium inline-flex items-center gap-1 pt-1"
              >
                <span>{language === 'id' ? 'Lihat Profil Tim & DPL' : 'View Team & Advisors'}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Column 3: Navigasi Cepat */}
          <div className="space-y-4">
            <div className="text-sm font-semibold text-white uppercase tracking-wider">
              {language === 'id' ? 'Navigasi Pintar' : 'Quick Navigation'}
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setCurrentView('destinations')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {language === 'id' ? 'Destinasi Wisata Unggulan' : 'Featured Destinations'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('tickets')}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <span>{language === 'id' ? 'Pemesanan E-Tiket Wisata' : 'E-Ticketing Booking'}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('culture')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {language === 'id' ? 'Arsip Budaya & Tradisi Pukul Sapu' : 'Culture & Pukul Sapu Archive'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('umkm')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {language === 'id' ? 'Katalog UMKM & Oleh-oleh' : 'Local Artisan Crafts & Market'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('map')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {language === 'id' ? 'Peta Interaktif Leihitu' : 'Interactive Map of Leihitu'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('admin')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  {language === 'id' ? 'Dashboard Pengelola Desa' : 'Village Administration Dashboard'}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Statistik & Informasi Kunjungan */}
          <div className="space-y-4">
            <div className="text-sm font-semibold text-white uppercase tracking-wider">
              {language === 'id' ? 'Statistik Portal' : 'Portal Analytics'}
            </div>
            <div className="p-3.5 rounded-xl bg-stone-900 border border-stone-800 space-y-2">
              <div className="text-[11px] text-stone-400">
                {language === 'id' ? 'Kunjungan Bulan Ini (Sept 2026)' : 'Visits This Month (Sept 2026)'}
              </div>
              <div className="font-mono text-2xl font-bold text-white tabular-nums tracking-tight">
                {webVisits.toLocaleString('id-ID')}
              </div>
              <div className="w-full bg-stone-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full w-[85%] rounded-full" />
              </div>
              <p className="text-[10px] text-stone-400">
                {language === 'id' ? 'Tingkat kunjungan wisatawan meningkat 140%' : 'Tourist inquiries up by 140%'}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>
            © 2026 Pemerintah Negeri Morela & Program Pengabdian Mahasiswa Universitas Darussalam Ambon. Hak Cipta Dilindungi.
          </p>
          <div className="flex items-center gap-4">
            <span>Kecamatan Leihitu, Maluku Tengah</span>
            <span>·</span>
            <span>Provinsi Maluku, Indonesia</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
