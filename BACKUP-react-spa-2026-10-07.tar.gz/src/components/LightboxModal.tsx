import React, { useEffect } from 'react';
import { useTourism } from '../context/TourismContext';
import { X, ChevronLeft, ChevronRight, Camera, MapPin, Calendar } from 'lucide-react';

export const LightboxModal: React.FC = () => {
  const { lightboxIndex, setLightboxIndex, gallery, language } = useTourism();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowRight') {
        setLightboxIndex((lightboxIndex + 1) % gallery.length);
      }
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((lightboxIndex - 1 + gallery.length) % gallery.length);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, gallery.length, setLightboxIndex]);

  if (lightboxIndex === null || !gallery[lightboxIndex]) return null;

  const currentPhoto = gallery[lightboxIndex];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 animate-in fade-in duration-200">
      {/* Close button */}
      <button
        onClick={() => setLightboxIndex(null)}
        className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-stone-900/80 text-stone-300 hover:text-white hover:bg-stone-800 transition-colors"
        aria-label="Close"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Prev button */}
      <button
        onClick={() => setLightboxIndex((lightboxIndex - 1 + gallery.length) % gallery.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-stone-900/80 text-white hover:bg-stone-800 transition-colors shadow-lg"
        aria-label="Previous image"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* Next button */}
      <button
        onClick={() => setLightboxIndex((lightboxIndex + 1) % gallery.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-stone-900/80 text-white hover:bg-stone-800 transition-colors shadow-lg"
        aria-label="Next image"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Image container */}
      <div className="max-w-5xl max-h-[85vh] flex flex-col items-center">
        <div className="relative overflow-hidden rounded-xl bg-stone-900 flex items-center justify-center max-h-[72vh]">
          <img
            src={currentPhoto.imageUrl}
            alt={currentPhoto.title}
            referrerPolicy="no-referrer"
            className="max-h-[72vh] max-w-full object-contain rounded-xl select-none"
            onError={(e) => {
              // Resilient fallback container if needed
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        </div>

        {/* Caption & Metadata strip */}
        <div className="mt-4 text-center max-w-xl text-stone-200 space-y-1.5 px-4">
          <h4 className="font-serif text-lg font-semibold text-white">
            {language === 'id' ? currentPhoto.title : currentPhoto.titleEn}
          </h4>
          <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-stone-400">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              {currentPhoto.location}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Camera className="w-3.5 h-3.5 text-stone-400" />
              {currentPhoto.photographer}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-stone-400" />
              {currentPhoto.dateTaken}
            </span>
          </div>
          <div className="text-[11px] text-stone-500 pt-1">
            {lightboxIndex + 1} / {gallery.length}
          </div>
        </div>
      </div>
    </div>
  );
};
