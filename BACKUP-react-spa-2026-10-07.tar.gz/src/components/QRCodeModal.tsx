import React, { useState } from 'react';
import { useTourism } from '../context/TourismContext';
import { X, QrCode, Download, Copy, Check, ExternalLink, Printer } from 'lucide-react';

export const QRCodeModal: React.FC = () => {
  const { qrModalItem, setQrModalItem, language } = useTourism();
  const [copied, setCopied] = useState(false);

  if (!qrModalItem) return null;

  const currentUrl = `${window.location.origin}/#${qrModalItem.type}/${qrModalItem.code}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-stone-900 shadow-2xl relative border border-stone-200">
        <button
          onClick={() => setQrModalItem(null)}
          className="absolute top-4 right-4 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-1 mb-5">
          <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-widest">
            {language === 'id' ? 'QR Code Resmi Wisata Desa Morela' : 'Official Morela Tourism QR'}
          </span>
          <h3 className="font-serif text-xl font-bold text-stone-900">
            {qrModalItem.title}
          </h3>
          <p className="text-xs text-stone-500">
            {qrModalItem.subtitle}
          </p>
        </div>

        {/* QR Code Presentation Box */}
        <div className="bg-stone-50 border-2 border-stone-200 rounded-xl p-5 flex flex-col items-center justify-center shadow-inner relative group">
          <div className="w-48 h-48 bg-white p-3 rounded-lg shadow-sm border border-stone-200 flex flex-col items-center justify-center relative">
            {/* SVG Rendered Realistic QR Code Matrix */}
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full text-stone-900"
              fill="currentColor"
            >
              {/* Outer Corners Finder Patterns */}
              <rect x="5" y="5" width="28" height="28" rx="3" fill="#0f172a" />
              <rect x="10" y="10" width="18" height="18" fill="white" />
              <rect x="14" y="14" width="10" height="10" fill="#0f172a" />

              <rect x="67" y="5" width="28" height="28" rx="3" fill="#0f172a" />
              <rect x="72" y="10" width="18" height="18" fill="white" />
              <rect x="76" y="14" width="10" height="10" fill="#0f172a" />

              <rect x="5" y="67" width="28" height="28" rx="3" fill="#0f172a" />
              <rect x="10" y="72" width="18" height="18" fill="white" />
              <rect x="14" y="76" width="10" height="10" fill="#0f172a" />

              {/* Timing Marks */}
              <rect x="36" y="8" width="4" height="4" fill="#0f172a" />
              <rect x="44" y="8" width="4" height="4" fill="#0f172a" />
              <rect x="52" y="8" width="4" height="4" fill="#0f172a" />
              <rect x="60" y="8" width="4" height="4" fill="#0f172a" />

              <rect x="8" y="36" width="4" height="4" fill="#0f172a" />
              <rect x="8" y="44" width="4" height="4" fill="#0f172a" />
              <rect x="8" y="52" width="4" height="4" fill="#0f172a" />
              <rect x="8" y="60" width="4" height="4" fill="#0f172a" />

              {/* Data Grid Dots */}
              <rect x="38" y="38" width="6" height="6" fill="#047857" />
              <rect x="48" y="38" width="6" height="6" fill="#0f172a" />
              <rect x="58" y="38" width="6" height="6" fill="#047857" />
              <rect x="40" y="48" width="8" height="8" fill="#0f172a" />
              <rect x="52" y="48" width="8" height="8" fill="#0f172a" />
              <rect x="38" y="60" width="6" height="6" fill="#0f172a" />
              <rect x="48" y="60" width="6" height="6" fill="#047857" />
              <rect x="58" y="60" width="6" height="6" fill="#0f172a" />
              
              <rect x="70" y="38" width="6" height="6" fill="#0f172a" />
              <rect x="80" y="42" width="6" height="6" fill="#0f172a" />
              <rect x="86" y="52" width="6" height="6" fill="#0f172a" />
              <rect x="74" y="60" width="6" height="6" fill="#0f172a" />
              <rect x="84" y="68" width="6" height="6" fill="#0f172a" />
              <rect x="72" y="78" width="6" height="6" fill="#0f172a" />
              <rect x="82" y="86" width="6" height="6" fill="#0f172a" />

              <rect x="38" y="74" width="6" height="6" fill="#0f172a" />
              <rect x="48" y="78" width="6" height="6" fill="#0f172a" />
              <rect x="58" y="84" width="6" height="6" fill="#0f172a" />

              {/* Center Seal Badge */}
              <circle cx="50" cy="50" r="9" fill="white" stroke="#047857" strokeWidth="2" />
              <circle cx="50" cy="50" r="5" fill="#047857" />
            </svg>
          </div>

          <p className="text-[11px] text-stone-500 mt-3 font-medium text-center">
            {language === 'id'
              ? 'Pindai dengan kamera smartphone untuk membuka informasi lengkap lokasi ini.'
              : 'Scan with smartphone camera to open complete guide for this destination.'}
          </p>
        </div>

        {/* Action Controls */}
        <div className="grid grid-cols-2 gap-2 mt-4">
          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-1.5 py-2 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-medium transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? (language === 'id' ? 'Tersalin!' : 'Copied!') : (language === 'id' ? 'Salin Tautan' : 'Copy Link')}</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-medium transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{language === 'id' ? 'Cetak QR Wisata' : 'Print Badge'}</span>
          </button>
        </div>

        <div className="mt-3 text-center">
          <span className="text-[10px] text-stone-400">
            Kolaborasi Universitas Darussalam Ambon & Desa Morela
          </span>
        </div>
      </div>
    </div>
  );
};
